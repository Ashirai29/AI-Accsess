using System.Drawing.Drawing2D;

namespace GhostTap.Unified.UI;

public static class UiKit
{
    public static readonly Color Background = Color.FromArgb(10, 13, 19);
    public static readonly Color Panel = Color.FromArgb(17, 22, 31);
    public static readonly Color PanelAlt = Color.FromArgb(21, 27, 38);
    public static readonly Color Border = Color.FromArgb(38, 46, 60);
    public static readonly Color Text = Color.FromArgb(238, 242, 247);
    public static readonly Color Muted = Color.FromArgb(143, 154, 171);
    public static readonly Color Accent = Color.FromArgb(0, 200, 255);
    public static readonly Color Success = Color.FromArgb(71, 214, 145);
    public static readonly Color Warning = Color.FromArgb(255, 184, 74);
    public static readonly Color Danger = Color.FromArgb(255, 102, 112);

    public static Label Label(string text, int size = 10, bool bold = false, Color? color = null)
    {
        return new Label
        {
            Text = text,
            ForeColor = color ?? Text,
            Font = new Font("Segoe UI", size, bold ? FontStyle.Bold : FontStyle.Regular),
            AutoSize = true,
            Margin = new Padding(0),
            BackColor = Color.Transparent
        };
    }

    public static Label MutedLabel(string text, int size = 9) => Label(text, size, false, Muted);

    public static Button Button(string text, Action action, bool primary = false)
    {
        var button = new Button
        {
            Text = text,
            AutoSize = true,
            FlatStyle = FlatStyle.Flat,
            FlatAppearance =
            {
                BorderSize = primary ? 0 : 1,
                BorderColor = Border
            },
            BackColor = primary ? Accent : PanelAlt,
            ForeColor = primary ? Color.FromArgb(8, 13, 18) : Text,
            Font = new Font("Segoe UI", 9, FontStyle.Bold),
            Padding = new Padding(14, 9, 14, 9),
            Cursor = Cursors.Hand,
            Margin = new Padding(0, 0, 8, 0)
        };
        button.Click += (_, _) => action();
        return button;
    }

    public static Panel Card(int radius = 14)
    {
        var panel = new RoundedPanel(radius)
        {
            BackColor = Panel,
            Margin = new Padding(0, 0, 12, 12),
            Padding = new Padding(18)
        };
        return panel;
    }

    public static FlowLayoutPanel Flow(FlowDirection direction = FlowDirection.TopDown)
    {
        return new FlowLayoutPanel
        {
            FlowDirection = direction,
            WrapContents = false,
            AutoScroll = true,
            Dock = DockStyle.Fill,
            Padding = new Padding(0),
            Margin = new Padding(0),
            BackColor = Color.Transparent
        };
    }

    public static TextBox TextBox(string placeholder = "", string text = "")
    {
        return new TextBox
        {
            Text = text,
            PlaceholderText = placeholder,
            BackColor = PanelAlt,
            ForeColor = Text,
            BorderStyle = BorderStyle.FixedSingle,
            Font = new Font("Segoe UI", 10),
            Height = 34,
            Margin = new Padding(0, 4, 0, 8)
        };
    }
}

public sealed class RoundedPanel : Panel
{
    private readonly int _radius;

    public RoundedPanel(int radius = 14)
    {
        _radius = radius;
        DoubleBuffered = true;
        ResizeRedraw = true;
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        var rect = new Rectangle(0, 0, Width - 1, Height - 1);
        using var path = RoundedRect(rect, _radius);
        using var pen = new Pen(UiKit.Border, 1);
        e.Graphics.DrawPath(pen, path);
    }

    protected override void OnPaintBackground(PaintEventArgs e)
    {
        using var brush = new SolidBrush(BackColor);
        e.Graphics.FillRectangle(brush, ClientRectangle);
    }

    private static GraphicsPath RoundedRect(Rectangle rect, int radius)
    {
        var path = new GraphicsPath();
        var d = radius * 2;
        path.AddArc(rect.X, rect.Y, d, d, 180, 90);
        path.AddArc(rect.Right - d, rect.Y, d, d, 270, 90);
        path.AddArc(rect.Right - d, rect.Bottom - d, d, d, 0, 90);
        path.AddArc(rect.X, rect.Bottom - d, d, d, 90, 90);
        path.CloseFigure();
        return path;
    }
}

public sealed class SectionHeader : Panel
{
    public SectionHeader(string eyebrow, string title, string? description = null)
    {
        Height = description is null ? 72 : 98;
        Dock = DockStyle.Top;
        BackColor = Color.Transparent;
        Padding = new Padding(0, 0, 0, 14);

        var overline = UiKit.Label(eyebrow.ToUpperInvariant(), 8, true, UiKit.Accent);
        overline.Location = new Point(0, 0);
        Controls.Add(overline);

        var heading = UiKit.Label(title, 22, true);
        heading.Location = new Point(0, 18);
        Controls.Add(heading);

        if (description is not null)
        {
            var sub = UiKit.MutedLabel(description, 9);
            sub.MaximumSize = new Size(850, 36);
            sub.Location = new Point(0, 52);
            Controls.Add(sub);
        }
    }
}
