using GhostTap.Unified.Models;
using GhostTap.Unified.Services;
using Windows.UI.Notifications.Management;

namespace GhostTap.Unified.UI;

public sealed class SetupWizardForm : Form
{
    private readonly AppServices _services;
    private readonly Action _openNfc;
    private readonly Panel _body;
    private readonly Label _stepLabel;
    private readonly Label _statusLabel;
    private readonly Button _backButton;
    private readonly Button _nextButton;
    private readonly Panel _progress;
    private int _step;

    private TextBox? _ruleName;
    private TextBox? _chatPattern;
    private TextBox? _keywords;
    private CheckBox? _anyMessage;
    private CheckBox? _autoCreate;

    public SetupWizardForm(AppServices services, Action openNfc)
    {
        _services = services;
        _openNfc = openNfc;

        Text = "GhostTap setup";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        ShowInTaskbar = false;
        ClientSize = new Size(760, 540);
        BackColor = UiKit.Background;
        ForeColor = UiKit.Text;
        Font = new Font("Segoe UI", 9);

        var title = UiKit.Label("GHOSTTAP", 15, true);
        title.Location = new Point(28, 22);
        Controls.Add(title);
        _stepLabel = UiKit.MutedLabel("Setup · Step 1 of 5", 9);
        _stepLabel.Location = new Point(29, 52);
        Controls.Add(_stepLabel);

        _progress = new Panel { Location = new Point(28, 82), Size = new Size(704, 4), BackColor = UiKit.Border };
        Controls.Add(_progress);

        _body = new Panel { Location = new Point(28, 108), Size = new Size(704, 340), BackColor = Color.Transparent, AutoScroll = true };
        Controls.Add(_body);

        _statusLabel = UiKit.MutedLabel(string.Empty, 8);
        _statusLabel.MaximumSize = new Size(704, 34);
        _statusLabel.Location = new Point(28, 458);
        Controls.Add(_statusLabel);

        _backButton = UiKit.Button("Back", Back, false);
        _backButton.Location = new Point(28, 487);
        Controls.Add(_backButton);

        _nextButton = UiKit.Button("Next", Next, true);
        _nextButton.Location = new Point(625, 487);
        Controls.Add(_nextButton);

        Shown += (_, _) => RenderStep();
    }

    private void RenderStep()
    {
        _body.Controls.Clear();
        _statusLabel.Text = string.Empty;
        _backButton.Enabled = _step > 0;
        _nextButton.Text = _step == 4 ? "Finish" : "Next";
        _stepLabel.Text = $"Setup · Step {_step + 1} of 5";

        var fill = Math.Max(1, (int)(_progress.Width * ((_step + 1) / 5.0)));
        _progress.Controls.Clear();
        _progress.Controls.Add(new Panel { Dock = DockStyle.Left, Width = fill, BackColor = UiKit.Accent });

        switch (_step)
        {
            case 0: RenderWelcome(); break;
            case 1: RenderWhatsApp(); break;
            case 2: RenderRule(); break;
            case 3: RenderNfc(); break;
            case 4: RenderFinish(); break;
        }
    }

    private void RenderWelcome()
    {
        AddHeading("Welcome to GhostTap", "One Windows assistant for NFC automation and important WhatsApp activity.");
        AddBody("GhostTap runs quietly in the background. Your NFC cards launch the modes you configure, while WhatsApp Watch turns selected notifications into persistent tasks and reminders.");
        AddCard("WHAT THIS SETUP DOES",
            "1. Connects WhatsApp through Windows notifications.\r\n" +
            "2. Creates your first chat/group rule.\r\n" +
            "3. Checks your NFC reader and explains card binding.\r\n" +
            "4. Leaves everything editable later in the app.");
        AddBody("Privacy: GhostTap has no GhostTap cloud account and sends captured WhatsApp notification content to no GhostTap server. Windows grants the listener access to user notifications; GhostTap filters that stream locally to WhatsApp notifications and stores only the task/activity data you choose to keep.");
    }

    private void RenderWhatsApp()
    {
        AddHeading("Connect WhatsApp", "GhostTap does not log into WhatsApp. It watches the WhatsApp notifications that Windows exposes.");

        if (!WindowsAppEnvironment.IsPackaged)
        {
            AddCard("INSTALLATION REQUIREMENT", "WhatsApp Watch requires the installed MSIX version because Windows notification-listener access depends on package identity and the declared userNotificationListener capability.");
            AddBody("You can use NFC, modes, tasks and reminders from the unpackaged build, but WhatsApp Watch will remain disconnected until GhostTap is installed from MSIX.");
            var openProject = UiKit.Button("Open project folder", () =>
            {
                var projectRoot = FindProjectRoot();
                if (projectRoot is not null) OpenFolder(projectRoot);
                else _statusLabel.Text = "Open the extracted GhostTap project and run .\\scripts\\Setup-GhostTap.ps1 -Install.";
            });
            openProject.Location = new Point(0, 250);
            _body.Controls.Add(openProject);
            return;
        }

        var access = _services.WhatsAppWatcher.GetAccessStatus();
        var status = access == UserNotificationListenerAccessStatus.Allowed
            ? "✓ Notification access is granted."
            : "○ Notification access is not granted yet.";
        AddCard("WINDOWS ACCESS", status);

        var actions = new FlowLayoutPanel
        {
            Location = new Point(0, 220),
            Size = new Size(680, 48),
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = true,
            AutoScroll = true,
            BackColor = Color.Transparent,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };

        var request = UiKit.Button(access == UserNotificationListenerAccessStatus.Allowed ? "Access granted" : "Grant notification access", async () =>
        {
            if (await _services.WhatsAppWatcher.RequestAccessAsync())
            {
                await _services.StartWhatsAppAsync();
            }
            RenderStep();
        }, primary: true);
        request.Enabled = access != UserNotificationListenerAccessStatus.Allowed;
        actions.Controls.Add(request);
        actions.Controls.Add(UiKit.Button("Windows notification settings", () => OpenUri("ms-settings:notifications")));
        actions.Controls.Add(UiKit.Button("Refresh connection", async () =>
        {
            var refreshed = await _services.WhatsAppWatcher.RefreshNowAsync();
            _statusLabel.Text = refreshed ? "WhatsApp notifications refreshed." : _services.WhatsAppWatcher.Status;
            RenderStep();
        }));
        actions.Controls.Add(UiKit.Button("Open WhatsApp", AutomationService.TryOpenWhatsApp));
        _body.Controls.Add(actions);

        AddBody("Then open WhatsApp on Windows and send yourself a test message. GhostTap will keep checking for permission changes in the background, so you do not have to restart the app after changing Windows access.");
        AddBody("This works for both group chats and private one-to-one chats. A rule can target either. Windows notification access is broader than WhatsApp itself, but GhostTap only processes notifications whose app name is recognised as WhatsApp.");
    }

    private void RenderRule()
    {
        AddHeading("Create your first rule", "Tell GhostTap which WhatsApp conversation matters and what words should trigger it.");
        _ruleName ??= UiKit.TextBox("Example: Software Engineering", "Software Engineering");
        _chatPattern ??= UiKit.TextBox("Group or contact name; * is a wildcard", "*Software Engineering*");
        _keywords ??= UiKit.TextBox("assignment, practical, deadline, due", "assignment, practical, deadline, due, submission, test, exam, project");

        AddField("Rule name", _ruleName, 0);
        AddField("Group / private chat", _chatPattern, 70);
        AddField("Trigger keywords", _keywords, 140);

        _anyMessage ??= new CheckBox { Text = "Match every message from this chat", AutoSize = true, ForeColor = UiKit.Text, BackColor = Color.Transparent };
        _anyMessage.Location = new Point(0, 260);
        _body.Controls.Add(_anyMessage);

        _autoCreate ??= new CheckBox { Text = "Automatically create tasks from matches", Checked = true, AutoSize = true, ForeColor = UiKit.Text, BackColor = Color.Transparent };
        _autoCreate.Location = new Point(0, 292);
        _body.Controls.Add(_autoCreate);

        var note = UiKit.MutedLabel("Busy class group → use keywords. Small project/private chat → every-message matching can work.", 8);
        note.MaximumSize = new Size(680, 40);
        note.Location = new Point(0, 318);
        _body.Controls.Add(note);
    }

    private void RenderNfc()
    {
        AddHeading("NFC setup", "Your existing NFC automation remains part of the same app.");
        var readers = _services.Nfc.Readers;
        AddCard("READER STATUS", readers.Count == 0
            ? "No PC/SC reader detected. Connect your reader and install its Windows driver."
            : $"✓ {readers.Count} reader{(readers.Count == 1 ? "" : "s")} detected.\r\n{string.Join("\r\n", readers)}");
        AddBody("To bind a card: open NFC & Modes → choose Bind next to a mode → tap the card once. Then the same card will launch that mode whenever it is detected.");
        AddBody("UID-based cards are preferred. If a reader exposes only an ATR, GhostTap will warn you because an ATR can identify a card profile rather than a unique physical card.");
        AddBody("Advanced: NFC & Modes can also write a compact ghosttap:// command as an NDEF URI on a dedicated writable Type 2 tag. The tag stores only the command, never the application.");
        var open = UiKit.Button("Open NFC & Modes", () => { _openNfc(); Close(); }, true);
        open.Location = new Point(0, 315);
        _body.Controls.Add(open);
    }

    private void RenderFinish()
    {
        AddHeading("GhostTap is ready", "Your setup can be refined at any time.");
        AddCard("NEXT", "Tap an NFC card to test a mode. Send a WhatsApp message to a watched chat to test WhatsApp Watch. Then use Tasks to manage outstanding work.");
        AddBody("Nothing is permanently locked into the wizard. You can add or remove rules, rebind cards, change reminder intervals, edit modes and pause reminders later.");
        AddBody("For the strongest WhatsApp experience, keep Windows notifications enabled for WhatsApp and run the packaged/MSIX version of GhostTap.");
    }

    private void Next()
    {
        if (_step == 2 && !SaveFirstRule())
        {
            return;
        }

        if (_step < 4)
        {
            _step++;
            RenderStep();
            return;
        }

        _services.Settings.Current.OnboardingCompleted = true;
        _services.Settings.SaveAsync().GetAwaiter().GetResult();
        DialogResult = DialogResult.OK;
        Close();
    }

    private void Back()
    {
        if (_step <= 0) return;
        _step--;
        RenderStep();
    }

    private bool SaveFirstRule()
    {
        if (_ruleName is null || _chatPattern is null || _keywords is null) return true;
        var chat = string.IsNullOrWhiteSpace(_chatPattern.Text) ? "*" : _chatPattern.Text.Trim();
        var keywords = _keywords.Text
            .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        if (_anyMessage?.Checked != true && keywords.Count == 0)
        {
            _statusLabel.Text = "Add at least one keyword, or choose “Match every message from this chat”.";
            _keywords.Focus();
            return false;
        }

        var existing = _services.Settings.Current.WhatsAppRules.FirstOrDefault(r => r.Name.Equals(_ruleName.Text.Trim(), StringComparison.OrdinalIgnoreCase));
        if (existing is null)
        {
            _services.Settings.Current.WhatsAppRules.Add(new WhatsAppWatchRule
            {
                Name = string.IsNullOrWhiteSpace(_ruleName.Text) ? "My WhatsApp rule" : _ruleName.Text.Trim(),
                ChatPattern = chat,
                Keywords = keywords,
                TriggerMode = _anyMessage?.Checked == true ? WhatsAppTriggerMode.AnyMessage : WhatsAppTriggerMode.Keywords,
                CaptureAllMessages = _anyMessage?.Checked == true,
                AutoCreateTasks = _autoCreate?.Checked == true,
                RecordActivity = true,
                ReminderMinutes = _services.Settings.Current.DefaultReminderMinutes,
                Enabled = true
            });
        }
        else
        {
            existing.ChatPattern = chat;
            existing.Keywords = keywords;
            existing.TriggerMode = _anyMessage?.Checked == true ? WhatsAppTriggerMode.AnyMessage : WhatsAppTriggerMode.Keywords;
            existing.CaptureAllMessages = _anyMessage?.Checked == true;
            existing.AutoCreateTasks = _autoCreate?.Checked == true;
            existing.Enabled = true;
        }

        _services.Settings.SaveAsync().GetAwaiter().GetResult();
        return true;
    }

    private void AddHeading(string title, string subtitle)
    {
        var heading = UiKit.Label(title, 24, true);
        heading.Location = new Point(0, 0);
        _body.Controls.Add(heading);
        var sub = UiKit.MutedLabel(subtitle, 9);
        sub.MaximumSize = new Size(680, 40);
        sub.Location = new Point(0, 40);
        _body.Controls.Add(sub);
    }

    private void AddBody(string text)
    {
        var label = UiKit.MutedLabel(text, 9);
        label.MaximumSize = new Size(680, 62);
        label.AutoSize = true;
        label.Location = new Point(0, _body.Controls.OfType<Control>().Any() ? _body.Controls.Cast<Control>().Max(c => c.Bottom) + 18 : 0);
        _body.Controls.Add(label);
    }

    private void AddCard(string heading, string body)
    {
        var card = UiKit.Card(12);
        card.Width = 680;
        card.Height = 116;
        card.Location = new Point(0, _body.Controls.OfType<Control>().Any() ? _body.Controls.Cast<Control>().Max(c => c.Bottom) + 18 : 0);
        var h = UiKit.Label(heading, 8, true, UiKit.Accent);
        h.Location = new Point(16, 14);
        card.Controls.Add(h);
        var b = UiKit.Label(body, 10, false, UiKit.Text);
        b.MaximumSize = new Size(640, 78);
        b.Location = new Point(16, 34);
        card.Controls.Add(b);
        _body.Controls.Add(card);
    }

    private void AddField(string caption, TextBox field, int y)
    {
        var label = UiKit.Label(caption, 8, true, UiKit.Muted);
        label.Location = new Point(0, 72 + y);
        _body.Controls.Add(label);
        field.Location = new Point(0, 90 + y);
        field.Width = 680;
        _body.Controls.Add(field);
    }

    private static void OpenUri(string uri)
    {
        try { System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(uri) { UseShellExecute = true }); } catch { }
    }

    private static void OpenFolder(string path)
    {
        if (!Directory.Exists(path)) return;
        try { System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("explorer.exe", $"\"{path}\"") { UseShellExecute = true }); } catch { }
    }

    private static string? FindProjectRoot()
    {
        var current = new DirectoryInfo(AppContext.BaseDirectory);
        for (var i = 0; i < 8 && current is not null; i++, current = current.Parent)
        {
            if (File.Exists(Path.Combine(current.FullName, "GhostTap.Unified.sln")))
            {
                return current.FullName;
            }
        }

        return null;
    }
}
