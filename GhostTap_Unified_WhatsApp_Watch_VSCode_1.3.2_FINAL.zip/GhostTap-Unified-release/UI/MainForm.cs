using GhostTap.Unified.Models;
using GhostTap.Unified.Services;
using Windows.UI.Notifications.Management;

namespace GhostTap.Unified.UI;

public sealed class MainForm : Form
{
    private readonly AppServices _services;
    private readonly Panel _content;
    private readonly Label _statusLabel;
    private readonly TrayService _tray;
    private readonly ProtocolBridgeService _protocolBridge = new();
    private Label? _openTasksLabel;
    private Label? _activityLabel;
    private Label? _nfcLabel;
    private Label? _modeLabel;
    private bool _closing;
    private bool _started;
    private string _pendingNfcModeId = string.Empty;
    private readonly List<ReminderForm> _openReminderForms = new();

    public MainForm(AppServices services)
    {
        _services = services;
        Text = "GhostTap Unified";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(1050, 680);
        ClientSize = new Size(1240, 780);
        BackColor = UiKit.Background;
        ForeColor = UiKit.Text;
        Font = new Font("Segoe UI", 9);
        DoubleBuffered = true;

        var iconPath = Path.Combine(AppContext.BaseDirectory, "Assets", "GhostTap.ico");
        if (File.Exists(iconPath)) Icon = new Icon(iconPath);

        var shell = new Panel { Dock = DockStyle.Fill, BackColor = UiKit.Background };
        Controls.Add(shell);

        shell.Controls.Add(BuildSidebar());
        _content = new Panel { Dock = DockStyle.Fill, BackColor = UiKit.Background, Padding = new Padding(30, 28, 30, 26) };
        shell.Controls.Add(_content);
        _content.BringToFront();

        var header = new Panel { Dock = DockStyle.Top, Height = 42, BackColor = Color.Transparent, Tag = "persistent" };
        _content.Controls.Add(header);
        _statusLabel = UiKit.MutedLabel("Starting…", 9);
        _statusLabel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        header.Controls.Add(_statusLabel);
        header.Resize += (_, _) => PositionStatus(header);
        PositionStatus(header);

        _tray = new TrayService(Show, AutomationService.TryOpenWhatsApp, ExitApplication,
            () => _services.Reminders.Paused, value => _ = SetRemindersPausedFromTrayAsync(value));

        _services.Tasks.TasksChanged += (_, _) => RefreshGlobalMetrics();
        _services.Activities.ActivitiesChanged += (_, _) => RefreshGlobalMetrics();
        _services.Settings.SettingsChanged += (_, _) => OnBackground(RefreshGlobalMetrics);
        _services.Nfc.StatusChanged += (_, status) => OnBackground(() =>
        {
            _statusLabel.Text = status;
            RefreshGlobalMetrics();
        });
        _services.WhatsAppWatcher.StatusChanged += (_, status) => OnBackground(() => _statusLabel.Text = status);
        _services.Automation.ModeChanged += (_, mode) => OnBackground(() =>
        {
            if (_modeLabel is not null && !_modeLabel.IsDisposed) _modeLabel.Text = mode.Name;
            _tray.RefreshPauseMenu();
        });
        _services.Nfc.CardScanned += OnCardScanned;
        _services.Reminders.ReminderRaised += OnReminderRaised;

        Shown += async (_, _) => await StartAsync();
        FormClosing += MainForm_FormClosing;
    }

    private void PositionStatus(Control header)
    {
        _statusLabel.Location = new Point(Math.Max(0, header.ClientSize.Width - _statusLabel.Width), 3);
    }

    private Control BuildSidebar()
    {
        var sidebar = new Panel
        {
            Dock = DockStyle.Left,
            Width = 230,
            BackColor = Color.FromArgb(13, 17, 24),
            Padding = new Padding(18, 22, 18, 18)
        };

        var brand = UiKit.Label("GHOSTTAP", 16, true);
        brand.Location = new Point(18, 18);
        sidebar.Controls.Add(brand);
        var sub = UiKit.MutedLabel("UNIFIED CONTROL", 8);
        sub.Location = new Point(19, 44);
        sidebar.Controls.Add(sub);
        sidebar.Controls.Add(new Panel { BackColor = UiKit.Border, Height = 1, Width = 194, Location = new Point(18, 72) });

        var nav = new FlowLayoutPanel
        {
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            Location = new Point(12, 92),
            Size = new Size(206, 525),
            BackColor = Color.Transparent
        };
        sidebar.Controls.Add(nav);
        AddNav(nav, "Dashboard", ShowDashboard);
        AddNav(nav, "WhatsApp Watch", ShowWhatsAppWatch);
        AddNav(nav, "Tasks", ShowTasks);
        AddNav(nav, "NFC & Modes", ShowNfcModes);
        AddNav(nav, "System Check", ShowSystemCheck);
        AddNav(nav, "Settings", ShowSettings);

        var footer = UiKit.MutedLabel("NFC automation + WhatsApp task intelligence", 8);
        footer.MaximumSize = new Size(190, 50);
        footer.Location = new Point(20, 695);
        footer.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
        sidebar.Controls.Add(footer);
        return sidebar;
    }

    private static void AddNav(FlowLayoutPanel nav, string text, Action action)
    {
        var button = new Button
        {
            Text = text,
            Width = 196,
            Height = 42,
            FlatStyle = FlatStyle.Flat,
            FlatAppearance = { BorderSize = 0 },
            BackColor = Color.Transparent,
            ForeColor = UiKit.Muted,
            TextAlign = ContentAlignment.MiddleLeft,
            Font = new Font("Segoe UI", 9, FontStyle.Bold),
            Padding = new Padding(14, 0, 0, 0),
            Cursor = Cursors.Hand,
            Margin = new Padding(0, 0, 0, 5)
        };
        button.MouseEnter += (_, _) => button.ForeColor = UiKit.Text;
        button.MouseLeave += (_, _) => button.ForeColor = UiKit.Muted;
        button.Click += (_, _) => action();
        nav.Controls.Add(button);
    }

    private async Task StartAsync()
    {
        if (_started) return;
        _started = true;
        try
        {
            await _services.InitializeAsync();
            _protocolBridge.Start(HandleProtocolCommandAsync);
            if (_services.Settings.Current.StartWithWindows)
            {
                try { _services.Startup.SetEnabled(true); } catch { }
            }

            ShowDashboard();
            await _services.StartWhatsAppAsync();

            if (!_services.Settings.Current.OnboardingCompleted)
            {
                using var wizard = new SetupWizardForm(_services, ShowNfcModes);
                wizard.ShowDialog(this);
                await _services.StartWhatsAppAsync();
                ShowDashboard();
            }

            RefreshGlobalMetrics();
            if (Environment.CommandLine.Contains("--minimized", StringComparison.OrdinalIgnoreCase) || _services.Settings.Current.StartMinimized)
            {
                BeginInvoke(Hide);
            }
        }
        catch (Exception ex)
        {
            _statusLabel.Text = "Startup completed with an error.";
            MessageBox.Show(this, $"GhostTap could not finish starting:\r\n\r\n{ex.Message}", "Startup error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private TableLayoutPanel BeginPage(string eyebrow, string title, string description, out FlowLayoutPanel body)
    {
        var page = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2,
            BackColor = Color.Transparent,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        page.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        page.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        page.Controls.Add(new SectionHeader(eyebrow, title, description), 0, 0);
        body = UiKit.Flow();
        body.Padding = new Padding(0, 0, 4, 0);
        page.Controls.Add(body, 0, 1);
        _content.Controls.Add(page);
        return page;
    }

    private void ShowDashboard()
    {
        ClearContent();
        BeginPage("GhostTap Unified", "Your control centre", "Tap an NFC card to change your workspace. Let WhatsApp Watch turn important conversations into tasks that stay visible until you handle them.", out var body);

        var cards = new FlowLayoutPanel { FlowDirection = FlowDirection.LeftToRight, WrapContents = true, AutoSize = true, Dock = DockStyle.Top, BackColor = Color.Transparent };
        body.Controls.Add(cards);
        _openTasksLabel = UiKit.Label(_services.Tasks.GetOpen().Count.ToString(), 22, true);
        _activityLabel = UiKit.Label(_services.Activities.GetUnhandledCount().ToString(), 22, true);
        _nfcLabel = UiKit.Label(_services.Nfc.Readers.Count == 0 ? "No reader" : $"{_services.Nfc.Readers.Count} reader{(_services.Nfc.Readers.Count == 1 ? "" : "s")}", 11, true);
        var currentMode = _services.Settings.GetMode(_services.Settings.Current.CurrentModeId);
        _modeLabel = UiKit.Label(currentMode?.Name ?? "No mode", 11, true);
        cards.Controls.Add(MetricCard("OPEN TASKS", _openTasksLabel, "Persistent checklist"));
        cards.Controls.Add(MetricCard("UNHANDLED", _activityLabel, "Watched WhatsApp activity"));
        cards.Controls.Add(MetricCard("NFC", _nfcLabel, "PC/SC readers"));
        cards.Controls.Add(MetricCard("MODE", _modeLabel, "Current automation"));

        var setup = UiKit.Card();
        setup.Width = 900;
        setup.Height = 150;
        setup.Controls.Add(UiKit.Label("Quick actions", 12, true));
        var actions = new FlowLayoutPanel { Location = new Point(18, 50), AutoSize = true, WrapContents = false, BackColor = Color.Transparent };
        actions.Controls.Add(UiKit.Button("WhatsApp Watch", ShowWhatsAppWatch, true));
        actions.Controls.Add(UiKit.Button("Tasks", ShowTasks));
        actions.Controls.Add(UiKit.Button("NFC & Modes", ShowNfcModes));
        actions.Controls.Add(UiKit.Button("System Check", ShowSystemCheck));
        actions.Controls.Add(UiKit.Button("Open WhatsApp", AutomationService.TryOpenWhatsApp));
        setup.Controls.Add(actions);
        body.Controls.Add(setup);

        var tasks = UiKit.Card();
        tasks.Width = 900;
        tasks.Height = 300;
        tasks.Controls.Add(UiKit.Label("Next outstanding tasks", 12, true));
        var list = new FlowLayoutPanel { Location = new Point(18, 50), Size = new Size(850, 235), FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoScroll = true, BackColor = Color.Transparent };
        foreach (var task in _services.Tasks.GetOpen().Take(6)) list.Controls.Add(BuildTaskRow(task));
        if (list.Controls.Count == 0) list.Controls.Add(UiKit.MutedLabel("Nothing outstanding. GhostTap is standing by.", 9));
        tasks.Controls.Add(list);
        body.Controls.Add(tasks);
    }

    private Panel MetricCard(string title, Control value, string detail)
    {
        var card = UiKit.Card();
        card.Width = 215;
        card.Height = 128;
        card.Controls.Add(UiKit.Label(title, 8, true, UiKit.Muted));
        value.Location = new Point(18, 40);
        card.Controls.Add(value);
        var detailLabel = UiKit.MutedLabel(detail, 8);
        detailLabel.MaximumSize = new Size(180, 24);
        detailLabel.Location = new Point(18, 91);
        card.Controls.Add(detailLabel);
        return card;
    }

    private void ShowWhatsAppWatch()
    {
        ClearContent();
        BeginPage("WhatsApp Watch", "Make WhatsApp actionable", "GhostTap uses Windows-exposed WhatsApp notifications. The same system works for groups and private chats.", out var body);

        var connection = UiKit.Card();
        connection.Width = 900;
        connection.Height = 245;
        connection.Controls.Add(UiKit.Label("CONNECTION", 8, true, UiKit.Accent));
        var state = UiKit.Label(GetWhatsAppConnectionText(), 13, true);
        state.MaximumSize = new Size(840, 45);
        state.Location = new Point(18, 34);
        connection.Controls.Add(state);
        var detail = UiKit.MutedLabel(GetWhatsAppDetailText(), 8);
        detail.MaximumSize = new Size(840, 60);
        detail.Location = new Point(18, 76);
        connection.Controls.Add(detail);

        var buttons = new FlowLayoutPanel { Location = new Point(18, 145), AutoSize = true, WrapContents = false, BackColor = Color.Transparent };
        buttons.Controls.Add(UiKit.Button("Grant / Refresh access", async () =>
        {
            var granted = await _services.WhatsAppWatcher.RequestAccessAsync();
            if (granted) await _services.StartWhatsAppAsync();
            ShowWhatsAppWatch();
        }, true));
        buttons.Controls.Add(UiKit.Button("Refresh notifications", async () => { await _services.WhatsAppWatcher.RefreshNowAsync(); ShowWhatsAppWatch(); }));
        buttons.Controls.Add(UiKit.Button("Windows Notification Settings", () => OpenUri("ms-settings:notifications")));
        buttons.Controls.Add(UiKit.Button("Test WhatsApp message", ShowTestMessageDialog));
        connection.Controls.Add(buttons);

        if (_services.WhatsAppWatcher.LastNotificationAt.HasValue)
        {
            var last = UiKit.MutedLabel($"Last captured: {_services.WhatsAppWatcher.LastNotificationAt.Value.LocalDateTime:g}  •  {_services.WhatsAppWatcher.LastChat}", 8);
            last.Location = new Point(18, 200);
            connection.Controls.Add(last);
        }
        else
        {
            var waiting = UiKit.MutedLabel("Live test: keep WhatsApp Desktop open, receive a new message, then use Refresh notifications if it is not captured automatically.", 8);
            waiting.MaximumSize = new Size(840, 34);
            waiting.Location = new Point(18, 200);
            connection.Controls.Add(waiting);
        }
        body.Controls.Add(connection);

        var parserCard = UiKit.Card();
        parserCard.Width = 900;
        parserCard.Height = 145;
        parserCard.Controls.Add(UiKit.Label("PARSER RULES", 8, true, UiKit.Accent));
        var parserStatus = UiKit.MutedLabel(_services.WhatsAppParser.ConfigurationStatus, 8);
        parserStatus.MaximumSize = new Size(840, 42);
        parserStatus.Location = new Point(18, 36);
        parserCard.Controls.Add(parserStatus);
        var parserButtons = new FlowLayoutPanel { Location = new Point(18, 88), AutoSize = true, WrapContents = false, BackColor = Color.Transparent };
        parserButtons.Controls.Add(UiKit.Button("Open parser rules", () => OpenFile(_services.WhatsAppParser.ConfigurationPath), true));
        parserButtons.Controls.Add(UiKit.Button("Reload parser", () => { _services.WhatsAppParser.ReloadConfiguration(); ShowWhatsAppWatch(); }));
        parserButtons.Controls.Add(UiKit.Button("Open data folder", () => OpenFolder(_services.Paths.Root)));
        parserCard.Controls.Add(parserButtons);
        body.Controls.Add(parserCard);

        var rulesCard = UiKit.Card();
        rulesCard.Width = 900;
        rulesCard.Height = 360;
        rulesCard.Controls.Add(UiKit.Label("WATCH RULES", 8, true, UiKit.Accent));
        var rules = new FlowLayoutPanel { Location = new Point(18, 40), Size = new Size(850, 260), FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoScroll = true, BackColor = Color.Transparent };
        foreach (var rule in _services.Settings.Current.WhatsAppRules) rules.Controls.Add(BuildRuleRow(rule));
        if (rules.Controls.Count == 0) rules.Controls.Add(UiKit.MutedLabel("No rules yet. Add one for a group or private chat.", 9));
        rulesCard.Controls.Add(rules);
        var add = UiKit.Button("Add WhatsApp rule", () => ShowRuleEditor(null), true);
        add.Location = new Point(18, 312);
        rulesCard.Controls.Add(add);
        body.Controls.Add(rulesCard);

        var activityCard = UiKit.Card();
        activityCard.Width = 900;
        activityCard.Height = 310;
        activityCard.Controls.Add(UiKit.Label("RECENT ACTIVITY", 8, true, UiKit.Accent));
        var activityList = new FlowLayoutPanel { Location = new Point(18, 40), Size = new Size(850, 215), FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoScroll = true, BackColor = Color.Transparent };
        foreach (var activity in _services.Activities.GetRecent(15)) activityList.Controls.Add(BuildActivityRow(activity));
        if (activityList.Controls.Count == 0) activityList.Controls.Add(UiKit.MutedLabel("No watched WhatsApp activity captured yet.", 9));
        activityCard.Controls.Add(activityList);
        var markAll = UiKit.Button("Mark all handled", async () => { await _services.Activities.MarkAllHandledAsync(); ShowWhatsAppWatch(); });
        markAll.Location = new Point(18, 267);
        activityCard.Controls.Add(markAll);
        var clearActivity = UiKit.Button("Clear captured activity", async () =>
        {
            var result = MessageBox.Show(this, "Clear all captured WhatsApp activity? Tasks will remain.", "Clear activity", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result != DialogResult.Yes) return;
            await _services.Activities.ClearAsync();
            ShowWhatsAppWatch();
        });
        clearActivity.Location = new Point(155, 267);
        activityCard.Controls.Add(clearActivity);
        body.Controls.Add(activityCard);
    }

    private string GetWhatsAppConnectionText()
    {
        if (!_services.Settings.Current.WhatsAppEnabled) return "WhatsApp Watch is disabled.";
        if (!_services.Settings.Current.OnboardingCompleted) return "Setup is not complete yet.";
        if (!WindowsAppEnvironment.IsPackaged) return "Install the MSIX version to connect to Windows notifications.";
        var access = _services.WhatsAppWatcher.GetAccessStatus();
        return access == UserNotificationListenerAccessStatus.Allowed
            ? "✓ Windows notification access is granted."
            : "○ Windows notification access is not granted.";
    }

    private string GetWhatsAppDetailText()
    {
        if (!WindowsAppEnvironment.IsPackaged) return "The unpackaged EXE can run NFC automation and local tasks, but the WhatsApp notification-listener feature requires package identity and the userNotificationListener capability.";
        return $"Status: {_services.WhatsAppWatcher.Status}\r\nCaptured WhatsApp notifications this session: {_services.WhatsAppWatcher.CapturedCount}.\r\nThe feature reads notifications; it does not log into WhatsApp or read WhatsApp's private database.";
    }

    private Panel BuildRuleRow(WhatsAppWatchRule rule)
    {
        var row = new RoundedPanel(10) { Width = 825, Height = 88, BackColor = UiKit.PanelAlt, Padding = new Padding(12), Margin = new Padding(0, 0, 0, 8) };
        var title = UiKit.Label(rule.Name, 10, true);
        title.Location = new Point(12, 10);
        row.Controls.Add(title);
        var match = rule.TriggerMode == WhatsAppTriggerMode.AnyMessage ? "every message" : string.Join(", ", rule.Keywords.Take(6));
        var details = UiKit.MutedLabel($"Chat: {rule.ChatPattern}  •  {match}  •  reminder every {rule.ReminderMinutes}m", 8);
        details.MaximumSize = new Size(530, 28);
        details.Location = new Point(12, 34);
        row.Controls.Add(details);
        var enabled = new CheckBox { Text = "Enabled", Checked = rule.Enabled, AutoSize = true, ForeColor = UiKit.Text, Location = new Point(565, 13), BackColor = Color.Transparent };
        enabled.CheckedChanged += async (_, _) => { rule.Enabled = enabled.Checked; await _services.Settings.SaveAsync(); };
        row.Controls.Add(enabled);
        var edit = UiKit.Button("Edit", () => ShowRuleEditor(rule));
        edit.Location = new Point(662, 8);
        row.Controls.Add(edit);
        return row;
    }

    private Panel BuildActivityRow(WhatsAppActivity activity)
    {
        var row = new RoundedPanel(9) { Width = 825, Height = 76, BackColor = activity.IsHandled ? UiKit.PanelAlt : Color.FromArgb(25, 34, 46), Padding = new Padding(12), Margin = new Padding(0, 0, 0, 7) };
        var title = UiKit.Label($"{activity.Chat}  •  {activity.CreatedAt.LocalDateTime:t}", 9, true);
        title.Location = new Point(12, 8);
        row.Controls.Add(title);
        var preview = UiKit.MutedLabel(string.IsNullOrWhiteSpace(activity.Preview) ? "No visible message text." : Limit(activity.Preview, 110), 8);
        preview.MaximumSize = new Size(625, 28);
        preview.Location = new Point(12, 31);
        row.Controls.Add(preview);
        var button = UiKit.Button(activity.IsHandled ? "Handled" : "Mark handled", async () => { await _services.Activities.MarkHandledAsync(activity.Id); ShowWhatsAppWatch(); });
        button.Location = new Point(665, 14);
        row.Controls.Add(button);
        return row;
    }

    private void ShowTasks()
    {
        ClearContent();
        BeginPage("Tasks", "Persistent checklist", "Tasks remain open until you mark them Done. Reminders automatically tighten as deadlines approach.", out var body);
        var top = UiKit.Card();
        top.Width = 900;
        top.Height = 75;
        top.Controls.Add(UiKit.Button("Add task", ShowManualTaskDialog, true));
        top.Controls[0].Location = new Point(18, 16);
        var whatsapp = UiKit.Button("Open WhatsApp", AutomationService.TryOpenWhatsApp);
        whatsapp.Location = new Point(120, 16);
        top.Controls.Add(whatsapp);
        body.Controls.Add(top);

        foreach (var task in _services.Tasks.GetAll()) body.Controls.Add(BuildTaskRow(task));
        if (body.Controls.Count <= 1)
        {
            var empty = UiKit.Card();
            empty.Width = 900;
            empty.Height = 120;
            empty.Controls.Add(UiKit.MutedLabel("No tasks yet.", 9));
            body.Controls.Add(empty);
        }
    }

    private Panel BuildTaskRow(GhostTask task)
    {
        var row = new RoundedPanel(11)
        {
            Width = 900,
            Height = 92,
            BackColor = task.Status == GhostTaskStatus.Done ? Color.FromArgb(15, 20, 27) : UiKit.Panel,
            Padding = new Padding(14),
            Margin = new Padding(0, 0, 0, 9)
        };
        var check = new CheckBox { AutoSize = true, Checked = task.Status == GhostTaskStatus.Done, Enabled = task.Status != GhostTaskStatus.Done, Location = new Point(15, 14), BackColor = Color.Transparent };
        check.CheckedChanged += async (_, _) => { if (check.Checked) await _services.Tasks.CompleteAsync(task.Id); ShowTasks(); };
        row.Controls.Add(check);
        var title = UiKit.Label(task.Title, 10, true, task.Status == GhostTaskStatus.Done ? UiKit.Muted : UiKit.Text);
        title.MaximumSize = new Size(570, 28);
        title.Location = new Point(48, 10);
        row.Controls.Add(title);
        var metaText = string.IsNullOrWhiteSpace(task.SourceChat) ? "Manual task" : task.SourceChat;
        metaText += task.DueAt.HasValue ? $"  •  Due {task.DueAt.Value.LocalDateTime:g}" : "  •  No deadline";
        var meta = UiKit.MutedLabel(metaText, 8);
        meta.MaximumSize = new Size(570, 30);
        meta.Location = new Point(48, 40);
        row.Controls.Add(meta);

        var actions = new FlowLayoutPanel { Location = new Point(630, 12), AutoSize = true, WrapContents = false, BackColor = Color.Transparent };
        if (task.Status == GhostTaskStatus.Open)
        {
            actions.Controls.Add(UiKit.Button("Done", async () => { await _services.Tasks.CompleteAsync(task.Id); ShowTasks(); }, true));
            actions.Controls.Add(UiKit.Button("Snooze", async () => { await _services.Tasks.SnoozeAsync(task.Id, TimeSpan.FromMinutes(30)); ShowTasks(); }));
        }
        else
        {
            actions.Controls.Add(UiKit.Button("Reopen", async () => { await _services.Tasks.ReopenAsync(task.Id); ShowTasks(); }));
        }
        actions.Controls.Add(UiKit.Button("WhatsApp", AutomationService.TryOpenWhatsApp));
        row.Controls.Add(actions);
        return row;
    }

    private void ShowNfcModes()
    {
        ClearContent();
        BeginPage("NFC & Modes", "Tap to automate", "Use a card identity binding for the classic workflow, or store a compact ghosttap:// command directly on a writable NDEF tag.", out var body);

        var readerCard = UiKit.Card();
        readerCard.Width = 900;
        readerCard.Height = 160;
        readerCard.Controls.Add(UiKit.Label("NFC READER", 8, true, UiKit.Accent));
        var status = UiKit.Label(_services.Nfc.Status, 11, true);
        status.MaximumSize = new Size(840, 42);
        status.Location = new Point(18, 36);
        readerCard.Controls.Add(status);
        var readers = UiKit.MutedLabel(_services.Nfc.Readers.Count == 0 ? "Connect a PC/SC-compatible reader." : string.Join("\r\n", _services.Nfc.Readers), 8);
        readers.MaximumSize = new Size(840, 44);
        readers.Location = new Point(18, 76);
        readerCard.Controls.Add(readers);
        var refresh = UiKit.Button("Refresh reader list", async () => { await _services.Nfc.RefreshOnceAsync(); ShowNfcModes(); }, true);
        refresh.Location = new Point(18, 120);
        readerCard.Controls.Add(refresh);
        if (_services.Nfc.LastScan is { } last)
        {
            var payloadText = last.PayloadUri is null ? string.Empty : $"  •  NDEF: {last.PayloadUri}";
            var lastScan = UiKit.MutedLabel($"Last card: {last.IdentityType}  •  {last.Uid}  •  {last.ReaderName}{payloadText}", 8);
            lastScan.MaximumSize = new Size(650, 34);
            lastScan.Location = new Point(210, 123);
            readerCard.Controls.Add(lastScan);
        }
        body.Controls.Add(readerCard);

        var modeCard = UiKit.Card();
        modeCard.Width = 900;
        modeCard.Height = Math.Max(360, 100 + _services.Settings.Current.FocusModes.Count * 92);
        modeCard.Controls.Add(UiKit.Label("FOCUS MODES", 8, true, UiKit.Accent));
        var modePanel = new FlowLayoutPanel { Location = new Point(18, 40), Size = new Size(850, modeCard.Height - 115), FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoScroll = true, BackColor = Color.Transparent };
        foreach (var focusMode in _services.Settings.Current.FocusModes) modePanel.Controls.Add(BuildModeRow(focusMode));
        modeCard.Controls.Add(modePanel);
        var modeHint = UiKit.MutedLabel("UID binding is the safest physical-card workflow. NDEF command tags are an additional option and are intended for writable, NDEF-formatted Type 2 tags.", 8);
        modeHint.MaximumSize = new Size(840, 42);
        modeHint.Location = new Point(18, modeCard.Height - 62);
        modeCard.Controls.Add(modeHint);
        body.Controls.Add(modeCard);

        var ndefCard = UiKit.Card();
        ndefCard.Width = 900;
        ndefCard.Height = 255;
        ndefCard.Controls.Add(UiKit.Label("NDEF COMMAND TAG", 8, true, UiKit.Accent));
        var ndefInfo = UiKit.MutedLabel("This writes a small ghosttap:// command onto the tag. The application itself stays on Windows; only the command is stored on the NFC tag.", 8);
        ndefInfo.MaximumSize = new Size(840, 36);
        ndefInfo.Location = new Point(18, 36);
        ndefCard.Controls.Add(ndefInfo);

        var readerSelector = new ComboBox
        {
            Location = new Point(18, 78),
            Width = 360,
            DropDownStyle = ComboBoxStyle.DropDownList,
            BackColor = UiKit.PanelAlt,
            ForeColor = UiKit.Text,
            FlatStyle = FlatStyle.Flat
        };
        readerSelector.Items.AddRange(_services.Nfc.Readers.ToArray());
        if (readerSelector.Items.Count > 0) readerSelector.SelectedIndex = 0;
        ndefCard.Controls.Add(readerSelector);

        var modeSelector = new ComboBox
        {
            Location = new Point(395, 78),
            Width = 280,
            DropDownStyle = ComboBoxStyle.DropDownList,
            BackColor = UiKit.PanelAlt,
            ForeColor = UiKit.Text,
            FlatStyle = FlatStyle.Flat
        };
        modeSelector.DisplayMember = nameof(FocusMode.Name);
        foreach (var focusMode in _services.Settings.Current.FocusModes) modeSelector.Items.Add(focusMode);
        if (modeSelector.Items.Count > 0) modeSelector.SelectedIndex = 0;
        ndefCard.Controls.Add(modeSelector);

        var uriLabel = UiKit.MutedLabel("", 8);
        uriLabel.MaximumSize = new Size(840, 30);
        uriLabel.Location = new Point(18, 122);
        ndefCard.Controls.Add(uriLabel);

        var updateUriPreview = new Action(() =>
        {
            if (modeSelector.SelectedItem is FocusMode selected)
            {
                var uri = NfcPayloadService.BuildModeUri(selected.Id);
                var hex = NfcPayloadService.ToHex(NfcPayloadService.BuildType2NdefTlv(uri));
                uriLabel.Text = $"URI: {uri}\r\nNDEF TLV ({NfcPayloadService.BuildType2NdefTlv(uri).Length} bytes): {Limit(hex, 190)}";
            }
            else
            {
                uriLabel.Text = "Select a mode to preview its GhostTap command.";
            }
        });
        modeSelector.SelectedIndexChanged += (_, _) => updateUriPreview();
        updateUriPreview();

        var ndefButtons = new FlowLayoutPanel { Location = new Point(18, 170), AutoSize = true, WrapContents = false, BackColor = Color.Transparent };
        var write = UiKit.Button("Write command to tag", async () =>
        {
            if (readerSelector.SelectedItem is not string readerName || modeSelector.SelectedItem is not FocusMode selected)
            {
                MessageBox.Show(this, "Select an NFC reader and mode first.", "NDEF command", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            var confirm = MessageBox.Show(this, $"Write the GhostTap command for {selected.Name} to the tag on {readerName}?\r\n\r\nThis can overwrite existing user NDEF data on the tag. Use a dedicated programmable tag.", "Confirm NFC write", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (confirm != DialogResult.Yes) return;
            var result = await _services.Nfc.WriteModeUriAsync(readerName, selected.Id);
            MessageBox.Show(this, result.Message + (result.Succeeded ? $"\r\n\r\n{result.Uri}" : ""), result.Succeeded ? "NDEF command written" : "NDEF write failed", MessageBoxButtons.OK, result.Succeeded ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
            if (result.Succeeded) await _services.Nfc.RefreshOnceAsync();
            ShowNfcModes();
        }, true);
        write.Enabled = readerSelector.Items.Count > 0 && modeSelector.Items.Count > 0;
        ndefButtons.Controls.Add(write);
        ndefButtons.Controls.Add(UiKit.Button("Copy URI", () =>
        {
            if (modeSelector.SelectedItem is FocusMode selected) CopyText(NfcPayloadService.BuildModeUri(selected.Id));
        }));
        ndefButtons.Controls.Add(UiKit.Button("Copy NDEF hex", () =>
        {
            if (modeSelector.SelectedItem is FocusMode selected) CopyText(NfcPayloadService.ToHex(NfcPayloadService.BuildType2NdefTlv(NfcPayloadService.BuildModeUri(selected.Id))));
        }));
        ndefCard.Controls.Add(ndefButtons);

        var warning = UiKit.MutedLabel("Compatibility note: GhostTap writes the common PC/SC Type 2 page commands (FF B0/FF D6). Some readers or tags use vendor-specific NDEF commands and may reject writes even when they are NFC-capable.", 8);
        warning.MaximumSize = new Size(840, 42);
        warning.Location = new Point(18, 212);
        ndefCard.Controls.Add(warning);
        body.Controls.Add(ndefCard);

        var bindingsCard = UiKit.Card();
        bindingsCard.Width = 900;
        bindingsCard.Height = Math.Max(190, 70 + _services.Settings.Current.NfcBindings.Count * 68);
        bindingsCard.Controls.Add(UiKit.Label("CARD BINDINGS", 8, true, UiKit.Accent));
        var bindings = new FlowLayoutPanel { Location = new Point(18, 40), Size = new Size(850, bindingsCard.Height - 58), FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoScroll = true, BackColor = Color.Transparent };
        foreach (var binding in _services.Settings.Current.NfcBindings)
        {
            var boundMode = _services.Settings.GetMode(binding.ModeId);
            var row = new RoundedPanel(8) { Width = 825, Height = 58, BackColor = UiKit.PanelAlt, Margin = new Padding(0, 0, 0, 6) };
            var text = UiKit.Label($"{binding.Label}  •  {binding.IdentityType}", 9, true);
            text.Location = new Point(12, 9);
            row.Controls.Add(text);
            var info = UiKit.MutedLabel($"{boundMode?.Name ?? "Unknown mode"}  •  {Limit(binding.Uid, 48)}", 8);
            info.Location = new Point(12, 31);
            row.Controls.Add(info);
            var remove = UiKit.Button("Remove", async () => { _services.Settings.RemoveCardBinding(binding.Uid); await _services.Settings.SaveAsync(); ShowNfcModes(); });
            remove.Location = new Point(715, 9);
            row.Controls.Add(remove);
            bindings.Controls.Add(row);
        }
        if (bindings.Controls.Count == 0) bindings.Controls.Add(UiKit.MutedLabel("No UID/ATR cards are bound yet. NDEF command tags do not require a saved binding.", 9));
        bindingsCard.Controls.Add(bindings);
        body.Controls.Add(bindingsCard);
    }

    private Panel BuildModeRow(FocusMode mode)
    {
        var row = new RoundedPanel(10) { Width = 825, Height = 78, BackColor = UiKit.PanelAlt, Margin = new Padding(0, 0, 0, 8) };
        var title = UiKit.Label(mode.Name, 10, true);
        title.Location = new Point(12, 9);
        row.Controls.Add(title);
        var detail = UiKit.MutedLabel($"{mode.Description}  •  {mode.Targets.Count} automation target{(mode.Targets.Count == 1 ? "" : "s")}", 8);
        detail.MaximumSize = new Size(420, 36);
        detail.Location = new Point(12, 32);
        row.Controls.Add(detail);
        var run = UiKit.Button("Run", async () => await RunModeWithFeedbackAsync(mode.Id), true);
        run.Location = new Point(465, 13);
        row.Controls.Add(run);
        var bind = UiKit.Button("Bind", () =>
        {
            _pendingNfcModeId = mode.Id;
            _statusLabel.Text = $"Tap an NFC card now to bind it to {mode.Name}.";
        });
        bind.Location = new Point(545, 13);
        row.Controls.Add(bind);
        var edit = UiKit.Button("Edit", () => ShowModeEditor(mode));
        edit.Location = new Point(632, 13);
        row.Controls.Add(edit);
        return row;
    }

    private async Task RunModeWithFeedbackAsync(string modeId)
    {
        await _services.Automation.RunModeAsync(modeId);
        var mode = _services.Settings.GetMode(modeId);
        _statusLabel.Text = $"{mode?.Name ?? "Mode"} activated.";
    }

    private void ShowSystemCheck()
    {
        ClearContent();
        BeginPage("System Check", "Know what is ready", "A local diagnostic page for the pieces that matter: Windows, package identity, WhatsApp access, NFC, storage and startup.", out var body);

        var startupEnabled = false;
        var startupCheckDetails = "Windows startup could not be checked.";
        var startupCheckPassed = false;
        try
        {
            startupEnabled = _services.Startup.IsEnabled();
            startupCheckPassed = startupEnabled == _services.Settings.Current.StartWithWindows;
            startupCheckDetails = startupEnabled ? "GhostTap is registered to start with Windows." : "GhostTap is not registered to start with Windows.";
        }
        catch (Exception ex)
        {
            startupCheckDetails = $"Could not read startup registration: {ex.Message}";
        }

        var checks = new List<AppCheckResult>
        {
            new() { Name = "Windows version", Passed = WindowsAppEnvironment.IsSupportedWindowsVersion, Details = WindowsAppEnvironment.IsSupportedWindowsVersion ? $"Windows build {Environment.OSVersion.Version.Build} meets the app minimum." : $"Windows build {Environment.OSVersion.Version.Build} is below 19041." },
            new() { Name = "Package identity", Passed = WindowsAppEnvironment.IsPackaged, Warning = !WindowsAppEnvironment.IsPackaged, Details = WindowsAppEnvironment.IsPackaged ? "MSIX identity is present." : "Unpackaged mode detected. NFC/local tasks work; WhatsApp Watch requires the packaged install." },
            new() { Name = "WhatsApp access", Passed = WindowsAppEnvironment.IsPackaged && _services.WhatsAppWatcher.GetAccessStatus() == UserNotificationListenerAccessStatus.Allowed, Warning = WindowsAppEnvironment.IsPackaged && _services.WhatsAppWatcher.GetAccessStatus() != UserNotificationListenerAccessStatus.Allowed, Details = GetWhatsAppConnectionText() },
            new() { Name = "WhatsApp rules", Passed = _services.Settings.Current.WhatsAppRules.Count > 0, Details = $"{_services.Settings.Current.WhatsAppRules.Count} rule(s) configured." },
            new() { Name = "NFC reader", Passed = _services.Nfc.Readers.Count > 0, Warning = _services.Nfc.Readers.Count == 0, Details = _services.Nfc.Readers.Count > 0 ? string.Join("; ", _services.Nfc.Readers) : "No reader is currently detected." },
            new() { Name = "NDEF command layer", Passed = NfcPayloadService.TryValidateGhostTapUri(NfcPayloadService.BuildModeUri("study"), out _), Details = "GhostTap custom URI and NDEF encoder are available." },
            new() { Name = "SQLite database", Passed = _services.Database.IsAvailable, Warning = !_services.Database.IsAvailable, Details = _services.Database.Status },
            new() { Name = "WhatsApp parser rules", Passed = File.Exists(_services.WhatsAppParser.ConfigurationPath), Warning = !File.Exists(_services.WhatsAppParser.ConfigurationPath), Details = _services.WhatsAppParser.ConfigurationStatus },
            new() { Name = "Protocol bridge", Passed = _protocolBridge.IsRunning, Warning = !_protocolBridge.IsRunning, Details = _protocolBridge.IsRunning ? "Running-instance GhostTap URI commands are relayed to the live process." : "Protocol relay is not running yet." },
            new() { Name = "Local data", Passed = Directory.Exists(_services.Paths.Root), Details = _services.Paths.Root },
            new() { Name = "Windows startup", Passed = startupCheckPassed, Warning = !startupCheckPassed, Details = startupCheckDetails }
        };

        foreach (var check in checks) body.Controls.Add(BuildCheckRow(check));

        var actions = UiKit.Card();
        actions.Width = 900;
        actions.Height = 120;
        actions.Controls.Add(UiKit.Label("Diagnostics actions", 11, true));
        var buttons = new FlowLayoutPanel { Location = new Point(18, 50), AutoSize = true, WrapContents = false, BackColor = Color.Transparent };
        buttons.Controls.Add(UiKit.Button("Open setup wizard", () => { using var wizard = new SetupWizardForm(_services, ShowNfcModes); wizard.ShowDialog(this); ShowSystemCheck(); }, true));
        buttons.Controls.Add(UiKit.Button("Refresh NFC", async () => { await _services.Nfc.RefreshOnceAsync(); ShowSystemCheck(); }));
        buttons.Controls.Add(UiKit.Button("Refresh WhatsApp", async () => { await _services.WhatsAppWatcher.RefreshNowAsync(); ShowSystemCheck(); }));
        actions.Controls.Add(buttons);
        body.Controls.Add(actions);
    }

    private Panel BuildCheckRow(AppCheckResult result)
    {
        var card = UiKit.Card(10);
        card.Width = 900;
        card.Height = 72;
        var icon = result.Passed ? "✓" : result.Warning ? "!" : "✕";
        var color = result.Passed ? UiKit.Success : result.Warning ? UiKit.Warning : UiKit.Danger;
        var mark = UiKit.Label(icon, 16, true, color);
        mark.Location = new Point(18, 16);
        card.Controls.Add(mark);
        var title = UiKit.Label(result.Name, 9, true);
        title.Location = new Point(48, 11);
        card.Controls.Add(title);
        var detail = UiKit.MutedLabel(result.Details, 8);
        detail.MaximumSize = new Size(800, 34);
        detail.Location = new Point(48, 32);
        card.Controls.Add(detail);
        return card;
    }

    private void ShowSettings()
    {
        ClearContent();
        BeginPage("Settings", "Control the behaviour", "GhostTap keeps its task data, rules and card bindings local by default.", out var body);

        var general = UiKit.Card();
        general.Width = 900;
        general.Height = 390;
        general.Controls.Add(UiKit.Label("GENERAL", 8, true, UiKit.Accent));
        var start = new CheckBox { Text = "Start GhostTap with Windows", Checked = _services.Settings.Current.StartWithWindows, AutoSize = true, ForeColor = UiKit.Text, BackColor = Color.Transparent, Location = new Point(18, 45) };
        start.CheckedChanged += async (_, _) => { _services.Settings.Current.StartWithWindows = start.Checked; try { _services.Startup.SetEnabled(start.Checked); } catch { } await _services.Settings.SaveAsync(); };
        general.Controls.Add(start);
        var minimized = new CheckBox { Text = "Start minimized to the tray", Checked = _services.Settings.Current.StartMinimized, AutoSize = true, ForeColor = UiKit.Text, BackColor = Color.Transparent, Location = new Point(18, 80) };
        minimized.CheckedChanged += async (_, _) => { _services.Settings.Current.StartMinimized = minimized.Checked; await _services.Settings.SaveAsync(); };
        general.Controls.Add(minimized);
        var whatsapp = new CheckBox { Text = "Enable WhatsApp Watch", Checked = _services.Settings.Current.WhatsAppEnabled, AutoSize = true, ForeColor = UiKit.Text, BackColor = Color.Transparent, Location = new Point(18, 115) };
        whatsapp.CheckedChanged += async (_, _) =>
        {
            _services.Settings.Current.WhatsAppEnabled = whatsapp.Checked;
            await _services.Settings.SaveAsync();
            await _services.WhatsAppWatcher.StopAsync();
            if (whatsapp.Checked) await _services.StartWhatsAppAsync();
        };
        general.Controls.Add(whatsapp);
        var close = new CheckBox { Text = "Allow configured modes to close distracting apps", Checked = _services.Settings.Current.CloseDistractingProcesses, AutoSize = true, ForeColor = UiKit.Text, BackColor = Color.Transparent, Location = new Point(18, 150) };
        close.CheckedChanged += async (_, _) => { _services.Settings.Current.CloseDistractingProcesses = close.Checked; await _services.Settings.SaveAsync(); };
        general.Controls.Add(close);
        var force = new CheckBox { Text = "Force terminate if graceful close fails", Checked = _services.Settings.Current.ForceCloseDistractingProcesses, AutoSize = true, ForeColor = UiKit.Text, BackColor = Color.Transparent, Location = new Point(18, 185) };
        force.CheckedChanged += async (_, _) => { _services.Settings.Current.ForceCloseDistractingProcesses = force.Checked; await _services.Settings.SaveAsync(); };
        general.Controls.Add(force);
        general.Controls.Add(Place(UiKit.Label("WhatsApp notification sync interval (seconds)", 9, true), 18, 225));
        var poll = UiKit.TextBox(text: _services.Settings.Current.WhatsAppPollSeconds.ToString());
        poll.Location = new Point(18, 245); poll.Width = 120; general.Controls.Add(poll);
        var savePoll = UiKit.Button("Save", async () => { if (int.TryParse(poll.Text, out var seconds)) _services.Settings.Current.WhatsAppPollSeconds = Math.Clamp(seconds, 15, 120); poll.Text = _services.Settings.Current.WhatsAppPollSeconds.ToString(); await _services.Settings.SaveAsync(); }, true);
        savePoll.Location = new Point(150, 243); general.Controls.Add(savePoll);
        general.Controls.Add(Place(UiKit.Label("Default reminder interval (minutes)", 9, true), 280, 225));
        var reminder = UiKit.TextBox(text: _services.Settings.Current.DefaultReminderMinutes.ToString());
        reminder.Location = new Point(280, 245); reminder.Width = 120; general.Controls.Add(reminder);
        var saveReminder = UiKit.Button("Save", async () => { if (int.TryParse(reminder.Text, out var mins)) _services.Settings.Current.DefaultReminderMinutes = Math.Clamp(mins, 5, 1440); reminder.Text = _services.Settings.Current.DefaultReminderMinutes.ToString(); await _services.Settings.SaveAsync(); }, true);
        saveReminder.Location = new Point(412, 243); general.Controls.Add(saveReminder);
        var setupButton = UiKit.Button("Run onboarding again", () =>
        {
            using var wizard = new SetupWizardForm(_services, ShowNfcModes);
            wizard.ShowDialog(this);
        });
        setupButton.Location = new Point(540, 315);
        general.Controls.Add(setupButton);

        general.Controls.Add(Place(UiKit.Label("Notifications to import at first connection (minutes)", 9, true), 18, 300));
        var catchup = UiKit.TextBox(text: _services.Settings.Current.NotificationCatchUpMinutes.ToString());
        catchup.Location = new Point(18, 320); catchup.Width = 120; general.Controls.Add(catchup);
        var saveCatch = UiKit.Button("Save", async () => { if (int.TryParse(catchup.Text, out var mins)) _services.Settings.Current.NotificationCatchUpMinutes = Math.Clamp(mins, 1, 60); catchup.Text = _services.Settings.Current.NotificationCatchUpMinutes.ToString(); await _services.Settings.SaveAsync(); }, true);
        saveCatch.Location = new Point(150, 318); general.Controls.Add(saveCatch);
        body.Controls.Add(general);

        var process = UiKit.Card();
        process.Width = 900;
        process.Height = 165;
        process.Controls.Add(UiKit.Label("DISTRACTING PROCESSES", 8, true, UiKit.Accent));
        var proc = UiKit.TextBox(text: string.Join(Environment.NewLine, _services.Settings.Current.DistractingProcessNames));
        proc.Location = new Point(18, 42); proc.Width = 650; proc.Height = 75; proc.Multiline = true; proc.ScrollBars = ScrollBars.Vertical; process.Controls.Add(proc);
        var procSave = UiKit.Button("Save process list", async () =>
        {
            _services.Settings.Current.DistractingProcessNames = proc.Text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            foreach (var mode in _services.Settings.Current.FocusModes.Where(x => x.Id == "study")) mode.CloseProcessNames = _services.Settings.Current.DistractingProcessNames.ToList();
            await _services.Settings.SaveAsync();
        }, true);
        procSave.Location = new Point(685, 55); process.Controls.Add(procSave);
        body.Controls.Add(process);
    }


    private void ShowRuleEditor(WhatsAppWatchRule? existing)
    {
        var rule = existing ?? new WhatsAppWatchRule { Name = "New rule", ChatPattern = "*" };
        var isNew = existing is null;
        using var dialog = new Form { Text = isNew ? "Add WhatsApp rule" : "Edit WhatsApp rule", StartPosition = FormStartPosition.CenterParent, FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false, ClientSize = new Size(560, 520), BackColor = UiKit.Background, ForeColor = UiKit.Text };
        var name = UiKit.TextBox("Example: Software Engineering", rule.Name); name.Location = new Point(20, 35); name.Width = 500; dialog.Controls.Add(name); dialog.Controls.Add(Place(UiKit.Label("Rule name", 8, true, UiKit.Muted), 20, 17));
        var chat = UiKit.TextBox("Group or private chat name; * is wildcard", rule.ChatPattern); chat.Location = new Point(20, 97); chat.Width = 500; dialog.Controls.Add(chat); dialog.Controls.Add(Place(UiKit.Label("Group / private chat", 8, true, UiKit.Muted), 20, 79));
        var keywords = UiKit.TextBox("assignment, practical, deadline", string.Join(", ", rule.Keywords)); keywords.Location = new Point(20, 159); keywords.Width = 500; dialog.Controls.Add(keywords); dialog.Controls.Add(Place(UiKit.Label("Keywords (keyword mode)", 8, true, UiKit.Muted), 20, 141));
        var trigger = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 230, Location = new Point(20, 222), BackColor = UiKit.PanelAlt, ForeColor = UiKit.Text, FlatStyle = FlatStyle.Flat };
        trigger.Items.AddRange(new object[] { "Keywords", "Every message" }); trigger.SelectedIndex = rule.TriggerMode == WhatsAppTriggerMode.AnyMessage ? 1 : 0; dialog.Controls.Add(trigger); dialog.Controls.Add(Place(UiKit.Label("Trigger", 8, true, UiKit.Muted), 20, 204));
        var minutes = UiKit.TextBox(text: rule.ReminderMinutes.ToString()); minutes.Location = new Point(275, 222); minutes.Width = 100; dialog.Controls.Add(minutes); dialog.Controls.Add(Place(UiKit.Label("Reminder minutes", 8, true, UiKit.Muted), 275, 204));
        var enabled = new CheckBox { Text = "Enabled", Checked = rule.Enabled, AutoSize = true, ForeColor = UiKit.Text, BackColor = Color.Transparent, Location = new Point(395, 226) }; dialog.Controls.Add(enabled);
        var autoCreate = new CheckBox { Text = "Automatically create tasks", Checked = rule.AutoCreateTasks, AutoSize = true, ForeColor = UiKit.Text, BackColor = Color.Transparent, Location = new Point(20, 267) }; dialog.Controls.Add(autoCreate);
        var capture = new CheckBox { Text = "Treat every message as a match", Checked = rule.CaptureAllMessages, AutoSize = true, ForeColor = UiKit.Text, BackColor = Color.Transparent, Location = new Point(20, 301) }; dialog.Controls.Add(capture);
        var record = new CheckBox { Text = "Record matching activity", Checked = rule.RecordActivity, AutoSize = true, ForeColor = UiKit.Text, BackColor = Color.Transparent, Location = new Point(20, 335) }; dialog.Controls.Add(record);
        dialog.Controls.Add(Place(UiKit.MutedLabel("For a busy class group, use keywords. For a small project/private chat, every-message matching can be useful. Automatic tasks from every message may create a lot of tasks.", 8), 20, 365));
        var save = UiKit.Button("Save rule", async () =>
        {
            var cleanName = string.IsNullOrWhiteSpace(name.Text) ? "WhatsApp rule" : name.Text.Trim();
            var cleanChat = string.IsNullOrWhiteSpace(chat.Text) ? "*" : chat.Text.Trim();
            var cleanKeywords = keywords.Text.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            var every = trigger.SelectedIndex == 1 || capture.Checked;
            rule.Name = cleanName;
            rule.ChatPattern = cleanChat;
            rule.Keywords = cleanKeywords;
            rule.TriggerMode = every ? WhatsAppTriggerMode.AnyMessage : WhatsAppTriggerMode.Keywords;
            rule.CaptureAllMessages = every;
            rule.ReminderMinutes = int.TryParse(minutes.Text, out var mins) ? Math.Clamp(mins, 5, 1440) : _services.Settings.Current.DefaultReminderMinutes;
            rule.Enabled = enabled.Checked;
            rule.AutoCreateTasks = autoCreate.Checked;
            rule.RecordActivity = record.Checked;
            if (isNew) _services.Settings.Current.WhatsAppRules.Add(rule);
            await _services.Settings.SaveAsync();
            dialog.Close();
        }, true);
        save.Location = new Point(20, 430); dialog.Controls.Add(save);
        var cancel = UiKit.Button("Cancel", dialog.Close); cancel.Location = new Point(125, 430); dialog.Controls.Add(cancel);
        dialog.ShowDialog(this);
        ShowWhatsAppWatch();
    }

    private void ShowModeEditor(FocusMode mode)
    {
        using var dialog = new Form { Text = $"Edit {mode.Name}", StartPosition = FormStartPosition.CenterParent, FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false, ClientSize = new Size(640, 560), BackColor = UiKit.Background, ForeColor = UiKit.Text };
        var name = UiKit.TextBox(text: mode.Name); name.Location = new Point(20, 35); name.Width = 585; dialog.Controls.Add(name); dialog.Controls.Add(Place(UiKit.Label("Mode name", 8, true, UiKit.Muted), 20, 17));
        var desc = UiKit.TextBox(text: mode.Description); desc.Location = new Point(20, 97); desc.Width = 585; dialog.Controls.Add(desc); dialog.Controls.Add(Place(UiKit.Label("Description", 8, true, UiKit.Muted), 20, 79));
        dialog.Controls.Add(Place(UiKit.Label("Automation targets", 8, true, UiKit.Muted), 20, 141));
        var targetBox = UiKit.TextBox(text: string.Join(Environment.NewLine, mode.Targets.Select(FormatTarget))); targetBox.Location = new Point(20, 159); targetBox.Width = 585; targetBox.Height = 175; targetBox.Multiline = true; targetBox.ScrollBars = ScrollBars.Vertical; dialog.Controls.Add(targetBox);
        dialog.Controls.Add(Place(UiKit.MutedLabel("Examples: url:https://example.com   app:code   shell:steam://open/main", 8), 20, 340));
        var closeBox = UiKit.TextBox(text: string.Join(", ", mode.CloseProcessNames)); closeBox.Location = new Point(20, 382); closeBox.Width = 585; dialog.Controls.Add(closeBox); dialog.Controls.Add(Place(UiKit.Label("Processes to close when enabled", 8, true, UiKit.Muted), 20, 364));
        var pause = new CheckBox { Text = "Pause reminders while this mode is active", Checked = mode.PauseReminders, AutoSize = true, ForeColor = UiKit.Text, BackColor = Color.Transparent, Location = new Point(20, 430) }; dialog.Controls.Add(pause);
        var save = UiKit.Button("Save mode", async () =>
        {
            mode.Name = string.IsNullOrWhiteSpace(name.Text) ? mode.Name : name.Text.Trim();
            mode.Description = desc.Text.Trim();
            mode.Targets = targetBox.Text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).Select(ParseTarget).Where(x => x is not null).Cast<AutomationTarget>().ToList();
            mode.CloseProcessNames = closeBox.Text.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            mode.PauseReminders = pause.Checked;
            await _services.Settings.SaveAsync();
            dialog.Close();
        }, true);
        save.Location = new Point(20, 480); dialog.Controls.Add(save);
        var cancel = UiKit.Button("Cancel", dialog.Close); cancel.Location = new Point(120, 480); dialog.Controls.Add(cancel);
        dialog.ShowDialog(this);
        ShowNfcModes();
    }

    private static string FormatTarget(AutomationTarget target) => target.Kind switch
    {
        AutomationTargetKind.Url => "url:" + target.Value,
        AutomationTargetKind.Application => "app:" + target.Value,
        AutomationTargetKind.Shell => "shell:" + target.Value,
        _ => target.Value
    };

    private static AutomationTarget? ParseTarget(string line)
    {
        var trimmed = line.Trim();
        if (trimmed.Length == 0) return null;
        var separator = trimmed.IndexOf(':');
        if (separator <= 0) return new AutomationTarget { Kind = AutomationTargetKind.Application, Value = trimmed };
        var prefix = trimmed[..separator].ToLowerInvariant();
        var value = trimmed[(separator + 1)..];
        return prefix switch
        {
            "url" => new AutomationTarget { Kind = AutomationTargetKind.Url, Value = value },
            "app" => new AutomationTarget { Kind = AutomationTargetKind.Application, Value = value },
            "shell" => new AutomationTarget { Kind = AutomationTargetKind.Shell, Value = value },
            _ => new AutomationTarget { Kind = AutomationTargetKind.Application, Value = trimmed }
        };
    }

    private void ShowManualTaskDialog()
    {
        using var dialog = new Form { Text = "Add task", StartPosition = FormStartPosition.CenterParent, FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false, ClientSize = new Size(520, 360), BackColor = UiKit.Background, ForeColor = UiKit.Text };
        dialog.Controls.Add(Place(UiKit.Label("Task", 8, true, UiKit.Muted), 20, 20));
        var title = UiKit.TextBox("What needs to be done?"); title.Location = new Point(20, 40); title.Width = 475; dialog.Controls.Add(title);
        dialog.Controls.Add(Place(UiKit.Label("Source", 8, true, UiKit.Muted), 20, 100));
        var source = UiKit.TextBox("Optional group, chat or project"); source.Location = new Point(20, 120); source.Width = 475; dialog.Controls.Add(source);
        dialog.Controls.Add(Place(UiKit.Label("Deadline", 8, true, UiKit.Muted), 20, 180));
        var due = UiKit.TextBox("Optional: 12 Oct 2026 / tomorrow / Friday at 14:00"); due.Location = new Point(20, 200); due.Width = 475; dialog.Controls.Add(due);
        var save = UiKit.Button("Create task", async () =>
        {
            if (string.IsNullOrWhiteSpace(title.Text)) return;
            await _services.Tasks.AddCandidateAsync(new TaskCandidate
            {
                Title = title.Text.Trim(),
                SourceChat = source.Text.Trim(),
                SourcePreview = "Manual task",
                DueAt = ParseManualDueDate(due.Text),
                ReminderMinutes = _services.Settings.Current.DefaultReminderMinutes,
                DetectionKey = HashService.Sha256("manual", title.Text.Trim(), Guid.NewGuid().ToString("N"))
            });
            dialog.Close();
        }, true);
        save.Location = new Point(20, 275); dialog.Controls.Add(save);
        var cancel = UiKit.Button("Cancel", dialog.Close); cancel.Location = new Point(130, 275); dialog.Controls.Add(cancel);
        dialog.ShowDialog(this);
        ShowTasks();
    }

    private DateTimeOffset? ParseManualDueDate(string input)
    {
        if (string.IsNullOrWhiteSpace(input)) return null;
        var probe = new WhatsAppNotificationItem { Body = "assignment due " + input, CreatedAt = DateTimeOffset.Now };
        return _services.WhatsAppParser.Extract(probe, new[]
        {
            new WhatsAppWatchRule { ChatPattern = "*", Keywords = new() { "assignment" }, Enabled = true, AutoCreateTasks = true }
        }).FirstOrDefault()?.DueAt;
    }

    private void ShowTestMessageDialog()
    {
        using var dialog = new Form { Text = "Simulate a WhatsApp notification", StartPosition = FormStartPosition.CenterParent, FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false, ClientSize = new Size(540, 310), BackColor = UiKit.Background, ForeColor = UiKit.Text };
        dialog.Controls.Add(Place(UiKit.Label("Group / private chat", 8, true, UiKit.Muted), 20, 16));
        var chat = UiKit.TextBox("Software Engineering", "Software Engineering"); chat.Location = new Point(20, 36); chat.Width = 490; dialog.Controls.Add(chat);
        dialog.Controls.Add(Place(UiKit.Label("Message", 8, true, UiKit.Muted), 20, 92));
        var body = UiKit.TextBox("There are two practicals and an assignment due Friday at 14:00", "There are two practicals and an assignment due Friday at 14:00"); body.Location = new Point(20, 112); body.Width = 490; body.Height = 75; body.Multiline = true; dialog.Controls.Add(body);
        var send = UiKit.Button("Process test notification", async () => { await _services.WhatsAppWatcher.ProcessSyntheticMessageAsync(chat.Text, body.Text); dialog.Close(); }, true);
        send.Location = new Point(20, 220); dialog.Controls.Add(send);
        var cancel = UiKit.Button("Cancel", dialog.Close); cancel.Location = new Point(190, 220); dialog.Controls.Add(cancel);
        dialog.ShowDialog(this);
        ShowWhatsAppWatch();
    }

    private async void OnCardScanned(object? sender, NfcCardScannedEventArgs e)
    {
        try
        {
            if (!string.IsNullOrWhiteSpace(_pendingNfcModeId))
            {
                if (!e.IsUniqueIdentity)
                {
                    var result = MessageBox.Show(this, "This reader exposed an ATR instead of a unique UID. Different cards of the same technology can share an ATR. Bind anyway?", "NFC identity warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (result != DialogResult.Yes) return;
                }

                var pendingMode = _services.Settings.GetMode(_pendingNfcModeId);
                _services.Settings.BindCard(e.Uid, _pendingNfcModeId, pendingMode?.Name ?? "GhostTap mode", e.IdentityType, e.IsUniqueIdentity);
                await _services.Settings.SaveAsync();
                _pendingNfcModeId = string.Empty;
                OnBackground(() => { _statusLabel.Text = $"Card bound to {pendingMode?.Name ?? "mode"}."; ShowNfcModes(); });
                return;
            }

            var binding = _services.Settings.GetNfcBinding(e.Uid);
            if (binding is not null)
            {
                await _services.Automation.RunModeAsync(binding.ModeId);
                var activeMode = _services.Settings.GetMode(binding.ModeId);
                OnBackground(() => _statusLabel.Text = $"NFC: {binding.Label} → {activeMode?.Name ?? "mode"}");
                return;
            }

            if (e.PayloadUri is not null)
            {
                var executed = await ProtocolCommandService.ExecuteAsync(e.PayloadUri, _services.Settings, _services.Tasks, _services.Automation).ConfigureAwait(false);
                OnBackground(() => _statusLabel.Text = executed
                    ? $"NFC command executed: {e.PayloadUri}"
                    : $"NFC command rejected: {e.PayloadUri}");
                return;
            }

            OnBackground(() => _statusLabel.Text = $"Card detected ({e.IdentityType}). Bind it to a mode or write a GhostTap NDEF command from NFC & Modes.");
        }
        catch (Exception ex)
        {
            OnBackground(() => _statusLabel.Text = $"NFC action failed: {ex.Message}");
        }
    }

    private async Task HandleProtocolCommandAsync(Uri uri)
    {
        try
        {
            var executed = await ProtocolCommandService.ExecuteAsync(uri, _services.Settings, _services.Tasks, _services.Automation).ConfigureAwait(false);
            OnBackground(() => _statusLabel.Text = executed
                ? $"GhostTap command executed: {uri}"
                : $"GhostTap command rejected: {uri}");
        }
        catch (Exception ex)
        {
            OnBackground(() => _statusLabel.Text = $"GhostTap command failed: {ex.Message}");
        }
    }

    private async Task SetRemindersPausedFromTrayAsync(bool paused)
    {
        try
        {
            if (paused)
            {
                await _services.Automation.PauseRemindersAsync().ConfigureAwait(false);
            }
            else
            {
                await _services.Automation.ResumeRemindersAsync().ConfigureAwait(false);
            }
            OnBackground(() => _tray.RefreshPauseMenu());
        }
        catch (Exception ex)
        {
            OnBackground(() => _statusLabel.Text = $"Reminder state could not be saved: {ex.Message}");
        }
    }

    private void OnReminderRaised(object? sender, GhostTask task)
    {
        OnBackground(() =>
        {
            try
            {
                _tray.ShowTaskReminder(task);
                var popup = new ReminderForm(_services.Tasks, task);
                popup.FormClosed += (_, _) => _openReminderForms.Remove(popup);
                _openReminderForms.Add(popup);
                popup.Show(this);
            }
            catch { }
        });
    }

    private void RefreshGlobalMetrics()
    {
        if (IsDisposed) return;
        OnBackground(() =>
        {
            if (_openTasksLabel is not null && !_openTasksLabel.IsDisposed) _openTasksLabel.Text = _services.Tasks.GetOpen().Count.ToString();
            if (_activityLabel is not null && !_activityLabel.IsDisposed) _activityLabel.Text = _services.Activities.GetUnhandledCount().ToString();
            if (_nfcLabel is not null && !_nfcLabel.IsDisposed) _nfcLabel.Text = _services.Nfc.Readers.Count == 0 ? "No reader" : $"{_services.Nfc.Readers.Count} reader{(_services.Nfc.Readers.Count == 1 ? "" : "s")}";
            var mode = _services.Settings.GetMode(_services.Settings.Current.CurrentModeId);
            if (_modeLabel is not null && !_modeLabel.IsDisposed) _modeLabel.Text = mode?.Name ?? "No mode";
        });
    }

    private void ClearContent()
    {
        for (var i = _content.Controls.Count - 1; i >= 0; i--)
        {
            var control = _content.Controls[i];
            if (Equals(control.Tag, "persistent")) continue;
            _content.Controls.RemoveAt(i);
            control.Dispose();
        }
        _openTasksLabel = null;
        _activityLabel = null;
        _nfcLabel = null;
        _modeLabel = null;
    }

    private void OnBackground(Action action)
    {
        if (IsDisposed || Disposing || !IsHandleCreated) return;
        try { BeginInvoke(action); } catch { }
    }

    private static Control Place(Control control, int x, int y) { control.Location = new Point(x, y); return control; }
    private static string Limit(string value, int max) => value.Length <= max ? value : value[..Math.Max(0, max - 1)].TrimEnd() + "…";

    private static void CopyText(string value)
    {
        try { Clipboard.SetText(value); }
        catch { }
    }

    private static void OpenFile(string path)
    {
        try
        {
            if (!File.Exists(path)) return;
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(path) { UseShellExecute = true });
        }
        catch { }
    }

    private static void OpenUri(string uri)
    {
        try { System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(uri) { UseShellExecute = true }); } catch { }
    }

    private void MainForm_FormClosing(object? sender, FormClosingEventArgs e)
    {
        if (_closing) return;
        if (e.CloseReason == CloseReason.WindowsShutDown || e.CloseReason == CloseReason.TaskManagerClosing) { _closing = true; return; }
        e.Cancel = true;
        Hide();
    }

    protected override void OnFormClosed(FormClosedEventArgs e)
    {
        _closing = true;
        foreach (var reminder in _openReminderForms.ToList()) { try { reminder.Close(); } catch { } }
        try { _protocolBridge.DisposeAsync().AsTask().GetAwaiter().GetResult(); } catch { }
        _tray.Dispose();
        base.OnFormClosed(e);
    }

    public void ExitApplication()
    {
        if (_closing) return;
        _closing = true;
        try { _protocolBridge.DisposeAsync().AsTask().GetAwaiter().GetResult(); } catch { }
        try { _services.WhatsAppWatcher.StopAsync().GetAwaiter().GetResult(); } catch { }
        try { _services.Reminders.StopAsync().GetAwaiter().GetResult(); } catch { }
        try { _services.Nfc.StopAsync().GetAwaiter().GetResult(); } catch { }
        Application.Exit();
    }
}
