using GhostTap.Unified.Models;
using GhostTap.Unified.Services;

namespace GhostTap.Unified.UI;

public sealed class ReminderForm : Form
{
    private readonly TaskService _tasks;
    private readonly GhostTask _task;

    public ReminderForm(TaskService tasks, GhostTask task)
    {
        _tasks = tasks;
        _task = task;
        Build();
    }

    private void Build()
    {
        Text = "GhostTap Reminder";
        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.Manual;
        TopMost = true;
        ShowInTaskbar = false;
        BackColor = UiKit.Background;
        ClientSize = new Size(440, 250);
        Padding = new Padding(18);

        var workArea = Screen.PrimaryScreen?.WorkingArea ?? Screen.GetWorkingArea(Cursor.Position);
        Location = new Point(workArea.Right - Width - 22, workArea.Bottom - Height - 22);

        var panel = new RoundedPanel(18)
        {
            Dock = DockStyle.Fill,
            BackColor = UiKit.Panel,
            Padding = new Padding(20)
        };
        Controls.Add(panel);

        var title = UiKit.Label("Outstanding task", 9, true, UiKit.Warning);
        title.Location = new Point(20, 18);
        panel.Controls.Add(title);

        var taskTitle = UiKit.Label(_task.Title, 16, true);
        taskTitle.MaximumSize = new Size(380, 52);
        taskTitle.Location = new Point(20, 42);
        panel.Controls.Add(taskTitle);

        var source = UiKit.MutedLabel(string.IsNullOrWhiteSpace(_task.SourceChat) ? "Manual task" : _task.SourceChat, 9);
        source.Location = new Point(20, 100);
        panel.Controls.Add(source);

        var preview = UiKit.MutedLabel(_task.SourcePreview.Length > 90 ? _task.SourcePreview[..90] + "…" : _task.SourcePreview, 8);
        preview.MaximumSize = new Size(380, 45);
        preview.Location = new Point(20, 122);
        panel.Controls.Add(preview);

        if (_task.DueAt.HasValue)
        {
            var due = UiKit.Label($"Due {_task.DueAt.Value.LocalDateTime:g}", 8, true, UiKit.Danger);
            due.Location = new Point(20, 172);
            panel.Controls.Add(due);
        }

        var actions = new FlowLayoutPanel
        {
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            AutoSize = true,
            Location = new Point(20, 198),
            BackColor = Color.Transparent
        };
        actions.Controls.Add(UiKit.Button("Done", async () =>
        {
            await _tasks.CompleteAsync(_task.Id);
            Close();
        }, primary: true));
        actions.Controls.Add(UiKit.Button("Snooze 30m", async () =>
        {
            await _tasks.SnoozeAsync(_task.Id, TimeSpan.FromMinutes(30));
            Close();
        }));
        actions.Controls.Add(UiKit.Button("Open WhatsApp", () =>
        {
            AutomationService.TryOpenWhatsApp();
            Close();
        }));
        panel.Controls.Add(actions);
    }
}
