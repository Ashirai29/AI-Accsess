# GhostTap Unified

GhostTap Unified combines the original **NFC automation system** with **WhatsApp Watch** in one Windows application.

## Release

Version **1.3.2**.

## Core workflow

**NFC:** `tap card → bound mode → launch configured workspace`

**WhatsApp:** `WhatsApp notification → selected chat/rule → activity/task → persistent reminder → Done`

The default Study Mode opens UFS Blackboard (`learn.ufs.ac.za`) and Spotify's current **Deep Focus** playlist; both targets remain editable in NFC & Modes.

## WhatsApp integration

WhatsApp Watch works with **group chats and private chats**. It does not log into WhatsApp and it does not read WhatsApp's private database. It uses Windows' user notification listener to read notifications that Windows exposes to the installed app. Microsoft requires the `userNotificationListener` capability and user permission for this feature, and recommends explaining the permission during first-run onboarding.

Because the notification-listener feature depends on package identity, the repository now treats **MSIX installation as the supported WhatsApp Watch installation path**. The normal unpackaged EXE remains useful for development and for NFC/tasks, but it clearly tells the user why WhatsApp Watch is unavailable there.

## First-run onboarding

The application opens a five-step wizard:

1. Welcome and feature explanation.
2. WhatsApp connection and Windows permission.
3. First group/private-chat rule.
4. NFC reader/card setup.
5. Finish and testing guidance.

After onboarding, **System Check** can re-open the wizard at any time.

## WhatsApp rules

Each rule can target:

- a group name;
- a private contact/chat;
- a wildcard pattern using `*`;
- specific keywords; or
- every message in a selected chat.

Rules can independently control automatic task creation and activity recording. Keyword rules are recommended for busy class groups; every-message mode is better suited to small project/private chats.

## Task intelligence

The parser recognises common work items including practicals, assignments, projects, tests, exams, quizzes, presentations and reports. It can expand messages such as `two practicals and an assignment` into individual checklist items and can recognise common deadlines such as `tomorrow`, weekdays, dates and times. The parser is deterministic so that behaviour is predictable; inferred deadlines should still be checked against the actual instruction.

## NFC automation

GhostTap monitors PC/SC-compatible readers. It first attempts a common UID APDU and uses an ATR fingerprint only as a fallback. ATR fallback is explicitly marked as non-unique because an ATR can identify a card technology/profile rather than a specific physical card.

Modes include Study Mode, Coding Mode, Gaming Mode and Sleep Mode. Each mode can be edited to launch URLs, applications or shell/protocol targets and can optionally pause reminders or close configured distracting processes.

## Build

Requirements on Windows:

- Windows 10/11; minimum target 19041.
- .NET 8 SDK.
- Windows SDK for MSIX packaging.
- A PC/SC-compatible NFC reader for NFC functionality.

### Normal development build

```powershell
dotnet restore .\GhostTap.Unified.sln
dotnet build .\GhostTap.Unified.sln -c Release -p:Platform=x64
```

### Full verification

```powershell
.\scripts\Verify.ps1
```

This performs source/manifest preflight checks, restores the real dependencies, builds Release x64 and runs the included smoke tests.

### Recommended WhatsApp installation

```powershell
.\scripts\Setup-GhostTap.ps1 -Install
```

This publishes the app, creates the local development signing certificate if necessary, builds and signs the MSIX, trusts the certificate for the current user, and can install the package.

Alternatively:

```powershell
.\scripts\Package-MSIX.ps1 -Install
```

## Local data

GhostTap stores its local state under:

`%LocalAppData%\GhostTapUnified\`

Data includes settings, tasks, activities and de-duplication state. No GhostTap cloud account is required.

## Troubleshooting

Use **System Check** first. For WhatsApp, the order is package identity → notification access → Windows WhatsApp notifications → chat/rule match → refresh notifications → Recent Activity → Tasks. For NFC, check reader detection → card binding → UID identity → driver/hardware support.

## Documentation

- `docs/USER-GUIDE.md` — how to use the app from first run onward.
- `docs/ARCHITECTURE.md` — component architecture.
- `docs/WHATSAPP-LIMITS.md` — WhatsApp boundaries.
- `docs/NFC-HARDWARE.md` — NFC hardware expectations.
- `docs/MANUAL-QA.md` — release QA checklist.


## 1.3.2 architecture upgrades

GhostTap Unified now includes four complementary integration layers:

- NFC UID/ATR bindings remain supported for the original card-to-mode workflow.
- Writable NDEF Type 2 tags can store compact `ghosttap://trigger?action=<mode>` command URIs; the tag never stores the application itself.
- WhatsApp parser categories and regular expressions live in the user-editable `whatsapp-parser.json` file and can be reloaded without recompiling.
- Tasks and WhatsApp activity history are persisted in SQLite (`GhostTap.db`) while settings remain JSON configuration.

The Windows package registers the `ghosttap:` URI protocol and declares the notification-listener capability needed by WhatsApp Watch. A PC/SC reader is still required for physical NFC card detection/writing, and Type 2 write commands depend on reader/tag compatibility.

## Build isolation (1.3.2)

The application and smoke-test projects use explicit compile items. This is intentional: the smoke-test project lives under the application directory, and SDK-style wildcard compilation can otherwise allow nested project sources or stale generated files to contaminate the app build. The build, verify and publish scripts also remove stale `bin`/`obj` intermediates before compiling.

For a clean verification on Windows, run:

```powershell
.\scripts\Verify.ps1
```
