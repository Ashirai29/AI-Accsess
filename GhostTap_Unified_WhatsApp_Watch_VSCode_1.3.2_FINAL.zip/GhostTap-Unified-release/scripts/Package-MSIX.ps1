param(
    [switch]$Install
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

& (Join-Path $PSScriptRoot 'Setup-GhostTap.ps1')

if ($Install) {
    & (Join-Path $PSScriptRoot 'Install-MSIX.ps1')
}

Write-Host "MSIX ready: $(Join-Path $root 'out\GhostTap.Unified.msix')" -ForegroundColor Green
