$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

# Remove stale compiler intermediates before the first build. This prevents
# generated AssemblyInfo/TargetFramework files from older project layouts
# from participating in incremental compilation.
foreach ($path in @('bin', 'obj', 'tests\bin', 'tests\obj')) {
    $full = Join-Path $root $path
    if (Test-Path $full) { Remove-Item $full -Recurse -Force -ErrorAction SilentlyContinue }
}

Write-Host "[1/5] Running source preflight checks..." -ForegroundColor Cyan
$project = Get-Content .\GhostTap.Unified.csproj -Raw
$packageManifest = Get-Content .\packaging\Package.appxmanifest -Raw
$allCSharp = (Get-ChildItem . -Recurse -Filter *.cs | ForEach-Object { Get-Content $_.FullName -Raw }) -join "`n"

if ($project -match 'Microsoft\.Windows\.SDK\.NET\.Ref') {
    throw 'Invalid Microsoft.Windows.SDK.NET.Ref PackageReference found.'
}
if ($project -notmatch '<TargetFramework>net8\.0-windows10\.0\.19041\.0</TargetFramework>') {
    throw 'Unexpected target framework.'
}
if ($project -notmatch '<EnableWindowsTargeting>true</EnableWindowsTargeting>') {
    throw 'EnableWindowsTargeting is missing.'
}
if ($allCSharp -match 'Controls\[\^1\]') {
    throw 'Unsafe Controls[^1] expression found.'
}
if ($allCSharp -notmatch 'Dictionary<string,\s*ISCardMonitor>') {
    throw 'Expected ISCardMonitor map not found.'
}
if ($packageManifest -notmatch 'uap3:Capability Name="userNotificationListener"') {
    throw 'MSIX userNotificationListener capability is missing.'
}
if ($packageManifest -notmatch 'rescap:Capability Name="runFullTrust"') {
    throw 'MSIX runFullTrust capability is missing.'
}
if ($packageManifest -notmatch 'Version="1\.3\.2\.0"') {
    throw 'MSIX version does not match release 1.3.2.'
}

if ($allCSharp -notmatch 'ghosttap://') {
    throw 'GhostTap custom URI support is missing.'
}
if (-not (Test-Path .\Config\whatsapp-parser.json)) {
    throw 'External WhatsApp parser configuration is missing.'
}
if ($project -notmatch 'Microsoft.Data.Sqlite') {
    throw 'SQLite persistence package is missing.'
}
if ($allCSharp -notmatch 'WaitForConnectionAsync|GetNotificationsAsync|Task.Run') {
    throw 'Expected asynchronous/background service patterns were not found.'
}
if ($allCSharp -notmatch 'IsWhatsAppAppName\(displayName\)') {
    throw 'WhatsApp app-name detection is not delegated to external parser configuration.'
}
if ($allCSharp -match 'displayName\.Contains\(\"WhatsApp\"') {
    throw 'Hard-coded WhatsApp app-name detection bypass remains in the watcher.'
}

[xml](Get-Content .\app.manifest -Raw) | Out-Null
[xml](Get-Content .\packaging\Package.appxmanifest -Raw) | Out-Null
if (Get-Command python -ErrorAction SilentlyContinue) {
    Write-Host 'Running cross-platform static verifier...' -ForegroundColor Cyan
    python .\scripts\static_verify.py
    if ($LASTEXITCODE -ne 0) { throw 'Cross-platform static verification failed.' }
}
Write-Host 'Source preflight passed.' -ForegroundColor Green

Write-Host "[2/5] Checking .NET SDK..." -ForegroundColor Cyan
dotnet --info | Out-Null

Write-Host "[3/5] Restoring solution..." -ForegroundColor Cyan
dotnet restore .\GhostTap.Unified.sln

Write-Host "[4/5] Building Release x64..." -ForegroundColor Cyan
dotnet build .\GhostTap.Unified.sln -c Release -p:Platform=x64 --no-restore

Write-Host "[5/5] Running smoke tests..." -ForegroundColor Cyan
dotnet run --project .\tests\GhostTap.Unified.SmokeTests.csproj -c Release -p:Platform=x64 --no-restore

Write-Host "GhostTap verification completed successfully." -ForegroundColor Green
