param(
    [switch]$SkipBuild,
    [switch]$Install
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

function Find-WindowsKitTool([string]$name) {
    $kits = Join-Path ${env:ProgramFiles(x86)} 'Windows Kits\10\bin'
    return Get-ChildItem $kits -Filter $name -Recurse -ErrorAction SilentlyContinue |
        Where-Object { $_.FullName -match '\\x64\\' } |
        Sort-Object FullName -Descending |
        Select-Object -First 1
}

if (-not $SkipBuild) {
    & (Join-Path $PSScriptRoot 'Verify.ps1')
}

& (Join-Path $PSScriptRoot 'Publish.ps1')
$publish = Join-Path $root 'out\publish'
$staging = Join-Path $root 'out\msix-staging'
$package = Join-Path $root 'out\GhostTap.Unified.msix'
$cerFile = Join-Path $root 'out\GhostTap-Unified.cer'

$makeappx = Find-WindowsKitTool 'makeappx.exe'
$signtool = Find-WindowsKitTool 'signtool.exe'
if (-not $makeappx) { throw 'Windows SDK makeappx.exe was not found. Install the Windows 10/11 SDK.' }
if (-not $signtool) { throw 'Windows SDK signtool.exe was not found. Install the Windows 10/11 SDK.' }

Remove-Item $staging -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path $staging -Force | Out-Null
Copy-Item (Join-Path $publish '*') $staging -Recurse -Force
Copy-Item (Join-Path $root 'packaging\Package.appxmanifest') $staging -Force
New-Item -ItemType Directory -Path (Join-Path $staging 'Assets') -Force | Out-Null
Copy-Item (Join-Path $root 'packaging\Assets\*') (Join-Path $staging 'Assets') -Force

Remove-Item $package -Force -ErrorAction SilentlyContinue
& $makeappx.FullName pack /d $staging /p $package /o
if ($LASTEXITCODE -ne 0) { throw "makeappx failed with exit code $LASTEXITCODE" }

$subject = 'CN=GHOSTTECH.Ashirai'
$cert = Get-ChildItem Cert:\CurrentUser\My |
    Where-Object { $_.Subject -eq $subject -and $_.HasPrivateKey -and $_.EnhancedKeyUsageList.ObjectId -contains '1.3.6.1.5.5.7.3.3' } |
    Sort-Object NotAfter -Descending |
    Select-Object -First 1

if (-not $cert) {
    $cert = New-SelfSignedCertificate -Type CodeSigningCert -Subject $subject -CertStoreLocation 'Cert:\CurrentUser\My' -NotAfter (Get-Date).AddYears(3)
}

Remove-Item $cerFile -Force -ErrorAction SilentlyContinue
Export-Certificate -Cert $cert -FilePath $cerFile | Out-Null
& $signtool.FullName sign /fd SHA256 /sha1 $cert.Thumbprint $package
if ($LASTEXITCODE -ne 0) { throw "signtool failed with exit code $LASTEXITCODE" }

Import-Certificate -FilePath $cerFile -CertStoreLocation 'Cert:\CurrentUser\TrustedPeople' | Out-Null

Write-Host "Signed MSIX: $package" -ForegroundColor Green
if ($Install) {
    Add-AppxPackage -Path $package -ForceApplicationShutdown
    Write-Host 'GhostTap Unified installed.' -ForegroundColor Green
} else {
    Write-Host "Run: .\scripts\Install-MSIX.ps1" -ForegroundColor Yellow
}
