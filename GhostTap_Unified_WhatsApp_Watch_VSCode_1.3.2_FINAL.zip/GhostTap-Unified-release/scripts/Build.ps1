$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

# Remove stale compiler intermediates before the first build. This prevents
# generated AssemblyInfo/TargetFramework files from older project layouts
# from participating in incremental compilation.
foreach ($path in @('bin', 'obj', 'tests\bin', 'tests\obj')) {
    $full = Join-Path $root $path
    if (Test-Path $full) { Remove-Item $full -Recurse -Force -ErrorAction SilentlyContinue }
}

dotnet restore .\GhostTap.Unified.sln
dotnet build .\GhostTap.Unified.sln -c Release -p:Platform=x64 --no-restore
Write-Host "Release build completed." -ForegroundColor Green
