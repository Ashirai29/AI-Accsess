param(
    [switch]$SelfContained = $true
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

# Keep publish deterministic after project-structure changes. Remove stale compiler
# intermediates so generated assembly metadata from an older build cannot be reused.
foreach ($path in @('bin', 'obj', 'tests\bin', 'tests\obj')) {
    $full = Join-Path $root $path
    if (Test-Path $full) { Remove-Item $full -Recurse -Force -ErrorAction SilentlyContinue }
}

$out = Join-Path $root 'out\publish'
Remove-Item $out -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path $out -Force | Out-Null

$sc = if ($SelfContained) { 'true' } else { 'false' }
dotnet publish .\GhostTap.Unified.csproj -c Release -r win-x64 --self-contained:$sc -o $out -p:Platform=x64

Write-Host "Published to $out" -ForegroundColor Green
