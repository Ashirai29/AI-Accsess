#!/usr/bin/env python3
from __future__ import annotations
import json, re, sys
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []
warnings: list[str] = []

def err(msg: str): errors.append(msg)
def warn(msg: str): warnings.append(msg)

# Required project files.
required = [
    'GhostTap.Unified.csproj', 'GhostTap.Unified.sln', 'Program.cs',
    'Config/whatsapp-parser.json', 'packaging/Package.appxmanifest',
    'Services/NfcPayloadService.cs', 'Services/NfcService.cs',
    'Services/WhatsAppParser.cs', 'Services/WhatsAppWatcherService.cs',
    'Services/DatabaseService.cs', 'UI/SetupWizardForm.cs'
]
for rel in required:
    if not (ROOT / rel).is_file(): err(f'Missing required file: {rel}')

# XML validity + expected platform/package settings.
for rel in ['GhostTap.Unified.csproj', 'tests/GhostTap.Unified.SmokeTests.csproj', 'packaging/Package.appxmanifest']:
    p = ROOT / rel
    if p.exists():
        try: ET.parse(p)
        except Exception as e: err(f'Invalid XML in {rel}: {e}')

csproj = (ROOT/'GhostTap.Unified.csproj').read_text(encoding='utf-8')
manifest = (ROOT/'packaging/Package.appxmanifest').read_text(encoding='utf-8')
if 'Microsoft.Windows.SDK.NET.Ref' in csproj: err('Forbidden Microsoft.Windows.SDK.NET.Ref PackageReference remains.')
if 'EnableWindowsTargeting>true' not in csproj: err('EnableWindowsTargeting is missing.')
if 'Microsoft.Data.Sqlite' not in csproj: err('Microsoft.Data.Sqlite package is missing.')
if '<EnableDefaultCompileItems>false</EnableDefaultCompileItems>' not in csproj: err('Explicit compile item mode is required to prevent nested project/generated source leakage.')
if '<Compile Include="tests' in csproj: err('Main project must not compile smoke-test sources.')
if '<Version>1.3.2</Version>' not in csproj: err('Project version is not 1.3.2.')
if 'Version="1.3.2.0"' not in manifest: err('MSIX manifest version is not 1.3.2.0.')
if 'Name="ghosttap"' not in manifest: err('ghosttap URI protocol registration is missing.')
if 'Name="userNotificationListener"' not in manifest: err('userNotificationListener capability is missing.')
if 'Name="runFullTrust"' not in manifest: err('runFullTrust capability is missing.')

# JSON parser config must be valid and meaningful.
config_path = ROOT/'Config/whatsapp-parser.json'
if config_path.exists():
    try:
        cfg=json.loads(config_path.read_text(encoding='utf-8'))
        for key in ['categories','numberWords','patterns','recognizedAppNamePatterns']:
            if key not in cfg: err(f'WhatsApp parser config is missing {key}.')
    except Exception as e: err(f'Invalid WhatsApp parser JSON: {e}')

# Lightweight C# delimiter lexer: ignore comments, char literals and string contents including raw strings approximately.
def delimiter_check(text: str, rel: str):
    stack=[]
    i=0; n=len(text); state='code'; verbatim=False; raw_quotes=0
    line=1
    pairs={')':'(',']':'[','}':'{'}
    while i<n:
        c=text[i]
        if c=='\n': line+=1
        if state=='line_comment':
            if c=='\n': state='code'
            i+=1; continue
        if state=='block_comment':
            if text.startswith('*/',i): state='code'; i+=2
            else: i+=1
            continue
        if state=='string':
            if verbatim:
                if c=='"' and i+1<n and text[i+1]=='"': i+=2; continue
                if c=='"': state='code'; verbatim=False
                i+=1; continue
            if c=='\\': i+=2; continue
            if c=='"': state='code'
            i+=1; continue
        if state=='char':
            if c=='\\': i+=2; continue
            if c=="'": state='code'
            i+=1; continue
        if text.startswith('//',i): state='line_comment'; i+=2; continue
        if text.startswith('/*',i): state='block_comment'; i+=2; continue
        # Detect regular/verbatim interpolated strings. For structural checks, treating the whole literal as opaque is sufficient.
        if c=='@' and i+1<n and text[i+1]=='"': state='string'; verbatim=True; i+=2; continue
        if c=='$' and i+1<n and text[i+1]=='@' and i+2<n and text[i+2]=='"': state='string'; verbatim=True; i+=3; continue
        if c=='@' and i+1<n and text[i+1]=='$' and i+2<n and text[i+2]=='"': state='string'; verbatim=True; i+=3; continue
        if c=='$' and i+1<n and text[i+1]=='"': state='string'; verbatim=False; i+=2; continue
        if c=='"': state='string'; verbatim=False; i+=1; continue
        if c=="'": state='char'; i+=1; continue
        if c in '([{': stack.append((c,line))
        elif c in ')]}':
            if not stack or stack[-1][0]!=pairs[c]:
                err(f'Delimiter mismatch in {rel} near line {line}: got {c}')
                return
            stack.pop()
        i+=1
    if state in ('block_comment','string','char'): warn(f'Lexer ended inside {state} in {rel}; manual compiler will be authoritative.')
    if stack:
        err(f'Unclosed delimiter(s) in {rel}: {stack[-5:]}')

for p in ROOT.rglob('*.cs'):
    if any(part in {'bin','obj'} for part in p.parts): continue
    try: delimiter_check(p.read_text(encoding='utf-8', errors='replace'), str(p.relative_to(ROOT)))
    except Exception as e: err(f'Could not inspect {p}: {e}')

# Known API/code anti-patterns caught during earlier iterations.
for p in ROOT.rglob('*.cs'):
    if any(part in {'bin','obj'} for part in p.parts): continue
    text=p.read_text(encoding='utf-8', errors='replace')
    if re.search(r'Convert\.ToHexString\s*\([^)]*,\s*"', text):
        err(f'Invalid Convert.ToHexString overload pattern in {p.relative_to(ROOT)}')
    if 'PauseReminders()' in text and 'PauseRemindersAsync' not in text:
        err(f'Stale PauseReminders() API reference in {p.relative_to(ROOT)}')
    if 'ResumeReminders()' in text and 'ResumeRemindersAsync' not in text:
        err(f'Stale ResumeReminders() API reference in {p.relative_to(ROOT)}')

# Verify SQLite and parser architecture markers.
parser=(ROOT/'Services/WhatsAppParser.cs').read_text(encoding='utf-8')
if 'WhatsAppParserConfigPath' not in parser or 'File.GetLastWriteTimeUtc' not in parser: err('Parser does not appear to auto-reload external configuration.')
if 'RegexOptions' not in parser or 'matchTimeout' not in parser and 'TimeSpan.FromMilliseconds' not in parser: warn('Could not statically confirm regex timeout usage.')
watcher=(ROOT/'Services/WhatsAppWatcherService.cs').read_text(encoding='utf-8')
for marker in ['CancellationToken','SemaphoreSlim','WaitAsync','Task.Delay']:
    if marker not in watcher: err(f'WhatsApp watcher missing async/concurrency marker: {marker}')
nfc=(ROOT/'Services/NfcService.cs').read_text(encoding='utf-8')
for marker in ['ISCardMonitor','CancellationToken','Task.Run','Task.Delay']:
    if marker not in nfc: err(f'NFC service missing expected background/monitor marker: {marker}')
for marker in ['ghosttap://','NdefMessageTlv','BuildModeUri']:
    if marker not in (ROOT/'Services/NfcPayloadService.cs').read_text(encoding='utf-8'): err(f'NFC URI payload marker missing: {marker}')
db=(ROOT/'Services/DatabaseService.cs').read_text(encoding='utf-8')
for marker in ['Microsoft.Data.Sqlite','CREATE TABLE IF NOT EXISTS Tasks','CREATE TABLE IF NOT EXISTS Activities']:
    if marker not in db: err(f'SQLite marker missing: {marker}')

# Ensure project has no generated build output checked into the source release.
for folder in [ROOT/'bin', ROOT/'obj', ROOT/'tests'/'bin', ROOT/'tests'/'obj']:
    if folder.exists(): warn(f'Generated build directory present in source tree: {folder.relative_to(ROOT)}')

print('GhostTap Unified static verification')
print('='*42)
if warnings:
    print('Warnings:')
    for w in warnings: print('  -', w)
if errors:
    print('Errors:')
    for e in errors: print('  -', e)
    print(f'FAILED: {len(errors)} error(s), {len(warnings)} warning(s)')
    sys.exit(1)
print(f'PASSED: 0 errors, {len(warnings)} warning(s)')
