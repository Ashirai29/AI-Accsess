param(
    [string]$PackagePath = "$(Join-Path (Split-Path -Parent $PSScriptRoot) 'out\GhostTap.Unified.msix')",
    [string]$CertificatePath = "$(Join-Path (Split-Path -Parent $PSScriptRoot) 'out\GhostTap-Unified.cer')"
)

$ErrorActionPreference = 'Stop'

if (-not (Test-Path $PackagePath)) { throw "MSIX package not found: $PackagePath" }
if (Test-Path $CertificatePath) {
    Import-Certificate -FilePath $CertificatePath -CertStoreLocation 'Cert:\CurrentUser\TrustedPeople' | Out-Null
}

Add-AppxPackage -Path $PackagePath -ForceApplicationShutdown
Write-Host "GhostTap Unified installed." -ForegroundColor Green
