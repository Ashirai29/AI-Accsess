# Build / reliability notes

## Resolved issues

1. Removed the incompatible `Microsoft.Windows.SDK.NET.Ref` `PackageReference`. The Windows targeting pack must not be installed as a normal project package.
2. `NfcService` uses `ISCardMonitor`, matching `MonitorFactory.Create` in PCSC 7.x.
3. `AutomationService.TryOpenWhatsApp()` remains a `void` action so it can be used by WinForms button/tray callbacks.
4. NFC bind/activate scopes use distinct `pendingMode` / `activeMode` variables.
5. WhatsApp listener permission is requested only through the first-run/explicit access flow.
6. The notification listener is not attempted from an unpackaged process; the app explains that MSIX/package identity is required.
7. `UserNotificationListenerAccessStatus` handling uses only the documented values `Unspecified`, `Allowed`, and `Denied`.

## Verification limitation

This development environment is Linux and does not contain the Windows .NET SDK, Windows SDK, PC/SC service or Windows desktop runtime. Therefore an actual Windows compilation/runtime test cannot be claimed here.

The repository now contains a repeatable Windows verification path:

```powershell
.\\scripts\\Verify.ps1
```

That script is the authoritative local check because it restores the real dependencies, builds the real Windows target and runs the included smoke tests.


## 1.3.2 — duplicate assembly attribute fix
The main app project now uses explicit compile items and does not compile the nested `tests` project source. The smoke-test project also uses explicit compile items. Build/verify scripts delete stale `bin`/`obj` intermediates before restore/build. This prevents duplicate generated `AssemblyInfo`, `TargetFrameworkAttribute`, and `TargetPlatformAttribute` files from leaking into the application build.
