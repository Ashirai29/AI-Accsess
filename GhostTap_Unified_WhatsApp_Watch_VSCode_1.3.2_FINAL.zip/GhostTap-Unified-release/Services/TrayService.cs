using GhostTap.Unified.Models;

namespace GhostTap.Unified.Services;

public sealed class TrayService : IDisposable
{
    private readonly NotifyIcon _notifyIcon;
    private readonly ToolStripMenuItem _pauseItem;
    private readonly Action _showApp;
    private readonly Action _openWhatsApp;
    private readonly Action _exit;
    private readonly Func<bool> _getPaused;
    private readonly Action<bool> _setPaused;

    public bool Paused => _getPaused();

    public TrayService(Action showApp, Action openWhatsApp, Action exit, Func<bool> getPaused, Action<bool> setPaused)
    {
        _showApp = showApp;
        _openWhatsApp = openWhatsApp;
        _exit = exit;
        _getPaused = getPaused;
        _setPaused = setPaused;

        _pauseItem = new ToolStripMenuItem(_getPaused() ? "Resume reminders" : "Pause reminders");
        _pauseItem.Click += (_, _) => TogglePause();

        var menu = new ContextMenuStrip();
        menu.Items.Add("Open GhostTap", null, (_, _) => _showApp());
        menu.Items.Add("Open WhatsApp", null, (_, _) => _openWhatsApp());
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add(_pauseItem);
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Exit", null, (_, _) => _exit());

        _notifyIcon = new NotifyIcon
        {
            Text = "GhostTap Unified",
            Visible = true,
            ContextMenuStrip = menu
        };

        var iconPath = Path.Combine(AppContext.BaseDirectory, "Assets", "GhostTap.ico");
        if (File.Exists(iconPath))
        {
            _notifyIcon.Icon = new Icon(iconPath);
        }

        _notifyIcon.DoubleClick += (_, _) => _showApp();
    }

    public void SetStatus(string title, string text, ToolTipIcon icon = ToolTipIcon.Info)
    {
        _notifyIcon.ShowBalloonTip(5000, title, text, icon);
    }

    public void ShowTaskReminder(GhostTask task)
    {
        var due = task.DueAt.HasValue ? $" Due {task.DueAt.Value.LocalDateTime:g}." : string.Empty;
        SetStatus("GhostTap reminder", $"{task.SourceChat}: {task.Title}.{due}", ToolTipIcon.Warning);
    }

    public void TogglePause()
    {
        _setPaused(!_getPaused());
        RefreshPauseMenu();
    }

    public void RefreshPauseMenu()
    {
        _pauseItem.Text = _getPaused() ? "Resume reminders" : "Pause reminders";
    }

    public void Dispose()
    {
        _notifyIcon.Visible = false;
        _notifyIcon.Dispose();
    }
}
