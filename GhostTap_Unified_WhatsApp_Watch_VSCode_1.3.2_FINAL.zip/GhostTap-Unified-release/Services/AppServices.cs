using GhostTap.Unified.Models;

namespace GhostTap.Unified.Services;

public sealed class AppServices : IAsyncDisposable
{
    public PathService Paths { get; } = new();
    public SettingsService Settings { get; }
    public DatabaseService Database { get; }
    public TaskService Tasks { get; }
    public ActivityService Activities { get; }
    public WhatsAppParser WhatsAppParser { get; }
    public WhatsAppWatcherService WhatsAppWatcher { get; }
    public ReminderService Reminders { get; }
    public NfcService Nfc { get; }
    public StartupService Startup { get; } = new();
    public AutomationService Automation { get; }

    public AppServices()
    {
        Settings = new SettingsService(Paths);
        Database = new DatabaseService(Paths);
        Tasks = new TaskService(Paths, Database);
        Activities = new ActivityService(Paths, Database);
        WhatsAppParser = new WhatsAppParser(Paths);
        Reminders = new ReminderService(Tasks);
        WhatsAppWatcher = new WhatsAppWatcherService(Settings, Tasks, Activities, WhatsAppParser, Paths);
        Automation = new AutomationService(Settings, Reminders);
        Nfc = new NfcService();
    }

    public async Task InitializeAsync()
    {
        await Settings.LoadAsync().ConfigureAwait(false);
        await Database.InitializeAsync(Paths).ConfigureAwait(false);
        await Tasks.LoadAsync().ConfigureAwait(false);
        await Activities.LoadAsync().ConfigureAwait(false);
        Reminders.Paused = Settings.Current.RemindersPaused;
        Reminders.Start();
        Nfc.Start();
    }

    public async Task StartWhatsAppAsync() => await WhatsAppWatcher.StartAsync().ConfigureAwait(false);

    public async ValueTask DisposeAsync()
    {
        await WhatsAppWatcher.DisposeAsync().ConfigureAwait(false);
        await Reminders.DisposeAsync().ConfigureAwait(false);
        await Nfc.StopAsync().ConfigureAwait(false);
        await Database.DisposeAsync().ConfigureAwait(false);
    }
}
