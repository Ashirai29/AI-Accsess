namespace GhostTap.Unified.Services;

public sealed class PathService
{
    public string Root { get; }

    public PathService(string? root = null)
    {
        Root = string.IsNullOrWhiteSpace(root)
            ? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "GhostTapUnified")
            : Path.GetFullPath(root);

        Directory.CreateDirectory(Root);
    }

    public string SettingsPath => Path.Combine(Root, "settings.json");
    public string TasksPath => Path.Combine(Root, "tasks.json");
    public string ActivitiesPath => Path.Combine(Root, "activities.json");
    public string SeenNotificationsPath => Path.Combine(Root, "seen-notifications.json");
    public string DatabasePath => Path.Combine(Root, "GhostTap.db");
    public string WhatsAppParserConfigPath => Path.Combine(Root, "whatsapp-parser.json");
}
