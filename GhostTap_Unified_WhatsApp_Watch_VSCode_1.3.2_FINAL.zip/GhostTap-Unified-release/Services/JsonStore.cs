using System.Text.Json;
using System.Text.Json.Serialization;

namespace GhostTap.Unified.Services;

public sealed class JsonStore<T> where T : class
{
    private readonly string _path;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private readonly JsonSerializerOptions _options = new()
    {
        WriteIndented = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        Converters = { new JsonStringEnumConverter() }
    };

    public JsonStore(string path)
    {
        _path = path;
        var directory = Path.GetDirectoryName(_path);
        if (!string.IsNullOrWhiteSpace(directory))
        {
            Directory.CreateDirectory(directory);
        }
    }

    public async Task<T?> LoadAsync(CancellationToken cancellationToken = default)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            if (!File.Exists(_path))
            {
                return null;
            }

            await using var stream = new FileStream(_path, FileMode.Open, FileAccess.Read, FileShare.Read);
            return await JsonSerializer.DeserializeAsync<T>(stream, _options, cancellationToken);
        }
        catch (JsonException)
        {
            TryBackUpCorruptFile();
            return null;
        }
        catch (IOException)
        {
            return null;
        }
        catch (UnauthorizedAccessException)
        {
            return null;
        }
        finally
        {
            _gate.Release();
        }
    }

    public async Task SaveAsync(T value, CancellationToken cancellationToken = default)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            var temp = _path + ".tmp";
            await using (var stream = new FileStream(temp, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                await JsonSerializer.SerializeAsync(stream, value, _options, cancellationToken);
                await stream.FlushAsync(cancellationToken);
            }

            if (File.Exists(_path))
            {
                File.Replace(temp, _path, _path + ".bak", true);
            }
            else
            {
                File.Move(temp, _path);
            }
        }
        finally
        {
            _gate.Release();
        }
    }

    private void TryBackUpCorruptFile()
    {
        try
        {
            if (File.Exists(_path))
            {
                var backup = _path + ".corrupt-" + DateTimeOffset.Now.ToString("yyyyMMdd-HHmmss");
                File.Move(_path, backup, true);
            }
        }
        catch
        {
            // A corrupt-data backup is best-effort only.
        }
    }
}
