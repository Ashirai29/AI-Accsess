using System.Runtime.InteropServices;
using Windows.ApplicationModel;

namespace GhostTap.Unified.Services;

public static class WindowsAppEnvironment
{
    public static bool IsPackaged
    {
        get
        {
            try
            {
                _ = Package.Current.Id;
                return true;
            }
            catch (COMException)
            {
                return false;
            }
            catch (InvalidOperationException)
            {
                return false;
            }
        }
    }

    public static string PackageDisplayName
    {
        get
        {
            try
            {
                return Package.Current.DisplayName;
            }
            catch
            {
                return string.Empty;
            }
        }
    }

    public static string PackageFullName
    {
        get
        {
            try
            {
                return Package.Current.Id.FullName;
            }
            catch
            {
                return string.Empty;
            }
        }
    }

    public static bool IsSupportedWindowsVersion => Environment.OSVersion.Version.Build >= 19041;
}
