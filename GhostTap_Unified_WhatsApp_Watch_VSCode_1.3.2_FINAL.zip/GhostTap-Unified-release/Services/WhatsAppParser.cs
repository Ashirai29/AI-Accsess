using System.Globalization;
using System.Text.Json;
using System.Text.RegularExpressions;
using GhostTap.Unified.Models;

namespace GhostTap.Unified.Services;

public sealed class WhatsAppParser
{
    private readonly PathService _paths;
    private readonly object _configurationSync = new();
    private WhatsAppParserConfiguration? _configuration;
    private DateTime _configurationWriteTimeUtc = DateTime.MinValue;

    public WhatsAppParser(PathService paths)
    {
        _paths = paths;
    }

    public string ConfigurationPath => _paths.WhatsAppParserConfigPath;
    public string ConfigurationStatus { get; private set; } = "Built-in parser defaults are active.";

    public IReadOnlyList<TaskCandidate> Extract(WhatsAppNotificationItem message, IEnumerable<WhatsAppWatchRule> rules)
    {
        var config = LoadConfiguration();
        var matchingRules = rules
            .Where(r => r.Enabled && r.AutoCreateTasks)
            .Where(r => MatchesChat(message.Chat, r.ChatPattern))
            .Where(r => MatchesContent(message.Body, r))
            .ToList();

        if (matchingRules.Count == 0) return Array.Empty<TaskCandidate>();

        var selectedRule = matchingRules
            .OrderByDescending(r => r.ChatPattern != "*")
            .ThenByDescending(r => r.CaptureAllMessages)
            .ThenByDescending(r => r.TriggerMode == WhatsAppTriggerMode.AnyMessage)
            .ThenBy(r => r.ReminderMinutes)
            .First();

        var titles = ExtractTaskTitles(message.Body, config);
        if (titles.Count == 0) titles.Add(BuildFallbackTitle(message.Body));

        var dueAt = ExtractDueDate(message.Body, message.CreatedAt, config);
        return titles
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .Take(Math.Clamp(config.MaxTaskTitles, 1, 32))
            .Select(title => new TaskCandidate
            {
                Title = title,
                SourceChat = message.Chat,
                SourcePreview = Limit(message.Body, 400),
                DueAt = dueAt,
                ReminderMinutes = Math.Clamp(selectedRule.ReminderMinutes, 5, 1440),
                DetectionKey = HashService.Sha256(
                    "task",
                    message.Chat.Trim(),
                    title.Trim(),
                    dueAt?.ToString("O") ?? $"none:{message.CreatedAt.LocalDateTime:yyyy-MM-dd}")
            })
            .ToList();
    }

    public IReadOnlyList<WhatsAppWatchRule> MatchingRules(WhatsAppNotificationItem message, IEnumerable<WhatsAppWatchRule> rules) => rules
        .Where(r => r.Enabled)
        .Where(r => MatchesChat(message.Chat, r.ChatPattern))
        .Where(r => MatchesContent(message.Body, r))
        .ToList();

    public bool IsWhatsAppAppName(string appName)
    {
        if (string.IsNullOrWhiteSpace(appName)) return false;
        return LoadConfiguration().RecognizedAppNamePatterns.Any(pattern =>
            !string.IsNullOrWhiteSpace(pattern) && appName.Contains(pattern.Trim(), StringComparison.OrdinalIgnoreCase));
    }

    public WhatsAppParserConfiguration GetCurrentConfiguration() => CloneConfiguration(LoadConfiguration());

    public void ReloadConfiguration()
    {
        lock (_configurationSync)
        {
            _configuration = null;
            _configurationWriteTimeUtc = DateTime.MinValue;
        }
        _ = LoadConfiguration();
    }

    private WhatsAppParserConfiguration LoadConfiguration()
    {
        var file = _paths.WhatsAppParserConfigPath;
        var writeTime = File.Exists(file) ? File.GetLastWriteTimeUtc(file) : DateTime.MinValue;
        lock (_configurationSync)
        {
            if (_configuration is not null && writeTime == _configurationWriteTimeUtc) return _configuration;

            try
            {
                EnsureDefaultConfigExists(file);
                var json = File.ReadAllText(file);
                var loaded = JsonSerializer.Deserialize<WhatsAppParserConfiguration>(json, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true,
                    ReadCommentHandling = JsonCommentHandling.Skip,
                    AllowTrailingCommas = true
                });

                if (loaded is null) throw new InvalidDataException("Parser configuration is empty.");
                NormalizeConfiguration(loaded);
                _configuration = loaded;
                _configurationWriteTimeUtc = File.Exists(file) ? File.GetLastWriteTimeUtc(file) : DateTime.UtcNow;
                ConfigurationStatus = $"External parser configuration loaded from {file}.";
            }
            catch (Exception ex)
            {
                _configuration = CreateDefaults();
                _configurationWriteTimeUtc = writeTime;
                ConfigurationStatus = $"Using built-in parser defaults because external configuration could not be loaded: {ex.Message}";
            }

            return _configuration;
        }
    }

    private static void EnsureDefaultConfigExists(string destination)
    {
        if (File.Exists(destination)) return;
        var source = Path.Combine(AppContext.BaseDirectory, "Config", "whatsapp-parser.json");
        if (File.Exists(source))
        {
            Directory.CreateDirectory(Path.GetDirectoryName(destination) ?? AppContext.BaseDirectory);
            File.Copy(source, destination, overwrite: false);
        }
    }

    private static WhatsAppParserConfiguration CreateDefaults() => new()
    {
        RecognizedAppNamePatterns = new() { "WhatsApp", "WhatsApp Beta" },
        Categories = new() { "practical", "assignment", "project", "test", "exam", "quiz", "presentation", "report", "portfolio", "tutorial", "lab", "deliverable", "milestone" },
        NumberWords = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase)
        {
            ["one"] = 1, ["two"] = 2, ["three"] = 3, ["four"] = 4, ["five"] = 5,
            ["six"] = 6, ["seven"] = 7, ["eight"] = 8, ["nine"] = 9, ["ten"] = 10
        },
        MaxTaskTitles = 8,
        MaxQuantityPerCategory = 10,
        DefaultDueTime = "18:00",
        Patterns = CreateDefaultPatterns()
    };

    private static Dictionary<string, string> CreateDefaultPatterns() => new(StringComparer.OrdinalIgnoreCase)
    {
        ["numbered"] = @"\b{category}s?\s*(?:#|number\s*)?(\d+)\b",
        ["paired"] = @"\b{category}s?\s+(\d+)\s*(?:and|&)\s*(\d+)\b",
        ["quantity"] = @"\b([0-9]+|one|two|three|four|five|six|seven|eight|nine|ten)\s+{category}s?\b",
        ["categoryOnly"] = @"\b{category}s?\b",
        ["dayOfWeek"] = @"\b(?:on|by|this|next)?\s*(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b",
        ["isoDate"] = @"\b(20\d{2})[-/](\d{1,2})[-/](\d{1,2})\b",
        ["dayMonth"] = @"\b(\d{1,2})\s*(?:st|nd|rd|th)?[\s/-]+([A-Za-z]{3,9})(?:[\s/-]+(20\d{2}|\d{2}))?\b",
        ["monthFirst"] = @"\b([A-Za-z]{3,9})\s+(\d{1,2})(?:st|nd|rd|th)?(?:,?\s+(20\d{2}|\d{2}))?\b",
        ["slashDate"] = @"\b(\d{1,2})/(\d{1,2})(?:/(20\d{2}|\d{2}))?\b",
        ["timeAt"] = @"\b(?:at|by)\s*(\d{1,2})(?::|h)?(\d{2})?\s*(am|pm)?\b",
        ["timeClock"] = @"\b(\d{1,2})(?::|h)(\d{2})\s*(am|pm)?\b",
        ["timeAmPm"] = @"\b(\d{1,2})\s*(am|pm)\b"
    };

    private static void NormalizeConfiguration(WhatsAppParserConfiguration config)
    {
        config.RecognizedAppNamePatterns ??= new List<string>();
        config.Categories ??= new List<string>();
        config.NumberWords ??= new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        config.Patterns ??= new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        var defaults = CreateDefaults();
        if (config.RecognizedAppNamePatterns.Count == 0) config.RecognizedAppNamePatterns.AddRange(defaults.RecognizedAppNamePatterns);
        if (config.Categories.Count == 0) config.Categories.AddRange(defaults.Categories);
        if (config.NumberWords.Count == 0) config.NumberWords = defaults.NumberWords;

        foreach (var pair in defaults.Patterns)
        {
            if (!config.Patterns.TryGetValue(pair.Key, out var configuredPattern) || string.IsNullOrWhiteSpace(configuredPattern) || !IsSafePattern(configuredPattern))
            {
                config.Patterns[pair.Key] = pair.Value;
            }
        }

        config.RecognizedAppNamePatterns = config.RecognizedAppNamePatterns
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Select(x => x.Trim())
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .Take(32)
            .ToList();
        config.Categories = config.Categories
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Select(x => x.Trim())
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .Take(64)
            .ToList();
        config.NumberWords = config.NumberWords
            .Where(x => !string.IsNullOrWhiteSpace(x.Key) && x.Value is > 0 and <= 50)
            .ToDictionary(x => x.Key.Trim(), x => x.Value, StringComparer.OrdinalIgnoreCase);

        config.MaxTaskTitles = Math.Clamp(config.MaxTaskTitles, 1, 32);
        config.MaxQuantityPerCategory = Math.Clamp(config.MaxQuantityPerCategory, 1, 50);
        if (!TimeSpan.TryParseExact(config.DefaultDueTime, @"hh\:mm", CultureInfo.InvariantCulture, out _)) config.DefaultDueTime = "18:00";
    }

    private static bool IsSafePattern(string pattern)
    {
        try
        {
            _ = new Regex(pattern, RegexOptions.IgnoreCase | RegexOptions.CultureInvariant, TimeSpan.FromMilliseconds(250));
            return true;
        }
        catch (ArgumentException)
        {
            return false;
        }
    }

    private static WhatsAppParserConfiguration CloneConfiguration(WhatsAppParserConfiguration source) => new()
    {
        Version = source.Version,
        RecognizedAppNamePatterns = source.RecognizedAppNamePatterns.ToList(),
        Categories = source.Categories.ToList(),
        NumberWords = new Dictionary<string, int>(source.NumberWords, StringComparer.OrdinalIgnoreCase),
        MaxTaskTitles = source.MaxTaskTitles,
        MaxQuantityPerCategory = source.MaxQuantityPerCategory,
        DefaultDueTime = source.DefaultDueTime,
        Patterns = new Dictionary<string, string>(source.Patterns, StringComparer.OrdinalIgnoreCase)
    };

    private static bool MatchesChat(string chat, string pattern)
    {
        pattern = string.IsNullOrWhiteSpace(pattern) ? "*" : pattern.Trim();
        if (pattern == "*") return true;
        var regex = "^" + Regex.Escape(pattern).Replace("\\*", ".*") + "$";
        return Regex.IsMatch(chat ?? string.Empty, regex, RegexOptions.IgnoreCase | RegexOptions.CultureInvariant, TimeSpan.FromMilliseconds(250));
    }

    private static bool MatchesContent(string body, WhatsAppWatchRule rule)
    {
        if (rule.CaptureAllMessages || rule.TriggerMode == WhatsAppTriggerMode.AnyMessage) return true;
        return rule.Keywords.Any(keyword => !string.IsNullOrWhiteSpace(keyword) && body.Contains(keyword.Trim(), StringComparison.OrdinalIgnoreCase));
    }

    private static List<string> ExtractTaskTitles(string body, WhatsAppParserConfiguration config)
    {
        var titles = new List<string>();
        var lower = body?.ToLowerInvariant() ?? string.Empty;
        foreach (var rawCategory in config.Categories.Distinct(StringComparer.OrdinalIgnoreCase))
        {
            var category = rawCategory.Trim().ToLowerInvariant();
            if (string.IsNullOrWhiteSpace(category)) continue;
            var beforeCategory = titles.Count;

            if (config.Patterns.TryGetValue("numbered", out var numberedPattern))
            {
                var regex = ApplyCategory(numberedPattern, category);
                foreach (Match match in SafeMatches(lower, regex))
                {
                    if (int.TryParse(match.Groups[1].Value, out var number) && number is > 0 and <= 50) titles.Add($"{TitleCase(category)} {number}");
                }
            }

            if (config.Patterns.TryGetValue("paired", out var pairedPattern))
            {
                var regex = ApplyCategory(pairedPattern, category);
                foreach (Match match in SafeMatches(lower, regex))
                {
                    if (int.TryParse(match.Groups[1].Value, out var first) && int.TryParse(match.Groups[2].Value, out var second))
                    {
                        if (first > 0 && first <= 50) titles.Add($"{TitleCase(category)} {first}");
                        if (second > 0 && second <= 50) titles.Add($"{TitleCase(category)} {second}");
                    }
                }
            }

            if (config.Patterns.TryGetValue("quantity", out var quantityPattern))
            {
                var match = SafeMatch(lower, ApplyCategory(quantityPattern, category));
                if (match.Success && match.Groups.Count > 1)
                {
                    var raw = match.Groups[1].Value;
                    var count = config.NumberWords.TryGetValue(raw, out var wordNumber) ? wordNumber : int.TryParse(raw, out var parsed) ? parsed : 1;
                    for (var i = 1; i <= Math.Min(count, config.MaxQuantityPerCategory); i++) titles.Add($"{TitleCase(category)} {i}");
                }
            }

            if (titles.Count == beforeCategory && config.Patterns.TryGetValue("categoryOnly", out var categoryOnly) &&
                SafeIsMatch(lower, ApplyCategory(categoryOnly, category)))
            {
                titles.Add(TitleCase(category));
            }
        }
        return titles;
    }

    private static MatchCollection SafeMatches(string input, string pattern)
    {
        try
        {
            return Regex.Matches(input, pattern, RegexOptions.IgnoreCase | RegexOptions.CultureInvariant, TimeSpan.FromMilliseconds(250));
        }
        catch (ArgumentException)
        {
            return Regex.Matches(string.Empty, @"(?!x)x");
        }
        catch (RegexMatchTimeoutException)
        {
            return Regex.Matches(string.Empty, @"(?!x)x");
        }
    }

    private static Match SafeMatch(string input, string pattern)
    {
        try
        {
            return Regex.Match(input, pattern, RegexOptions.IgnoreCase | RegexOptions.CultureInvariant, TimeSpan.FromMilliseconds(250));
        }
        catch (ArgumentException)
        {
            return Match.Empty;
        }
        catch (RegexMatchTimeoutException)
        {
            return Match.Empty;
        }
    }

    private static bool SafeIsMatch(string input, string pattern)
    {
        try
        {
            return Regex.IsMatch(input, pattern, RegexOptions.IgnoreCase | RegexOptions.CultureInvariant, TimeSpan.FromMilliseconds(250));
        }
        catch (ArgumentException)
        {
            return false;
        }
        catch (RegexMatchTimeoutException)
        {
            return false;
        }
    }

    private static string ApplyCategory(string pattern, string category) => pattern.Replace("{category}", Regex.Escape(category), StringComparison.OrdinalIgnoreCase);

    private static string BuildFallbackTitle(string body)
    {
        var cleaned = Regex.Replace(body?.Trim() ?? string.Empty, @"\s+", " ", RegexOptions.CultureInvariant, TimeSpan.FromMilliseconds(250));
        var firstSentence = Regex.Split(cleaned, @"(?<=[.!?])\s+", RegexOptions.CultureInvariant, TimeSpan.FromMilliseconds(250)).FirstOrDefault() ?? cleaned;
        return string.IsNullOrWhiteSpace(firstSentence) ? "Check WhatsApp message" : Limit(firstSentence, 100);
    }

    private static DateTimeOffset? ExtractDueDate(string body, DateTimeOffset createdAt, WhatsAppParserConfiguration config)
    {
        var text = body?.Trim() ?? string.Empty;
        if (text.Length == 0) return null;

        var now = createdAt.ToLocalTime();
        var lower = text.ToLowerInvariant();
        var defaultTime = TimeSpan.TryParseExact(config.DefaultDueTime, @"hh\:mm", CultureInfo.InvariantCulture, out var parsedDefault)
            ? parsedDefault
            : TimeSpan.FromHours(18);
        var time = ExtractTime(lower, config) ?? defaultTime;

        if (SafeIsMatch(lower, @"\b(today|tonight)\b")) return BuildOffsetDate(now.Date, time, createdAt.Offset);
        if (SafeIsMatch(lower, @"\btomorrow\b")) return BuildOffsetDate(now.Date.AddDays(1), time, createdAt.Offset);

        if (config.Patterns.TryGetValue("dayOfWeek", out var dayPattern))
        {
            var dayMatch = SafeMatch(lower, dayPattern);
            if (dayMatch.Success)
            {
                var target = Enum.Parse<DayOfWeek>(TitleCase(dayMatch.Groups[1].Value));
                var daysAhead = ((int)target - (int)now.DayOfWeek + 7) % 7;
                if (lower.Contains("next " + dayMatch.Groups[1].Value, StringComparison.Ordinal)) daysAhead = daysAhead == 0 ? 7 : daysAhead + 7;
                else if (daysAhead == 0) daysAhead = 7;
                return BuildOffsetDate(now.Date.AddDays(daysAhead), time, createdAt.Offset);
            }
        }

        if (config.Patterns.TryGetValue("isoDate", out var isoPattern))
        {
            var iso = SafeMatch(text, isoPattern);
            if (iso.Success && TryBuildDate(int.Parse(iso.Groups[1].Value), int.Parse(iso.Groups[2].Value), int.Parse(iso.Groups[3].Value), out var isoDate)) return BuildOffsetDate(isoDate.Date, time, createdAt.Offset);
        }

        if (config.Patterns.TryGetValue("dayMonth", out var dayMonthPattern))
        {
            var match = SafeMatch(text, dayMonthPattern);
            var result = BuildMonthDate(now, time, createdAt.Offset, match, dayFirst: true);
            if (result.HasValue) return result;
        }

        if (config.Patterns.TryGetValue("monthFirst", out var monthFirstPattern))
        {
            var match = SafeMatch(text, monthFirstPattern);
            var result = BuildMonthDate(now, time, createdAt.Offset, match, dayFirst: false);
            if (result.HasValue) return result;
        }

        if (config.Patterns.TryGetValue("slashDate", out var slashPattern))
        {
            var slash = SafeMatch(text, slashPattern);
            if (slash.Success)
            {
                var day = int.Parse(slash.Groups[1].Value);
                var month = int.Parse(slash.Groups[2].Value);
                var year = slash.Groups[3].Success ? ToFourDigitYear(slash.Groups[3].Value) : now.Year;
                if (TryBuildDate(year, month, day, out var date))
                {
                    if (!slash.Groups[3].Success && date.Date < now.Date) date = date.AddYears(1);
                    return BuildOffsetDate(date.Date, time, createdAt.Offset);
                }
            }
        }
        return null;
    }

    private static DateTimeOffset? BuildMonthDate(DateTime now, TimeSpan time, TimeSpan offset, Match match, bool dayFirst)
    {
        if (!match.Success) return null;
        var day = int.Parse(dayFirst ? match.Groups[1].Value : match.Groups[2].Value);
        var monthText = dayFirst ? match.Groups[2].Value : match.Groups[1].Value;
        var yearGroup = match.Groups[3];
        var year = yearGroup.Success ? ToFourDigitYear(yearGroup.Value) : now.Year;
        if (!DateTime.TryParseExact($"{day} {monthText} {year}", new[] { "d MMM yyyy", "dd MMM yyyy", "d MMMM yyyy", "dd MMMM yyyy" }, CultureInfo.InvariantCulture, DateTimeStyles.None, out var date)) return null;
        if (!yearGroup.Success && date.Date < now.Date) date = date.AddYears(1);
        return BuildOffsetDate(date.Date, time, offset);
    }

    private static TimeSpan? ExtractTime(string lower, WhatsAppParserConfiguration config)
    {
        Match match = Match.Empty;
        if (config.Patterns.TryGetValue("timeAt", out var timeAt)) match = SafeMatch(lower, timeAt);
        if (!match.Success && config.Patterns.TryGetValue("timeClock", out var timeClock)) match = SafeMatch(lower, timeClock);
        if (!match.Success && config.Patterns.TryGetValue("timeAmPm", out var timeAmPm)) match = SafeMatch(lower, timeAmPm);
        if (!match.Success) return null;

        if (!int.TryParse(match.Groups[1].Value, out var hour)) return null;
        var minute = 0;
        var meridiem = string.Empty;
        if (match.Groups.Count > 2 && match.Groups[2].Success)
        {
            if (match.Groups[2].Value.Equals("am", StringComparison.OrdinalIgnoreCase) || match.Groups[2].Value.Equals("pm", StringComparison.OrdinalIgnoreCase)) meridiem = match.Groups[2].Value;
            else int.TryParse(match.Groups[2].Value, out minute);
        }
        if (match.Groups.Count > 3 && match.Groups[3].Success) meridiem = match.Groups[3].Value;
        if (minute > 59) return null;
        if (meridiem.Equals("pm", StringComparison.OrdinalIgnoreCase) && hour < 12) hour += 12;
        if (meridiem.Equals("am", StringComparison.OrdinalIgnoreCase) && hour == 12) hour = 0;
        return hour is >= 0 and <= 23 ? new TimeSpan(hour, minute, 0) : null;
    }

    private static DateTimeOffset BuildOffsetDate(DateTime date, TimeSpan time, TimeSpan offset) => new(date.Date.Add(time), offset);
    private static int ToFourDigitYear(string value) => value.Length == 2 ? int.Parse("20" + value) : int.Parse(value);
    private static bool TryBuildDate(int year, int month, int day, out DateTime date)
    {
        try { date = new DateTime(year, month, day); return true; }
        catch (ArgumentOutOfRangeException) { date = default; return false; }
    }
    private static string TitleCase(string value) => string.IsNullOrEmpty(value) ? value : char.ToUpperInvariant(value[0]) + value[1..].ToLowerInvariant();
    private static string Limit(string value, int max) => value.Length <= max ? value : value[..Math.Max(0, max - 1)].TrimEnd() + "…";
}
