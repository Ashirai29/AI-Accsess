using GhostTap.Unified.Models;

namespace GhostTap.Unified.Services;

public static class ProtocolCommandService
{
    public static async Task<bool> ExecuteAsync(Uri uri, SettingsService settings, TaskService tasks, AutomationService automation)
    {
        if (!NfcPayloadService.TryValidateGhostTapUri(uri.ToString(), out var valid)) return false;

        var query = ParseQuery(valid.Query);
        var action = query.TryGetValue("action", out var actionValue) ? actionValue : string.Empty;
        var modeId = query.TryGetValue("mode", out var modeValue) ? modeValue : action;

        if (string.IsNullOrWhiteSpace(action) && string.IsNullOrWhiteSpace(modeId)) return false;

        switch (action.ToLowerInvariant())
        {
            case "open-whatsapp":
                AutomationService.TryOpenWhatsApp();
                return true;
            case "pause":
                await automation.PauseRemindersAsync().ConfigureAwait(false);
                return true;
            case "resume":
                await automation.ResumeRemindersAsync().ConfigureAwait(false);
                return true;
            case "study":
            case "coding":
            case "gaming":
            case "sleep":
                modeId = action;
                break;
        }

        var mode = settings.GetMode(modeId);
        if (mode is null) return false;
        await automation.RunModeAsync(mode.Id).ConfigureAwait(false);
        return true;
    }

    public static string BuildModeUri(string modeId) => NfcPayloadService.BuildModeUri(modeId);

    private static Dictionary<string, string> ParseQuery(string query)
    {
        var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        var raw = query.TrimStart('?');
        if (raw.Length == 0) return result;

        foreach (var part in raw.Split('&', StringSplitOptions.RemoveEmptyEntries))
        {
            var separator = part.IndexOf('=');
            var key = separator < 0 ? part : part[..separator];
            var value = separator < 0 ? string.Empty : part[(separator + 1)..];
            try
            {
                key = Uri.UnescapeDataString(key.Replace('+', ' ')).Trim();
                value = Uri.UnescapeDataString(value.Replace('+', ' ')).Trim();
            }
            catch (UriFormatException)
            {
                continue;
            }
            if (!string.IsNullOrWhiteSpace(key)) result[key] = value;
        }
        return result;
    }
}
