using GhostTap.Unified.Models;

namespace GhostTap.Unified.Services;

public sealed class ReminderService : IAsyncDisposable
{
    private readonly TaskService _tasks;
    private CancellationTokenSource? _cts;
    private Task? _loop;
    private readonly object _sync = new();
    private bool _paused;

    public event EventHandler<GhostTask>? ReminderRaised;
    public bool Paused
    {
        get { lock (_sync) return _paused; }
        set { lock (_sync) _paused = value; }
    }

    public ReminderService(TaskService tasks) => _tasks = tasks;

    public void Start()
    {
        if (_loop is not null) return;
        _cts = new CancellationTokenSource();
        _loop = Task.Run(() => LoopAsync(_cts.Token));
    }

    public async Task StopAsync()
    {
        _cts?.Cancel();
        if (_loop is not null)
        {
            try { await _loop; } catch (OperationCanceledException) { }
        }
        _loop = null;
        _cts?.Dispose();
        _cts = null;
    }

    public async ValueTask DisposeAsync() => await StopAsync();

    private async Task LoopAsync(CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            if (!Paused)
            {
                var now = DateTimeOffset.Now;
                foreach (var task in _tasks.GetOpen()
                             .Where(x => x.NextReminderAt.HasValue && x.NextReminderAt <= now)
                             .Take(5))
                {
                    await _tasks.MarkRemindedAsync(task.Id);
                    var refreshed = _tasks.Get(task.Id);
                    if (refreshed is not null && refreshed.Status == GhostTaskStatus.Open)
                    {
                        ReminderRaised?.Invoke(this, refreshed);
                    }
                }
            }

            await Task.Delay(TimeSpan.FromSeconds(20), cancellationToken);
        }
    }
}
