using System.Text;

namespace GhostTap.Unified.Services;

/// <summary>
/// Builds and parses compact NFC Forum URI NDEF messages. GhostTap stores a tiny
/// command URI on the tag instead of attempting to store application binaries.
/// </summary>
public static class NfcPayloadService
{
    public const string Scheme = "ghosttap";
    public const int ConservativeType2CapacityBytes = 144;
    private const byte NdefMessageTlv = 0x03;
    private const byte TerminatorTlv = 0xFE;
    private const byte UriRecordType = 0x55;

    public static string BuildModeUri(string modeId)
    {
        if (string.IsNullOrWhiteSpace(modeId)) throw new ArgumentException("A mode id is required.", nameof(modeId));
        var trimmed = modeId.Trim();
        if (trimmed.Length > 120) throw new ArgumentException("The mode id is too long for a compact NFC command.", nameof(modeId));
        return $"{Scheme}://trigger?action={Uri.EscapeDataString(trimmed)}";
    }

    public static byte[] BuildType2NdefTlv(string uri)
    {
        if (!TryValidateGhostTapUri(uri, out var parsed))
        {
            throw new ArgumentException("Only a valid ghosttap:// command URI can be written to a GhostTap tag.", nameof(uri));
        }

        var uriText = parsed.AbsoluteUri;
        var uriBytes = Encoding.UTF8.GetBytes(uriText);
        var uriPayload = new byte[uriBytes.Length + 1];
        uriPayload[0] = 0x00; // NFC Forum URI Record prefix 0 = no abbreviation.
        Buffer.BlockCopy(uriBytes, 0, uriPayload, 1, uriBytes.Length);

        if (uriPayload.Length > byte.MaxValue)
        {
            throw new ArgumentException("The GhostTap URI is too long for a short NDEF URI record.", nameof(uri));
        }

        // MB=1, ME=1, SR=1, TNF=Well-known(0x01) => 0xD1.
        var record = new byte[4 + uriPayload.Length];
        record[0] = 0xD1;
        record[1] = 0x01; // type length
        record[2] = (byte)uriPayload.Length;
        record[3] = UriRecordType; // 'U'
        Buffer.BlockCopy(uriPayload, 0, record, 4, uriPayload.Length);

        return BuildShortTlv(record);
    }

    public static string ToHex(byte[] bytes) => string.Join(" ", bytes.Select(static b => b.ToString("X2")));

    public static bool TryParseGhostTapUri(ReadOnlySpan<byte> tagMemory, out Uri? uri)
    {
        uri = null;
        var index = 0;

        while (index < tagMemory.Length)
        {
            var type = tagMemory[index++];
            if (type == 0x00) continue; // NULL TLV
            if (type == TerminatorTlv) break;
            if (index >= tagMemory.Length) break;

            if (!TryReadTlvLength(tagMemory, ref index, out var length)) break;
            if (length < 0 || index + length > tagMemory.Length) break;

            var value = tagMemory.Slice(index, length);
            index += length;

            if (type != NdefMessageTlv || value.Length < 4) continue;
            if (!TryExtractUriRecord(value, out var uriText)) continue;
            if (TryValidateGhostTapUri(uriText, out var parsed))
            {
                uri = parsed;
                return true;
            }
        }

        return false;
    }

    public static bool TryValidateGhostTapUri(string value, out Uri uri)
    {
        uri = null!;
        if (string.IsNullOrWhiteSpace(value)) return false;
        if (!Uri.TryCreate(value.Trim(), UriKind.Absolute, out var parsed)) return false;
        if (!string.Equals(parsed.Scheme, Scheme, StringComparison.OrdinalIgnoreCase)) return false;
        if (!string.Equals(parsed.Host, "trigger", StringComparison.OrdinalIgnoreCase)) return false;
        if (parsed.AbsolutePath != "/") return false;

        var hasCommand = false;
        foreach (var pair in parsed.Query.TrimStart('?').Split('&', StringSplitOptions.RemoveEmptyEntries))
        {
            var separator = pair.IndexOf('=');
            var key = separator >= 0 ? pair[..separator] : pair;
            if (key.Equals("action", StringComparison.OrdinalIgnoreCase) || key.Equals("mode", StringComparison.OrdinalIgnoreCase))
            {
                hasCommand = true;
                break;
            }
        }

        if (!hasCommand) return false;
        uri = parsed;
        return true;
    }

    private static byte[] BuildShortTlv(byte[] record)
    {
        if (record.Length > byte.MaxValue) throw new ArgumentException("The NDEF record is too large for a short TLV.", nameof(record));
        var tlv = new byte[3 + record.Length];
        tlv[0] = NdefMessageTlv;
        tlv[1] = (byte)record.Length;
        Buffer.BlockCopy(record, 0, tlv, 2, record.Length);
        tlv[^1] = TerminatorTlv;
        return tlv;
    }

    private static bool TryReadTlvLength(ReadOnlySpan<byte> data, ref int index, out int length)
    {
        length = 0;
        if (index >= data.Length) return false;
        var first = data[index++];
        if (first != 0xFF)
        {
            length = first;
            return true;
        }

        if (index + 2 > data.Length) return false;
        length = (data[index] << 8) | data[index + 1];
        index += 2;
        return true;
    }

    private static bool TryExtractUriRecord(ReadOnlySpan<byte> message, out string uri)
    {
        uri = string.Empty;
        if (message.Length < 4) return false;

        var header = message[0];
        var typeLength = message[1];
        var payloadLength = message[2];
        if ((header & 0xC0) != 0xC0 || typeLength != 1 || message[3] != UriRecordType) return false;
        if (4 + payloadLength > message.Length || payloadLength < 1) return false;

        var payload = message.Slice(4, payloadLength);
        if (payload[0] != 0x00) return false; // GhostTap intentionally uses a custom, un-abbreviated URI scheme.
        uri = Encoding.UTF8.GetString(payload.Slice(1));
        return !string.IsNullOrWhiteSpace(uri);
    }
}
