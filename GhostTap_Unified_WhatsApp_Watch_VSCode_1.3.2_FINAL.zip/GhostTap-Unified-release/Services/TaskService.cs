using GhostTap.Unified.Models;

namespace GhostTap.Unified.Services;

public sealed class TaskService
{
    private readonly JsonStore<List<GhostTask>> _legacyStore;
    private readonly DatabaseService _database;
    private readonly object _sync = new();
    private List<GhostTask> _tasks = new();

    public event EventHandler? TasksChanged;

    public TaskService(PathService paths, DatabaseService database)
    {
        _legacyStore = new JsonStore<List<GhostTask>>(paths.TasksPath);
        _database = database;
    }

    public async Task LoadAsync()
    {
        _tasks = _database.IsAvailable
            ? await _database.GetTasksAsync().ConfigureAwait(false)
            : await _legacyStore.LoadAsync().ConfigureAwait(false) ?? new List<GhostTask>();

        lock (_sync)
        {
            foreach (var task in _tasks)
            {
                task.ReminderMinutes = Math.Clamp(task.ReminderMinutes, 5, 1440);
                task.Occurrences = Math.Max(1, task.Occurrences);
                if (task.Status == GhostTaskStatus.Done)
                {
                    task.NextReminderAt = null;
                }
                else if (!task.NextReminderAt.HasValue)
                {
                    task.NextReminderAt = DateTimeOffset.Now.AddMinutes(task.ReminderMinutes);
                }
            }
        }
    }

    public IReadOnlyList<GhostTask> GetAll()
    {
        lock (_sync)
        {
            return _tasks
                .OrderBy(x => x.Status)
                .ThenBy(x => x.DueAt ?? DateTimeOffset.MaxValue)
                .ThenByDescending(x => x.CreatedAt)
                .Select(Clone)
                .ToList();
        }
    }

    public IReadOnlyList<GhostTask> GetOpen()
    {
        lock (_sync)
        {
            return _tasks
                .Where(x => x.Status == GhostTaskStatus.Open)
                .OrderBy(x => x.DueAt ?? DateTimeOffset.MaxValue)
                .ThenByDescending(x => x.CreatedAt)
                .Select(Clone)
                .ToList();
        }
    }

    public GhostTask? Get(string id)
    {
        lock (_sync)
        {
            return _tasks.FirstOrDefault(x => x.Id.Equals(id, StringComparison.OrdinalIgnoreCase)) is { } task ? Clone(task) : null;
        }
    }

    public async Task<GhostTask> AddCandidateAsync(TaskCandidate candidate)
    {
        if (string.IsNullOrWhiteSpace(candidate.Title)) throw new ArgumentException("A task title is required.", nameof(candidate));

        GhostTask created;
        lock (_sync)
        {
            var duplicate = _tasks.FirstOrDefault(x =>
                x.DetectionKey.Equals(candidate.DetectionKey, StringComparison.OrdinalIgnoreCase) &&
                x.SourceChat.Equals(candidate.SourceChat, StringComparison.OrdinalIgnoreCase));

            if (duplicate is not null)
            {
                duplicate.Occurrences++;
                if (string.IsNullOrWhiteSpace(duplicate.SourcePreview)) duplicate.SourcePreview = candidate.SourcePreview?.Trim() ?? string.Empty;
                if (!duplicate.DueAt.HasValue && candidate.DueAt.HasValue) duplicate.DueAt = candidate.DueAt;
                created = Clone(duplicate);
            }
            else
            {
                var reminderMinutes = Math.Clamp(candidate.ReminderMinutes, 5, 1440);
                created = new GhostTask
                {
                    Title = candidate.Title.Trim(),
                    SourceChat = candidate.SourceChat?.Trim() ?? string.Empty,
                    SourcePreview = candidate.SourcePreview?.Trim() ?? string.Empty,
                    DueAt = candidate.DueAt,
                    ReminderMinutes = reminderMinutes,
                    NextReminderAt = DateTimeOffset.Now.AddMinutes(reminderMinutes),
                    DetectionKey = candidate.DetectionKey ?? string.Empty,
                    Status = GhostTaskStatus.Open,
                    Occurrences = 1
                };
                _tasks.Add(created);
            }
        }

        await PersistTaskAsync(created).ConfigureAwait(false);
        return Clone(created);
    }

    public async Task CompleteAsync(string id)
    {
        GhostTask? task;
        lock (_sync)
        {
            task = _tasks.FirstOrDefault(x => x.Id.Equals(id, StringComparison.OrdinalIgnoreCase));
            if (task is null) return;
            task.Status = GhostTaskStatus.Done;
            task.LastReminderAt = DateTimeOffset.Now;
            task.NextReminderAt = null;
        }
        await PersistTaskAsync(task).ConfigureAwait(false);
    }

    public async Task ReopenAsync(string id)
    {
        GhostTask? task;
        lock (_sync)
        {
            task = _tasks.FirstOrDefault(x => x.Id.Equals(id, StringComparison.OrdinalIgnoreCase));
            if (task is null) return;
            task.Status = GhostTaskStatus.Open;
            task.NextReminderAt = DateTimeOffset.Now.AddMinutes(Math.Clamp(task.ReminderMinutes, 5, 1440));
        }
        await PersistTaskAsync(task).ConfigureAwait(false);
    }

    public async Task SnoozeAsync(string id, TimeSpan duration)
    {
        if (duration < TimeSpan.FromMinutes(1)) duration = TimeSpan.FromMinutes(1);
        if (duration > TimeSpan.FromDays(7)) duration = TimeSpan.FromDays(7);

        GhostTask? task;
        lock (_sync)
        {
            task = _tasks.FirstOrDefault(x => x.Id.Equals(id, StringComparison.OrdinalIgnoreCase));
            if (task is null || task.Status == GhostTaskStatus.Done) return;
            task.NextReminderAt = DateTimeOffset.Now.Add(duration);
        }
        await PersistTaskAsync(task).ConfigureAwait(false);
    }

    public async Task MarkRemindedAsync(string id)
    {
        GhostTask? task;
        lock (_sync)
        {
            task = _tasks.FirstOrDefault(x => x.Id.Equals(id, StringComparison.OrdinalIgnoreCase));
            if (task is null || task.Status == GhostTaskStatus.Done) return;
            task.LastReminderAt = DateTimeOffset.Now;
            task.NextReminderAt = DateTimeOffset.Now.AddMinutes(GetEffectiveReminderMinutes(task));
        }
        await PersistTaskAsync(task).ConfigureAwait(false);
    }

    public async Task DeleteAsync(string id)
    {
        var removed = false;
        lock (_sync) removed = _tasks.RemoveAll(x => x.Id.Equals(id, StringComparison.OrdinalIgnoreCase)) > 0;
        if (!removed) return;

        if (_database.IsAvailable) await _database.DeleteTaskAsync(id).ConfigureAwait(false);
        else await PersistLegacyAsync().ConfigureAwait(false);
        TasksChanged?.Invoke(this, EventArgs.Empty);
    }

    private static int GetEffectiveReminderMinutes(GhostTask task)
    {
        var configured = Math.Clamp(task.ReminderMinutes, 5, 1440);
        if (!task.DueAt.HasValue) return configured;
        var untilDue = task.DueAt.Value - DateTimeOffset.Now;
        if (untilDue <= TimeSpan.Zero) return Math.Min(configured, 20);
        if (untilDue <= TimeSpan.FromHours(3)) return Math.Min(configured, 30);
        if (untilDue <= TimeSpan.FromDays(1)) return Math.Min(configured, 60);
        return configured;
    }

    private async Task PersistTaskAsync(GhostTask task)
    {
        if (_database.IsAvailable) await _database.UpsertTaskAsync(task).ConfigureAwait(false);
        else await PersistLegacyAsync().ConfigureAwait(false);
        TasksChanged?.Invoke(this, EventArgs.Empty);
    }

    private async Task PersistLegacyAsync()
    {
        List<GhostTask> snapshot;
        lock (_sync) snapshot = _tasks.Select(Clone).ToList();
        await _legacyStore.SaveAsync(snapshot).ConfigureAwait(false);
    }

    private static GhostTask Clone(GhostTask task) => new()
    {
        Id = task.Id,
        Title = task.Title,
        SourceChat = task.SourceChat,
        SourcePreview = task.SourcePreview,
        CreatedAt = task.CreatedAt,
        DueAt = task.DueAt,
        Status = task.Status,
        LastReminderAt = task.LastReminderAt,
        NextReminderAt = task.NextReminderAt,
        ReminderMinutes = task.ReminderMinutes,
        DetectionKey = task.DetectionKey,
        Occurrences = task.Occurrences
    };
}
