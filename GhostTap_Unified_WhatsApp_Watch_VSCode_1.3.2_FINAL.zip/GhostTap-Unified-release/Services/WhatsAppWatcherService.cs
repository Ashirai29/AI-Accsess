using System.Text.RegularExpressions;
using Windows.UI.Notifications;
using Windows.UI.Notifications.Management;
using GhostTap.Unified.Models;

namespace GhostTap.Unified.Services;

public sealed class WhatsAppWatcherService : IAsyncDisposable
{
    private readonly SettingsService _settings;
    private readonly TaskService _tasks;
    private readonly ActivityService _activities;
    private readonly WhatsAppParser _parser;
    private readonly JsonStore<List<string>> _seenStore;
    private readonly HashSet<string> _seenKeys = new(StringComparer.OrdinalIgnoreCase);
    private readonly object _seenSync = new();
    private readonly SemaphoreSlim _processingGate = new(1, 1);
    private readonly SemaphoreSlim _syncGate = new(1, 1);
    private CancellationTokenSource? _cts;
    private Task? _loopTask;
    private UserNotificationListener? _listener;
    private bool _enabled;
    private bool _subscribed;

    public event EventHandler<string>? StatusChanged;
    public event EventHandler<WhatsAppNotificationItem>? MessageCaptured;
    public event EventHandler<TaskCandidate>? TaskCandidateDetected;

    public string Status { get; private set; } = "Not connected.";
    public UserNotificationListenerAccessStatus AccessStatus { get; private set; } = UserNotificationListenerAccessStatus.Unspecified;
    public DateTimeOffset? LastNotificationAt { get; private set; }
    public string LastChat { get; private set; } = string.Empty;
    public string LastMessage { get; private set; } = string.Empty;
    public int CapturedCount { get; private set; }
    public bool IsRunning => _loopTask is not null;
    public bool IsReady => IsRunning && AccessStatus == UserNotificationListenerAccessStatus.Allowed;
    public bool RequiresPackageIdentity => !WindowsAppEnvironment.IsPackaged;

    public WhatsAppWatcherService(
        SettingsService settings,
        TaskService tasks,
        ActivityService activities,
        WhatsAppParser parser,
        PathService paths)
    {
        _settings = settings;
        _tasks = tasks;
        _activities = activities;
        _parser = parser;
        _seenStore = new JsonStore<List<string>>(paths.SeenNotificationsPath);
    }

    public async Task<bool> RequestAccessAsync()
    {
        if (!WindowsAppEnvironment.IsPackaged)
        {
            AccessStatus = UserNotificationListenerAccessStatus.Unspecified;
            SetStatus("WhatsApp Watch requires the installed MSIX version so Windows can grant notification access.");
            return false;
        }

        if (!WindowsAppEnvironment.IsSupportedWindowsVersion)
        {
            SetStatus("This Windows build is below the supported minimum for notification listening.");
            return false;
        }

        try
        {
            _listener ??= UserNotificationListener.Current;
            AccessStatus = _listener.GetAccessStatus();
            if (AccessStatus != UserNotificationListenerAccessStatus.Allowed)
            {
                AccessStatus = await _listener.RequestAccessAsync();
            }

            if (AccessStatus == UserNotificationListenerAccessStatus.Allowed)
            {
                SetStatus("Notification access granted.");
                await StartAsync();
                await SyncNowAsync(initialSync: false);
                return true;
            }

            SetStatus(GetAccessStatusMessage(AccessStatus));
            return false;
        }
        catch (Exception ex)
        {
            SetStatus($"Could not request notification access: {ex.Message}");
            return false;
        }
    }

    public UserNotificationListenerAccessStatus GetAccessStatus()
    {
        if (!WindowsAppEnvironment.IsPackaged)
        {
            AccessStatus = UserNotificationListenerAccessStatus.Unspecified;
            return AccessStatus;
        }

        try
        {
            _listener ??= UserNotificationListener.Current;
            AccessStatus = _listener.GetAccessStatus();
            return AccessStatus;
        }
        catch
        {
            AccessStatus = UserNotificationListenerAccessStatus.Unspecified;
            return AccessStatus;
        }
    }

    public async Task StartAsync(bool requestAccess = false)
    {
        if (!_settings.Current.WhatsAppEnabled)
        {
            SetStatus("WhatsApp Watch is disabled in Settings.");
            return;
        }

        if (_loopTask is not null)
        {
            return;
        }

        if (!WindowsAppEnvironment.IsPackaged)
        {
            SetStatus("WhatsApp Watch is ready to configure, but the installed MSIX version is required for notification access.");
            return;
        }

        if (!WindowsAppEnvironment.IsSupportedWindowsVersion)
        {
            SetStatus("Unsupported Windows version for notification listening.");
            return;
        }

        try
        {
            await _seenStoreLoadAsync();
            _listener ??= UserNotificationListener.Current;
            AccessStatus = _listener.GetAccessStatus();
            if (AccessStatus != UserNotificationListenerAccessStatus.Allowed && requestAccess)
            {
                AccessStatus = await _listener.RequestAccessAsync();
            }

            _cts = new CancellationTokenSource();
            _loopTask = Task.Run(() => PollLoopAsync(_cts.Token));

            if (AccessStatus == UserNotificationListenerAccessStatus.Allowed)
            {
                SubscribeToChanges();
                await SyncNowAsync(initialSync: true);
                SetStatus("WhatsApp Watch is connected and waiting for notifications.");
            }
            else
            {
                SetStatus(GetAccessStatusMessage(AccessStatus) + " GhostTap will keep checking while it is running.");
            }
        }
        catch (Exception ex)
        {
            SetStatus($"WhatsApp Watch could not start: {ex.Message}");
            await StopAsync();
        }
    }

    public async Task StopAsync()
    {
        _cts?.Cancel();
        if (_loopTask is not null)
        {
            try { await _loopTask; } catch (OperationCanceledException) { }
        }

        UnsubscribeFromChanges();
        _loopTask = null;
        _cts?.Dispose();
        _cts = null;
        SetStatus("WhatsApp Watch stopped.");
    }

    public async Task<bool> RefreshNowAsync()
    {
        if (_listener is null)
        {
            GetAccessStatus();
        }

        if (AccessStatus != UserNotificationListenerAccessStatus.Allowed)
        {
            SetStatus(GetAccessStatusMessage(AccessStatus));
            return false;
        }

        try
        {
            await SyncNowAsync(initialSync: false);
            SetStatus("WhatsApp notifications refreshed.");
            return true;
        }
        catch (Exception ex)
        {
            SetStatus($"WhatsApp refresh failed: {ex.Message}");
            return false;
        }
    }

    public async Task ProcessSyntheticMessageAsync(string chat, string body)
    {
        var item = new WhatsAppNotificationItem
        {
            AppName = "WhatsApp (Test)",
            Chat = string.IsNullOrWhiteSpace(chat) ? "Test chat" : chat.Trim(),
            Body = body?.Trim() ?? string.Empty,
            CreatedAt = DateTimeOffset.Now,
            NotificationKey = HashService.Sha256("synthetic", chat ?? string.Empty, body ?? string.Empty)
        };

        await ProcessNotificationAsync(item);
    }

    private async Task _seenStoreLoadAsync()
    {
        var seen = await _seenStore.LoadAsync() ?? new List<string>();
        lock (_seenSync)
        {
            _seenKeys.Clear();
            foreach (var key in seen.TakeLast(4000))
            {
                _seenKeys.Add(key);
            }
        }
    }

    private async Task PollLoopAsync(CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            try
            {
                if (_listener is not null)
                {
                    AccessStatus = _listener.GetAccessStatus();
                }

                if (AccessStatus == UserNotificationListenerAccessStatus.Allowed)
                {
                    SubscribeToChanges();
                    await SyncNowAsync(initialSync: false, cancellationToken);
                    if (!string.Equals(Status, "WhatsApp Watch is connected and waiting for notifications.", StringComparison.Ordinal))
                    {
                        SetStatus("WhatsApp Watch is connected and waiting for notifications.");
                    }
                }
                else
                {
                    UnsubscribeFromChanges();
                    SetStatus(GetAccessStatusMessage(AccessStatus) + " GhostTap will keep checking while it is running.");
                }
            }
            catch (UnauthorizedAccessException)
            {
                SetStatus("Windows denied notification access. Check Notification access in Windows Settings.");
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                SetStatus($"WhatsApp sync warning: {ex.Message}");
            }

            await Task.Delay(TimeSpan.FromSeconds(Math.Clamp(_settings.Current.WhatsAppPollSeconds, 15, 120)), cancellationToken);
        }
    }

    private async Task SyncNowAsync(bool initialSync, CancellationToken cancellationToken = default)
    {
        if (_listener is null || AccessStatus != UserNotificationListenerAccessStatus.Allowed)
        {
            return;
        }

        await _syncGate.WaitAsync(cancellationToken);
        try
        {
            var notifications = await _listener.GetNotificationsAsync(NotificationKinds.Toast);
            var cutoff = DateTimeOffset.Now.AddMinutes(-Math.Clamp(_settings.Current.NotificationCatchUpMinutes, 1, 60));
            foreach (var notification in notifications.OrderBy(x => x.CreationTime))
            {
                cancellationToken.ThrowIfCancellationRequested();
                var item = TryReadNotification(notification);
                if (item is null)
                {
                    continue;
                }

                if (initialSync && item.CreatedAt < cutoff)
                {
                    continue;
                }

                if (!TryMarkSeen(item.NotificationKey))
                {
                    continue;
                }

                await ProcessNotificationAsync(item);
            }

            await PersistSeenAsync();
        }
        finally
        {
            _syncGate.Release();
        }
    }

    private async Task ProcessNotificationAsync(WhatsAppNotificationItem item)
    {
        await _processingGate.WaitAsync();
        try
        {
            LastNotificationAt = item.CreatedAt;
            LastChat = item.Chat;
            LastMessage = item.Body;
            CapturedCount++;
            MessageCaptured?.Invoke(this, item);

            var matches = _parser.MatchingRules(item, _settings.Current.WhatsAppRules);
            if (matches.Count == 0)
            {
                return;
            }

            var candidates = _parser.Extract(item, matches);
            if (matches.Any(r => r.RecordActivity || r.CaptureAllMessages))
            {
                await _activities.AddAsync(new WhatsAppActivity
                {
                    Chat = item.Chat,
                    Sender = item.Sender,
                    Preview = item.Body,
                    CreatedAt = item.CreatedAt,
                    NotificationKey = item.NotificationKey,
                    GeneratedTask = candidates.Count > 0,
                    IsHandled = false
                });
            }

            foreach (var candidate in candidates)
            {
                TaskCandidateDetected?.Invoke(this, candidate);
                await _tasks.AddCandidateAsync(candidate);
            }
        }
        finally
        {
            _processingGate.Release();
        }
    }

    private WhatsAppNotificationItem? TryReadNotification(UserNotification notification)
    {
        try
        {
            var displayName = notification.AppInfo?.DisplayInfo?.DisplayName ?? string.Empty;
            if (!_parser.IsWhatsAppAppName(displayName))
            {
                return null;
            }

            var binding = notification.Notification.Visual.GetBinding(KnownNotificationBindings.ToastGeneric);
            if (binding is null)
            {
                return null;
            }

            var texts = binding.GetTextElements()
                .Select(x => x.Text?.Trim() ?? string.Empty)
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .ToList();

            if (texts.Count == 0)
            {
                return null;
            }

            var (chat, sender, body) = ParseNotificationText(texts);
            var createdAt = notification.CreationTime;
            var key = HashService.Sha256(displayName, notification.Id.ToString(), createdAt.ToString("O"), string.Join("\u001f", texts));

            return new WhatsAppNotificationItem
            {
                AppName = displayName,
                Chat = chat,
                Sender = sender,
                Body = body,
                CreatedAt = createdAt,
                NotificationId = notification.Id,
                NotificationKey = key
            };
        }
        catch
        {
            return null;
        }
    }

    private static (string Chat, string Sender, string Body) ParseNotificationText(IReadOnlyList<string> texts)
    {
        if (texts.Count >= 3)
        {
            return (texts[0], texts[1], string.Join(" — ", texts.Skip(2)));
        }

        if (texts.Count == 2)
        {
            var split = Regex.Match(texts[1], @"^([^:]{1,60}):\s*(.+)$");
            if (split.Success)
            {
                return (texts[0], split.Groups[1].Value.Trim(), split.Groups[2].Value.Trim());
            }

            return (texts[0], string.Empty, texts[1]);
        }

        var single = Regex.Match(texts[0], @"^([^:]{1,80}):\s*(.+)$");
        return single.Success
            ? (single.Groups[1].Value.Trim(), string.Empty, single.Groups[2].Value.Trim())
            : (texts[0], string.Empty, string.Empty);
    }

    private bool TryMarkSeen(string key)
    {
        lock (_seenSync)
        {
            return _seenKeys.Add(key);
        }
    }

    private async Task PersistSeenAsync()
    {
        List<string> values;
        lock (_seenSync)
        {
            values = _seenKeys.TakeLast(4000).ToList();
        }

        await _seenStore.SaveAsync(values);
    }

    private void SubscribeToChanges()
    {
        if (_listener is null || _subscribed)
        {
            return;
        }

        _listener.NotificationChanged += Listener_NotificationChanged;
        _subscribed = true;
    }

    private void UnsubscribeFromChanges()
    {
        if (_listener is null || !_subscribed)
        {
            return;
        }

        try { _listener.NotificationChanged -= Listener_NotificationChanged; } catch { }
        _subscribed = false;
    }

    private void Listener_NotificationChanged(UserNotificationListener sender, UserNotificationChangedEventArgs args)
    {
        _ = RefreshFromEventAsync();
    }

    private async Task RefreshFromEventAsync()
    {
        try
        {
            await SyncNowAsync(initialSync: false);
        }
        catch
        {
            // The next periodic poll remains the safety net.
        }
    }

    private void SetStatus(string value)
    {
        Status = value;
        StatusChanged?.Invoke(this, value);
    }

    private static string GetAccessStatusMessage(UserNotificationListenerAccessStatus status) => status switch
    {
        UserNotificationListenerAccessStatus.Allowed => "Notification access granted.",
        UserNotificationListenerAccessStatus.Denied => "Windows notification access is denied. Open Windows Settings and allow GhostTap.",
        UserNotificationListenerAccessStatus.Unspecified => "Notification access has not been granted yet.",
        _ => $"Notification access status: {status}."
    };

    public async ValueTask DisposeAsync()
    {
        await StopAsync();
        _processingGate.Dispose();
        _syncGate.Dispose();
    }
}
