using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;
using GhostTap.Unified.Models;

namespace GhostTap.Unified.Services;

public static class ProtocolActivationService
{
    public static bool TryGetUri(out Uri? uri)
    {
        uri = null;
        if (!WindowsAppEnvironment.IsPackaged) return false;

        try
        {
            var args = AppInstance.GetActivatedEventArgs();
            if (args.Kind != ActivationKind.Protocol) return false;
            var protocolArgs = args as ProtocolActivatedEventArgs;
            if (protocolArgs?.Uri is null) return false;
            if (!NfcPayloadService.TryValidateGhostTapUri(protocolArgs.Uri.ToString(), out var valid)) return false;
            uri = valid;
            return true;
        }
        catch
        {
            return false;
        }
    }

    public static async Task<int> HandleAsync(Uri uri)
    {
        try
        {
            var paths = new PathService();
            var settings = new SettingsService(paths);
            var database = new DatabaseService(paths);
            var tasks = new TaskService(paths, database);
            var reminders = new ReminderService(tasks);
            var automation = new AutomationService(settings, reminders);

            await settings.LoadAsync().ConfigureAwait(false);
            await database.InitializeAsync(paths).ConfigureAwait(false);
            await tasks.LoadAsync().ConfigureAwait(false);

            var executed = await ProtocolCommandService.ExecuteAsync(uri, settings, tasks, automation).ConfigureAwait(false);
            await database.DisposeAsync().ConfigureAwait(false);
            return executed ? 0 : 2;
        }
        catch
        {
            return 3;
        }
    }
}
