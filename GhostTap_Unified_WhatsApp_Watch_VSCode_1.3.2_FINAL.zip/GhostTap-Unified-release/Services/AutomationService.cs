using GhostTap.Unified.Models;
using System.Diagnostics;

namespace GhostTap.Unified.Services;

public sealed class AutomationService
{
    private readonly SettingsService _settings;
    private readonly ReminderService _reminders;

    public event EventHandler<FocusMode>? ModeChanged;
    public string CurrentModeName { get; private set; } = "No mode";

    public AutomationService(SettingsService settings, ReminderService reminders)
    {
        _settings = settings;
        _reminders = reminders;
    }

    public async Task PauseRemindersAsync()
    {
        _reminders.Paused = true;
        _settings.Current.RemindersPaused = true;
        await _settings.SaveAsync().ConfigureAwait(false);
    }

    public async Task ResumeRemindersAsync()
    {
        _reminders.Paused = false;
        _settings.Current.RemindersPaused = false;
        await _settings.SaveAsync().ConfigureAwait(false);
    }

    public async Task RunModeAsync(string modeId)
    {
        var mode = _settings.GetMode(modeId);
        if (mode is null)
        {
            return;
        }

        if (_settings.Current.CloseDistractingProcesses && mode.CloseProcessNames.Count > 0)
        {
            await CloseProcessesAsync(mode.CloseProcessNames, _settings.Current.ForceCloseDistractingProcesses);
        }

        foreach (var target in mode.Targets)
        {
            OpenTarget(target);
            await Task.Delay(150);
        }

        _reminders.Paused = mode.PauseReminders;
        _settings.Current.RemindersPaused = mode.PauseReminders;

        _settings.SetCurrentMode(mode.Id);
        await _settings.SaveAsync();
        CurrentModeName = mode.Name;
        ModeChanged?.Invoke(this, mode);
    }

    private static void OpenTarget(AutomationTarget target)
    {
        if (string.IsNullOrWhiteSpace(target.Value))
        {
            return;
        }

        try
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = target.Value,
                UseShellExecute = true
            });
        }
        catch
        {
            // A single failed target must not prevent the rest of the mode from running.
        }
    }

    private static async Task CloseProcessesAsync(IEnumerable<string> processNames, bool force)
    {
        var names = processNames
            .Select(x => Path.GetFileNameWithoutExtension(x).Trim())
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        foreach (var name in names)
        {
            Process[] processes;
            try { processes = Process.GetProcessesByName(name); }
            catch { continue; }

            foreach (var process in processes)
            {
                using (process)
                {
                    try
                    {
                        if (process.HasExited)
                        {
                            continue;
                        }

                        if (process.CloseMainWindow())
                        {
                            await Task.Delay(300);
                        }

                        if (force && !process.HasExited)
                        {
                            process.Kill(entireProcessTree: true);
                        }
                    }
                    catch
                    {
                        // Processes owned by another account or with no UI may not be closable.
                    }
                }
            }
        }
    }

    public static void TryOpenWhatsApp()
    {
        try
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = "whatsapp://",
                UseShellExecute = true
            });
        }
        catch
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = "https://web.whatsapp.com/",
                    UseShellExecute = true
                });
            }
            catch
            {
                // WhatsApp may not be installed or its protocol may be unavailable.
            }
        }
    }
}
