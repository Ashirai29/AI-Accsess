using PCSC;
using PCSC.Exceptions;
using PCSC.Iso7816;
using PCSC.Monitoring;

namespace GhostTap.Unified.Services;

public sealed class NfcService : IAsyncDisposable
{
    private const int Type2FirstUserPage = 4;
    private const int Type2LastConservativePage = 39;

    private readonly object _sync = new();
    private readonly Dictionary<string, ISCardMonitor> _monitors = new(StringComparer.OrdinalIgnoreCase);
    private CancellationTokenSource? _cts;
    private Task? _refreshTask;
    private DateTimeOffset _lastScanAt = DateTimeOffset.MinValue;
    private string _lastUid = string.Empty;

    public event EventHandler<string>? StatusChanged;
    public event EventHandler<NfcCardScannedEventArgs>? CardScanned;

    public string Status { get; private set; } = "NFC reader not started.";
    public IReadOnlyList<string> Readers { get; private set; } = Array.Empty<string>();
    public NfcCardScannedEventArgs? LastScan { get; private set; }

    public void Start()
    {
        if (_refreshTask is not null) return;
        _cts = new CancellationTokenSource();
        _refreshTask = Task.Run(() => RefreshLoopAsync(_cts.Token));
    }

    public async Task StopAsync()
    {
        _cts?.Cancel();
        if (_refreshTask is not null)
        {
            try { await _refreshTask.ConfigureAwait(false); } catch (OperationCanceledException) { }
        }

        lock (_sync)
        {
            foreach (var monitor in _monitors.Values)
            {
                try { monitor.Cancel(); } catch { }
                try { monitor.Dispose(); } catch { }
            }
            _monitors.Clear();
        }

        _refreshTask = null;
        _cts?.Dispose();
        _cts = null;
    }

    public async ValueTask DisposeAsync() => await StopAsync().ConfigureAwait(false);

    public async Task RefreshOnceAsync(CancellationToken cancellationToken = default)
    {
        await Task.Run(() => RefreshOnceCore(cancellationToken), cancellationToken).ConfigureAwait(false);
    }

    public async Task<NfcWriteResult> WriteModeUriAsync(string readerName, string modeId, CancellationToken cancellationToken = default)
    {
        var uri = NfcPayloadService.BuildModeUri(modeId);
        var payload = NfcPayloadService.BuildType2NdefTlv(uri);
        if (payload.Length > NfcPayloadService.ConservativeType2CapacityBytes)
        {
            return NfcWriteResult.Fail($"The GhostTap NDEF payload is {payload.Length} bytes. It must be {NfcPayloadService.ConservativeType2CapacityBytes} bytes or less for the conservative Type 2 tag profile.", uri);
        }

        if (string.IsNullOrWhiteSpace(readerName)) return NfcWriteResult.Fail("No NFC reader is selected.", uri);
        return await Task.Run(() => WriteType2UriCore(readerName, uri, payload, cancellationToken), cancellationToken).ConfigureAwait(false);
    }

    private void RefreshOnceCore(CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        try
        {
            using var context = ContextFactory.Instance.Establish(SCardScope.System);
            var readers = context.GetReaders()?.Where(x => !string.IsNullOrWhiteSpace(x)).ToArray() ?? Array.Empty<string>();
            Readers = readers;

            foreach (var reader in readers)
            {
                cancellationToken.ThrowIfCancellationRequested();
                EnsureMonitor(reader);
            }

            var removed = _monitors.Keys.Where(x => !readers.Contains(x, StringComparer.OrdinalIgnoreCase)).ToList();
            foreach (var reader in removed) RemoveMonitor(reader);

            SetStatus(readers.Length == 0
                ? "No PC/SC NFC reader detected."
                : $"{readers.Length} PC/SC reader{(readers.Length == 1 ? "" : "s")} ready.");
        }
        catch (Exception ex)
        {
            Readers = Array.Empty<string>();
            SetStatus($"NFC service unavailable: {ex.Message}");
        }
    }

    private async Task RefreshLoopAsync(CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            await RefreshOnceAsync(cancellationToken).ConfigureAwait(false);
            await Task.Delay(TimeSpan.FromSeconds(5), cancellationToken).ConfigureAwait(false);
        }
    }

    private void EnsureMonitor(string readerName)
    {
        lock (_sync)
        {
            if (_monitors.ContainsKey(readerName)) return;

            try
            {
                ISCardMonitor monitor = MonitorFactory.Instance.Create(SCardScope.System);
                monitor.CardInserted += (_, e) => _ = HandleCardInsertedAsync(e.ReaderName);
                monitor.MonitorException += (_, e) => SetStatus($"NFC reader monitor error: {e.Message}");
                monitor.Start(readerName);
                _monitors[readerName] = monitor;
            }
            catch (Exception ex)
            {
                SetStatus($"Could not monitor {readerName}: {ex.Message}");
            }
        }
    }

    private void RemoveMonitor(string readerName)
    {
        lock (_sync)
        {
            if (!_monitors.Remove(readerName, out var monitor)) return;
            try { monitor.Cancel(); } catch { }
            try { monitor.Dispose(); } catch { }
        }
    }

    private async Task HandleCardInsertedAsync(string readerName)
    {
        try
        {
            var card = await Task.Run(() => ReadCardCore(readerName)).ConfigureAwait(false);
            if (card is null)
            {
                SetStatus($"Card detected in {readerName}, but a stable identity could not be read.");
                return;
            }

            var now = DateTimeOffset.Now;
            lock (_sync)
            {
                if (card.Uid.Equals(_lastUid, StringComparison.OrdinalIgnoreCase) && now - _lastScanAt < TimeSpan.FromSeconds(2)) return;
                _lastUid = card.Uid;
                _lastScanAt = now;
                LastScan = card;
            }

            CardScanned?.Invoke(this, card);
            var payloadSuffix = card.PayloadUri is null ? string.Empty : $" NDEF command: {card.PayloadUri}";
            SetStatus($"NFC card detected via {card.IdentityType} on {readerName}.{payloadSuffix}");
        }
        catch (Exception ex)
        {
            SetStatus($"NFC scan error: {ex.Message}");
        }
    }

    private static NfcCardScannedEventArgs? ReadCardCore(string readerName)
    {
        using var context = ContextFactory.Instance.Establish(SCardScope.System);
        string? uid = null;
        Uri? payloadUri = null;

        try
        {
            using var isoReader = new IsoReader(context, readerName, SCardShareMode.Shared, SCardProtocol.Any, false);
            var uidApdu = new CommandApdu(IsoCase.Case2Short, isoReader.ActiveProtocol)
            {
                CLA = 0xFF,
                Instruction = InstructionCode.GetData,
                P1 = 0x00,
                P2 = 0x00,
                Le = 0x00
            };
            var response = isoReader.Transmit(uidApdu);
            var data = response.GetData() ?? Array.Empty<byte>();
            if (data.Length > 0 && IsSuccessful(response)) uid = Convert.ToHexString(data);
            payloadUri = TryReadGhostTapUri(isoReader);

            if (!string.IsNullOrWhiteSpace(uid))
            {
                return new NfcCardScannedEventArgs(uid, readerName, "UID", true, payloadUri);
            }
        }
        catch
        {
            // Some readers do not expose UID or do not support the Type 2 read commands.
        }

        try
        {
            using var reader = context.ConnectReader(readerName, SCardShareMode.Shared, SCardProtocol.Any);
            var status = reader.GetStatus();
            var atr = status.GetAtr();
            if (atr.Length == 0) return payloadUri is null ? null : new NfcCardScannedEventArgs($"URI:{payloadUri}", readerName, "NDEF URI", false, payloadUri);

            var atrText = Convert.ToHexString(atr);
            return new NfcCardScannedEventArgs($"ATR:{atrText}", readerName, "ATR", false, payloadUri);
        }
        catch (PCSCException)
        {
            return null;
        }
    }

    private static Uri? TryReadGhostTapUri(IsoReader isoReader)
    {
        try
        {
            var bytes = new List<byte>(NfcPayloadService.ConservativeType2CapacityBytes);
            for (var page = Type2FirstUserPage; page <= Type2LastConservativePage; page++)
            {
                var readApdu = new CommandApdu(IsoCase.Case2Short, isoReader.ActiveProtocol)
                {
                    CLA = 0xFF,
                    INS = 0xB0,
                    P1 = 0x00,
                    P2 = (byte)page,
                    Le = 0x04
                };
                var response = isoReader.Transmit(readApdu);
                var data = response.GetData() ?? Array.Empty<byte>();
                if (!IsSuccessful(response) || data.Length == 0) break;
                bytes.AddRange(data.Take(4));
            }
            return NfcPayloadService.TryParseGhostTapUri(bytes.ToArray(), out var uri) ? uri : null;
        }
        catch
        {
            return null;
        }
    }

    private static NfcWriteResult WriteType2UriCore(string readerName, string uri, byte[] payload, CancellationToken cancellationToken)
    {
        try
        {
            using var context = ContextFactory.Instance.Establish(SCardScope.System);
            using var isoReader = new IsoReader(context, readerName, SCardShareMode.Shared, SCardProtocol.Any, false);
            var requiredPages = (payload.Length + 3) / 4;
            if (Type2FirstUserPage + requiredPages - 1 > Type2LastConservativePage)
            {
                return NfcWriteResult.Fail("The NDEF payload would exceed the conservative writable Type 2 page range.", uri);
            }

            // The card must be present. UID is intentionally read immediately before writing.
            var uidApdu = new CommandApdu(IsoCase.Case2Short, isoReader.ActiveProtocol)
            {
                CLA = 0xFF, Instruction = InstructionCode.GetData, P1 = 0x00, P2 = 0x00, Le = 0x00
            };
            var uidResponse = isoReader.Transmit(uidApdu);
            if (!IsSuccessful(uidResponse) || (uidResponse.GetData()?.Length ?? 0) == 0)
            {
                return NfcWriteResult.Fail("The reader did not expose a writable card UID. Writing was cancelled.", uri);
            }

            for (var index = 0; index < requiredPages; index++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                var pageData = new byte[4];
                var sourceOffset = index * 4;
                var copyLength = Math.Min(4, payload.Length - sourceOffset);
                Buffer.BlockCopy(payload, sourceOffset, pageData, 0, copyLength);

                var writeApdu = new CommandApdu(IsoCase.Case3Short, isoReader.ActiveProtocol)
                {
                    CLA = 0xFF,
                    INS = 0xD6,
                    P1 = 0x00,
                    P2 = (byte)(Type2FirstUserPage + index),
                    Data = pageData
                };
                var response = isoReader.Transmit(writeApdu);
                if (!IsSuccessful(response))
                {
                    return NfcWriteResult.Fail($"The reader/card rejected the write at Type 2 page {Type2FirstUserPage + index}.", uri);
                }
            }

            var verified = TryReadGhostTapUri(isoReader);
            if (verified is null || !string.Equals(verified.ToString(), uri, StringComparison.OrdinalIgnoreCase))
            {
                return NfcWriteResult.Fail("The write completed, but the tag could not be verified as a GhostTap command. The card may use a different NDEF layout.", uri);
            }

            return NfcWriteResult.Success(uri, payload.Length, requiredPages);
        }
        catch (OperationCanceledException)
        {
            return NfcWriteResult.Fail("NFC writing was cancelled.", uri);
        }
        catch (Exception ex)
        {
            return NfcWriteResult.Fail($"NFC NDEF write failed: {ex.Message}", uri);
        }
    }

    private static bool IsSuccessful(Response response) => response.SW1 == 0x90 && response.SW2 == 0x00;

    private void SetStatus(string value)
    {
        Status = value;
        StatusChanged?.Invoke(this, value);
    }
}

public sealed class NfcCardScannedEventArgs : EventArgs
{
    public NfcCardScannedEventArgs(string uid, string readerName, string identityType, bool isUniqueIdentity, Uri? payloadUri = null)
    {
        Uid = uid;
        ReaderName = readerName;
        IdentityType = identityType;
        IsUniqueIdentity = isUniqueIdentity;
        PayloadUri = payloadUri;
    }

    public string Uid { get; }
    public string ReaderName { get; }
    public string IdentityType { get; }
    public bool IsUniqueIdentity { get; }
    public Uri? PayloadUri { get; }
}

public sealed class NfcWriteResult
{
    private NfcWriteResult(bool succeeded, string message, string uri, int bytesWritten, int pagesWritten)
    {
        Succeeded = succeeded;
        Message = message;
        Uri = uri;
        BytesWritten = bytesWritten;
        PagesWritten = pagesWritten;
    }

    public bool Succeeded { get; }
    public string Message { get; }
    public string Uri { get; }
    public int BytesWritten { get; }
    public int PagesWritten { get; }

    public static NfcWriteResult Success(string uri, int bytesWritten, int pagesWritten) => new(true, $"Wrote {bytesWritten} NDEF bytes across {pagesWritten} page(s).", uri, bytesWritten, pagesWritten);
    public static NfcWriteResult Fail(string message, string uri) => new(false, message, uri, 0, 0);
}
