using System.Globalization;
using Microsoft.Data.Sqlite;
using GhostTap.Unified.Models;

namespace GhostTap.Unified.Services;

/// <summary>
/// SQLite persistence for operational data. Settings remain in JSON because they are
/// configuration; tasks and activity history are persisted in SQLite for durable, indexed storage.
/// </summary>
public sealed class DatabaseService : IAsyncDisposable
{
    private readonly string _databasePath;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private bool _initialized;
    private bool _disposed;

    public DatabaseService(PathService paths)
    {
        ArgumentNullException.ThrowIfNull(paths);
        _databasePath = paths.DatabasePath;
    }

    public bool IsAvailable { get; private set; }
    public string Status { get; private set; } = "SQLite database has not been initialized.";
    public string DatabasePath => _databasePath;

    public async Task InitializeAsync(PathService paths)
    {
        ArgumentNullException.ThrowIfNull(paths);
        if (_disposed || _initialized) return;

        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(_databasePath) ?? AppContext.BaseDirectory);
            await _gate.WaitAsync().ConfigureAwait(false);
            try
            {
                if (_disposed || _initialized) return;

                await using var connection = await OpenConnectionAsync().ConfigureAwait(false);
                await CreateSchemaAsync(connection).ConfigureAwait(false);
                await MigrateLegacyJsonAsync(paths, connection).ConfigureAwait(false);

                _initialized = true;
                IsAvailable = true;
                Status = $"SQLite database ready: {_databasePath}";
            }
            finally
            {
                _gate.Release();
            }
        }
        catch (Exception ex)
        {
            IsAvailable = false;
            Status = $"SQLite unavailable; JSON fallback is active. {ex.Message}";
        }
    }

    public async Task<List<GhostTask>> GetTasksAsync()
    {
        if (!IsAvailable || _disposed) return new();
        return await WithConnectionAsync(async connection =>
        {
            var result = new List<GhostTask>();
            await using var command = connection.CreateCommand();
            command.CommandText = """
                SELECT Id, Title, SourceChat, SourcePreview, CreatedAt, DueAt, Status,
                       LastReminderAt, NextReminderAt, ReminderMinutes, DetectionKey, Occurrences
                FROM Tasks
                ORDER BY CASE Status WHEN 0 THEN 0 ELSE 1 END,
                         CASE WHEN DueAt IS NULL THEN 1 ELSE 0 END,
                         DueAt,
                         CreatedAt DESC;
                """;
            await using var reader = await command.ExecuteReaderAsync().ConfigureAwait(false);
            while (await reader.ReadAsync().ConfigureAwait(false))
            {
                result.Add(new GhostTask
                {
                    Id = reader.GetString(0),
                    Title = reader.GetString(1),
                    SourceChat = reader.GetString(2),
                    SourcePreview = reader.GetString(3),
                    CreatedAt = ParseDate(reader.GetString(4)),
                    DueAt = reader.IsDBNull(5) ? null : ParseDate(reader.GetString(5)),
                    Status = (GhostTaskStatus)reader.GetInt32(6),
                    LastReminderAt = reader.IsDBNull(7) ? null : ParseDate(reader.GetString(7)),
                    NextReminderAt = reader.IsDBNull(8) ? null : ParseDate(reader.GetString(8)),
                    ReminderMinutes = reader.GetInt32(9),
                    DetectionKey = reader.GetString(10),
                    Occurrences = reader.GetInt32(11)
                });
            }
            return result;
        }).ConfigureAwait(false);
    }

    public async Task<WhatsAppActivity?> GetActivityByNotificationKeyAsync(string notificationKey)
    {
        if (!IsAvailable || _disposed || string.IsNullOrWhiteSpace(notificationKey)) return null;
        return await WithConnectionAsync(async connection =>
        {
            await using var command = connection.CreateCommand();
            command.CommandText = """
                SELECT Id, Chat, Sender, Preview, CreatedAt, IsHandled, GeneratedTask, NotificationKey
                FROM Activities
                WHERE NotificationKey = $key
                ORDER BY CreatedAt DESC
                LIMIT 1;
                """;
            command.Parameters.AddWithValue("$key", notificationKey);
            await using var reader = await command.ExecuteReaderAsync().ConfigureAwait(false);
            return await reader.ReadAsync().ConfigureAwait(false) ? ReadActivity(reader) : null;
        }).ConfigureAwait(false);
    }

    public async Task<List<WhatsAppActivity>> GetRecentActivitiesAsync(int max = 250)
    {
        if (!IsAvailable || _disposed) return new();
        max = Math.Clamp(max, 1, 2000);
        return await WithConnectionAsync(async connection =>
        {
            var result = new List<WhatsAppActivity>();
            await using var command = connection.CreateCommand();
            command.CommandText = $"""
                SELECT Id, Chat, Sender, Preview, CreatedAt, IsHandled, GeneratedTask, NotificationKey
                FROM Activities
                ORDER BY CreatedAt DESC
                LIMIT {max};
                """;
            await using var reader = await command.ExecuteReaderAsync().ConfigureAwait(false);
            while (await reader.ReadAsync().ConfigureAwait(false))
            {
                result.Add(ReadActivity(reader));
            }
            return result;
        }).ConfigureAwait(false);
    }

    public async Task<int> CountUnhandledActivitiesAsync()
    {
        if (!IsAvailable || _disposed) return 0;
        return await WithConnectionAsync(async connection =>
        {
            await using var command = connection.CreateCommand();
            command.CommandText = "SELECT COUNT(*) FROM Activities WHERE IsHandled = 0;";
            var value = await command.ExecuteScalarAsync().ConfigureAwait(false);
            return Convert.ToInt32(value, CultureInfo.InvariantCulture);
        }).ConfigureAwait(false);
    }

    public async Task UpsertTaskAsync(GhostTask task)
    {
        ArgumentNullException.ThrowIfNull(task);
        if (!IsAvailable || _disposed) return;
        await WithWriteConnectionAsync(async connection =>
        {
            await using var command = connection.CreateCommand();
            command.CommandText = """
                INSERT INTO Tasks
                    (Id, Title, SourceChat, SourcePreview, CreatedAt, DueAt, Status,
                     LastReminderAt, NextReminderAt, ReminderMinutes, DetectionKey, Occurrences)
                VALUES
                    ($id, $title, $chat, $preview, $created, $due, $status,
                     $lastReminder, $nextReminder, $reminderMinutes, $detectionKey, $occurrences)
                ON CONFLICT(Id) DO UPDATE SET
                    Title = excluded.Title,
                    SourceChat = excluded.SourceChat,
                    SourcePreview = excluded.SourcePreview,
                    CreatedAt = excluded.CreatedAt,
                    DueAt = excluded.DueAt,
                    Status = excluded.Status,
                    LastReminderAt = excluded.LastReminderAt,
                    NextReminderAt = excluded.NextReminderAt,
                    ReminderMinutes = excluded.ReminderMinutes,
                    DetectionKey = excluded.DetectionKey,
                    Occurrences = excluded.Occurrences;
                """;
            AddTaskParameters(command, task);
            await command.ExecuteNonQueryAsync().ConfigureAwait(false);
        }).ConfigureAwait(false);
    }

    public async Task DeleteTaskAsync(string id)
    {
        if (!IsAvailable || _disposed || string.IsNullOrWhiteSpace(id)) return;
        await WithWriteConnectionAsync(async connection =>
        {
            await using var command = connection.CreateCommand();
            command.CommandText = "DELETE FROM Tasks WHERE Id = $id;";
            command.Parameters.AddWithValue("$id", id);
            await command.ExecuteNonQueryAsync().ConfigureAwait(false);
        }).ConfigureAwait(false);
    }

    public async Task UpsertActivityAsync(WhatsAppActivity activity)
    {
        ArgumentNullException.ThrowIfNull(activity);
        if (!IsAvailable || _disposed) return;

        await WithWriteConnectionAsync(async connection =>
        {
            await using var transaction = await connection.BeginTransactionAsync().ConfigureAwait(false);
            try
            {
                if (!string.IsNullOrWhiteSpace(activity.NotificationKey))
                {
                    await using var delete = connection.CreateCommand();
                    delete.Transaction = transaction;
                    delete.CommandText = "DELETE FROM Activities WHERE NotificationKey = $key;";
                    delete.Parameters.AddWithValue("$key", activity.NotificationKey);
                    await delete.ExecuteNonQueryAsync().ConfigureAwait(false);
                }

                await using var insert = connection.CreateCommand();
                insert.Transaction = transaction;
                insert.CommandText = """
                    INSERT INTO Activities
                        (Id, Chat, Sender, Preview, CreatedAt, IsHandled, GeneratedTask, NotificationKey)
                    VALUES
                        ($id, $chat, $sender, $preview, $created, $handled, $generated, $key);
                    """;
                insert.Parameters.AddWithValue("$id", activity.Id);
                insert.Parameters.AddWithValue("$chat", activity.Chat ?? string.Empty);
                insert.Parameters.AddWithValue("$sender", activity.Sender ?? string.Empty);
                insert.Parameters.AddWithValue("$preview", activity.Preview ?? string.Empty);
                insert.Parameters.AddWithValue("$created", activity.CreatedAt.ToString("O"));
                insert.Parameters.AddWithValue("$handled", activity.IsHandled ? 1 : 0);
                insert.Parameters.AddWithValue("$generated", activity.GeneratedTask ? 1 : 0);
                insert.Parameters.AddWithValue("$key", activity.NotificationKey ?? string.Empty);
                await insert.ExecuteNonQueryAsync().ConfigureAwait(false);
                await transaction.CommitAsync().ConfigureAwait(false);
            }
            catch
            {
                await transaction.RollbackAsync().ConfigureAwait(false);
                throw;
            }
        }).ConfigureAwait(false);
    }

    public async Task UpdateActivityHandledAsync(string id, bool handled)
    {
        if (!IsAvailable || _disposed || string.IsNullOrWhiteSpace(id)) return;
        await WithWriteConnectionAsync(async connection =>
        {
            await using var command = connection.CreateCommand();
            command.CommandText = "UPDATE Activities SET IsHandled = $handled WHERE Id = $id;";
            command.Parameters.AddWithValue("$handled", handled ? 1 : 0);
            command.Parameters.AddWithValue("$id", id);
            await command.ExecuteNonQueryAsync().ConfigureAwait(false);
        }).ConfigureAwait(false);
    }

    public async Task MarkAllActivitiesHandledAsync()
    {
        if (!IsAvailable || _disposed) return;
        await WithWriteConnectionAsync(async connection =>
        {
            await using var command = connection.CreateCommand();
            command.CommandText = "UPDATE Activities SET IsHandled = 1 WHERE IsHandled = 0;";
            await command.ExecuteNonQueryAsync().ConfigureAwait(false);
        }).ConfigureAwait(false);
    }

    public async Task ClearActivitiesAsync()
    {
        if (!IsAvailable || _disposed) return;
        await WithWriteConnectionAsync(async connection =>
        {
            await using var command = connection.CreateCommand();
            command.CommandText = "DELETE FROM Activities;";
            await command.ExecuteNonQueryAsync().ConfigureAwait(false);
        }).ConfigureAwait(false);
    }

    public async Task DeleteActivityAsync(string id)
    {
        if (!IsAvailable || _disposed || string.IsNullOrWhiteSpace(id)) return;
        await WithWriteConnectionAsync(async connection =>
        {
            await using var command = connection.CreateCommand();
            command.CommandText = "DELETE FROM Activities WHERE Id = $id;";
            command.Parameters.AddWithValue("$id", id);
            await command.ExecuteNonQueryAsync().ConfigureAwait(false);
        }).ConfigureAwait(false);
    }

    public async Task<int> GetTaskCountAsync()
    {
        if (!IsAvailable || _disposed) return 0;
        return await WithConnectionAsync(async connection =>
        {
            await using var command = connection.CreateCommand();
            command.CommandText = "SELECT COUNT(*) FROM Tasks;";
            return Convert.ToInt32(await command.ExecuteScalarAsync().ConfigureAwait(false), CultureInfo.InvariantCulture);
        }).ConfigureAwait(false);
    }

    private async Task CreateSchemaAsync(SqliteConnection connection)
    {
        await using var command = connection.CreateCommand();
        command.CommandText = """
            PRAGMA journal_mode = WAL;
            PRAGMA synchronous = NORMAL;
            PRAGMA busy_timeout = 5000;
            PRAGMA foreign_keys = ON;

            CREATE TABLE IF NOT EXISTS Meta (
                Key TEXT PRIMARY KEY,
                Value TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS Tasks (
                Id TEXT PRIMARY KEY,
                Title TEXT NOT NULL,
                SourceChat TEXT NOT NULL DEFAULT '',
                SourcePreview TEXT NOT NULL DEFAULT '',
                CreatedAt TEXT NOT NULL,
                DueAt TEXT NULL,
                Status INTEGER NOT NULL,
                LastReminderAt TEXT NULL,
                NextReminderAt TEXT NULL,
                ReminderMinutes INTEGER NOT NULL,
                DetectionKey TEXT NOT NULL DEFAULT '',
                Occurrences INTEGER NOT NULL DEFAULT 1
            );

            CREATE INDEX IF NOT EXISTS IX_Tasks_Status_Due
            ON Tasks(Status, DueAt, CreatedAt);

            CREATE TABLE IF NOT EXISTS Activities (
                Id TEXT PRIMARY KEY,
                Chat TEXT NOT NULL DEFAULT '',
                Sender TEXT NOT NULL DEFAULT '',
                Preview TEXT NOT NULL DEFAULT '',
                CreatedAt TEXT NOT NULL,
                IsHandled INTEGER NOT NULL DEFAULT 0,
                GeneratedTask INTEGER NOT NULL DEFAULT 0,
                NotificationKey TEXT NOT NULL DEFAULT ''
            );

            CREATE INDEX IF NOT EXISTS IX_Activities_CreatedAt
            ON Activities(CreatedAt DESC);

            CREATE INDEX IF NOT EXISTS IX_Activities_NotificationKey
            ON Activities(NotificationKey);
            """;
        await command.ExecuteNonQueryAsync().ConfigureAwait(false);
    }

    private async Task MigrateLegacyJsonAsync(PathService paths, SqliteConnection connection)
    {
        if (!await IsFlagSetAsync(connection, "legacy-json-migrated-v1").ConfigureAwait(false))
        {
            var tasks = await new JsonStore<List<GhostTask>>(paths.TasksPath).LoadAsync().ConfigureAwait(false);
            if (tasks is not null)
            {
                foreach (var task in tasks)
                {
                    NormalizeTask(task);
                    await UpsertTaskOnConnectionAsync(connection, task).ConfigureAwait(false);
                }
            }

            var activities = await new JsonStore<List<WhatsAppActivity>>(paths.ActivitiesPath).LoadAsync().ConfigureAwait(false);
            if (activities is not null)
            {
                foreach (var activity in activities)
                {
                    NormalizeActivity(activity);
                    await UpsertActivityOnConnectionAsync(connection, activity).ConfigureAwait(false);
                }
            }

            await SetFlagAsync(connection, "legacy-json-migrated-v1", "true").ConfigureAwait(false);
            ArchiveLegacy(paths.TasksPath);
            ArchiveLegacy(paths.ActivitiesPath);
        }
    }

    private async Task UpsertTaskOnConnectionAsync(SqliteConnection connection, GhostTask task)
    {
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO Tasks
                (Id, Title, SourceChat, SourcePreview, CreatedAt, DueAt, Status,
                 LastReminderAt, NextReminderAt, ReminderMinutes, DetectionKey, Occurrences)
            VALUES
                ($id, $title, $chat, $preview, $created, $due, $status,
                 $lastReminder, $nextReminder, $reminderMinutes, $detectionKey, $occurrences)
            ON CONFLICT(Id) DO NOTHING;
            """;
        AddTaskParameters(command, task);
        await command.ExecuteNonQueryAsync().ConfigureAwait(false);
    }

    private async Task UpsertActivityOnConnectionAsync(SqliteConnection connection, WhatsAppActivity activity)
    {
        if (!string.IsNullOrWhiteSpace(activity.NotificationKey))
        {
            await using var delete = connection.CreateCommand();
            delete.CommandText = "DELETE FROM Activities WHERE NotificationKey = $key;";
            delete.Parameters.AddWithValue("$key", activity.NotificationKey);
            await delete.ExecuteNonQueryAsync().ConfigureAwait(false);
        }

        await using var insert = connection.CreateCommand();
        insert.CommandText = """
            INSERT INTO Activities
                (Id, Chat, Sender, Preview, CreatedAt, IsHandled, GeneratedTask, NotificationKey)
            VALUES
                ($id, $chat, $sender, $preview, $created, $handled, $generated, $key)
            ON CONFLICT(Id) DO NOTHING;
            """;
        insert.Parameters.AddWithValue("$id", activity.Id);
        insert.Parameters.AddWithValue("$chat", activity.Chat ?? string.Empty);
        insert.Parameters.AddWithValue("$sender", activity.Sender ?? string.Empty);
        insert.Parameters.AddWithValue("$preview", activity.Preview ?? string.Empty);
        insert.Parameters.AddWithValue("$created", activity.CreatedAt.ToString("O"));
        insert.Parameters.AddWithValue("$handled", activity.IsHandled ? 1 : 0);
        insert.Parameters.AddWithValue("$generated", activity.GeneratedTask ? 1 : 0);
        insert.Parameters.AddWithValue("$key", activity.NotificationKey ?? string.Empty);
        await insert.ExecuteNonQueryAsync().ConfigureAwait(false);
    }

    private async Task<bool> IsFlagSetAsync(SqliteConnection connection, string key)
    {
        await using var command = connection.CreateCommand();
        command.CommandText = "SELECT Value FROM Meta WHERE Key = $key LIMIT 1;";
        command.Parameters.AddWithValue("$key", key);
        var value = await command.ExecuteScalarAsync().ConfigureAwait(false);
        return string.Equals(Convert.ToString(value, CultureInfo.InvariantCulture), "true", StringComparison.OrdinalIgnoreCase);
    }

    private async Task SetFlagAsync(SqliteConnection connection, string key, string value)
    {
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO Meta(Key, Value) VALUES($key, $value)
            ON CONFLICT(Key) DO UPDATE SET Value = excluded.Value;
            """;
        command.Parameters.AddWithValue("$key", key);
        command.Parameters.AddWithValue("$value", value);
        await command.ExecuteNonQueryAsync().ConfigureAwait(false);
    }

    private async Task<SqliteConnection> OpenConnectionAsync()
    {
        var connection = new SqliteConnection($"Data Source={_databasePath};Mode=ReadWriteCreate;Cache=Shared;Default Timeout=5");
        await connection.OpenAsync().ConfigureAwait(false);
        return connection;
    }

    private async Task<T> WithConnectionAsync<T>(Func<SqliteConnection, Task<T>> operation)
    {
        ArgumentNullException.ThrowIfNull(operation);
        await _gate.WaitAsync().ConfigureAwait(false);
        try
        {
            await using var connection = await OpenConnectionAsync().ConfigureAwait(false);
            return await operation(connection).ConfigureAwait(false);
        }
        finally
        {
            _gate.Release();
        }
    }

    private async Task WithWriteConnectionAsync(Func<SqliteConnection, Task> operation)
    {
        ArgumentNullException.ThrowIfNull(operation);
        await _gate.WaitAsync().ConfigureAwait(false);
        try
        {
            await using var connection = await OpenConnectionAsync().ConfigureAwait(false);
            await operation(connection).ConfigureAwait(false);
        }
        finally
        {
            _gate.Release();
        }
    }

    private static void AddTaskParameters(SqliteCommand command, GhostTask task)
    {
        command.Parameters.AddWithValue("$id", task.Id ?? string.Empty);
        command.Parameters.AddWithValue("$title", task.Title ?? string.Empty);
        command.Parameters.AddWithValue("$chat", task.SourceChat ?? string.Empty);
        command.Parameters.AddWithValue("$preview", task.SourcePreview ?? string.Empty);
        command.Parameters.AddWithValue("$created", task.CreatedAt.ToString("O"));
        command.Parameters.AddWithValue("$due", task.DueAt?.ToString("O") ?? (object)DBNull.Value);
        command.Parameters.AddWithValue("$status", (int)task.Status);
        command.Parameters.AddWithValue("$lastReminder", task.LastReminderAt?.ToString("O") ?? (object)DBNull.Value);
        command.Parameters.AddWithValue("$nextReminder", task.NextReminderAt?.ToString("O") ?? (object)DBNull.Value);
        command.Parameters.AddWithValue("$reminderMinutes", Math.Clamp(task.ReminderMinutes, 5, 1440));
        command.Parameters.AddWithValue("$detectionKey", task.DetectionKey ?? string.Empty);
        command.Parameters.AddWithValue("$occurrences", Math.Max(1, task.Occurrences));
    }

    private static WhatsAppActivity ReadActivity(SqliteDataReader reader) => new()
    {
        Id = reader.GetString(0),
        Chat = reader.GetString(1),
        Sender = reader.GetString(2),
        Preview = reader.GetString(3),
        CreatedAt = ParseDate(reader.GetString(4)),
        IsHandled = reader.GetInt32(5) != 0,
        GeneratedTask = reader.GetInt32(6) != 0,
        NotificationKey = reader.GetString(7)
    };

    private static DateTimeOffset ParseDate(string value) =>
        DateTimeOffset.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out var parsed)
            ? parsed
            : DateTimeOffset.Now;

    private static void NormalizeTask(GhostTask task)
    {
        task.Id = string.IsNullOrWhiteSpace(task.Id) ? Guid.NewGuid().ToString("N") : task.Id;
        task.Title ??= string.Empty;
        task.SourceChat ??= string.Empty;
        task.SourcePreview ??= string.Empty;
        task.ReminderMinutes = Math.Clamp(task.ReminderMinutes, 5, 1440);
        task.Occurrences = Math.Max(1, task.Occurrences);
        if (task.Status == GhostTaskStatus.Done) task.NextReminderAt = null;
    }

    private static void NormalizeActivity(WhatsAppActivity activity)
    {
        activity.Id = string.IsNullOrWhiteSpace(activity.Id) ? Guid.NewGuid().ToString("N") : activity.Id;
        activity.Chat ??= string.Empty;
        activity.Sender ??= string.Empty;
        activity.Preview ??= string.Empty;
        activity.NotificationKey ??= string.Empty;
    }

    private static void ArchiveLegacy(string path)
    {
        try
        {
            if (!File.Exists(path)) return;
            var backup = path + ".legacy.json";
            if (File.Exists(backup))
            {
                File.Delete(path);
                return;
            }
            File.Move(path, backup);
        }
        catch
        {
            // Migration remains valid even if the legacy backup cannot be renamed.
        }
    }

    public ValueTask DisposeAsync()
    {
        if (_disposed) return ValueTask.CompletedTask;
        _disposed = true;
        IsAvailable = false;
        _gate.Dispose();
        return ValueTask.CompletedTask;
    }
}
