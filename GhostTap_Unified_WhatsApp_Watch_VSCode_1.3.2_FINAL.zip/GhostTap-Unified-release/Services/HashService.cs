using System.Security.Cryptography;
using System.Text;

namespace GhostTap.Unified.Services;

public static class HashService
{
    public static string Sha256(params string[] values)
    {
        var input = string.Join("\u001F", values);
        var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(input));
        return Convert.ToHexString(bytes).ToLowerInvariant();
    }
}
