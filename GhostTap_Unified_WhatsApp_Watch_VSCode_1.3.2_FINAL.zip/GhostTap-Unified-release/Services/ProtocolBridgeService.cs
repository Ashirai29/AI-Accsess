using System.IO.Pipes;
using System.Text;

namespace GhostTap.Unified.Services;

/// <summary>
/// Relays GhostTap protocol commands to an already-running GhostTap instance.
/// This keeps NFC/URI actions inside the live process instead of creating a second
/// background reminder process with separate in-memory state.
/// </summary>
public sealed class ProtocolBridgeService : IAsyncDisposable
{
    private const string PipeName = "GhostTapUnified.Protocol.v1";
    private const int MaxCommandLength = 4096;

    private readonly object _sync = new();
    private CancellationTokenSource? _cts;
    private Task? _serverTask;
    private Func<Uri, Task>? _handler;

    public bool IsRunning => _serverTask is not null;

    public void Start(Func<Uri, Task> handler)
    {
        ArgumentNullException.ThrowIfNull(handler);
        lock (_sync)
        {
            if (_serverTask is not null) return;
            _handler = handler;
            _cts = new CancellationTokenSource();
            _serverTask = Task.Run(() => ServerLoopAsync(_cts.Token));
        }
    }

    public async Task StopAsync()
    {
        CancellationTokenSource? cts;
        Task? serverTask;
        lock (_sync)
        {
            cts = _cts;
            serverTask = _serverTask;
            _cts = null;
            _serverTask = null;
            _handler = null;
        }

        cts?.Cancel();
        if (serverTask is not null)
        {
            try { await serverTask.ConfigureAwait(false); } catch (OperationCanceledException) { }
        }
        cts?.Dispose();
    }

    /// <summary>
    /// Returns true when a running GhostTap instance accepted the command.
    /// It returns false when no listener is available, allowing the caller to execute
    /// the protocol activation directly in the current process.
    /// </summary>
    public static async Task<bool> TrySendToRunningInstanceAsync(Uri uri, int timeoutMilliseconds = 750)
    {
        if (!NfcPayloadService.TryValidateGhostTapUri(uri.ToString(), out var valid)) return false;

        try
        {
            using var client = new NamedPipeClientStream(".", PipeName, PipeDirection.Out, PipeOptions.Asynchronous);
            await client.ConnectAsync(Math.Clamp(timeoutMilliseconds, 100, 3000)).ConfigureAwait(false);
            await using var writer = new StreamWriter(client, new UTF8Encoding(false), 1024, leaveOpen: true)
            {
                AutoFlush = true
            };
            await writer.WriteLineAsync(valid.ToString()).ConfigureAwait(false);
            return true;
        }
        catch (TimeoutException)
        {
            return false;
        }
        catch (IOException)
        {
            return false;
        }
        catch (UnauthorizedAccessException)
        {
            return false;
        }
    }

    private async Task ServerLoopAsync(CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            try
            {
                await using var server = new NamedPipeServerStream(
                    PipeName,
                    PipeDirection.In,
                    1,
                    PipeTransmissionMode.Byte,
                    PipeOptions.Asynchronous);

                await server.WaitForConnectionAsync(cancellationToken).ConfigureAwait(false);
                using var reader = new StreamReader(server, new UTF8Encoding(false), detectEncodingFromByteOrderMarks: false, bufferSize: 1024, leaveOpen: true);
                var line = await reader.ReadLineAsync().ConfigureAwait(false);
                if (string.IsNullOrWhiteSpace(line) || line.Length > MaxCommandLength) continue;
                if (!NfcPayloadService.TryValidateGhostTapUri(line, out var uri)) continue;

                Func<Uri, Task>? handler;
                lock (_sync) handler = _handler;
                if (handler is not null)
                {
                    try { await handler(uri).ConfigureAwait(false); } catch { }
                }
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                break;
            }
            catch (IOException) when (!cancellationToken.IsCancellationRequested)
            {
                await Task.Delay(100, cancellationToken).ConfigureAwait(false);
            }
            catch (ObjectDisposedException) when (cancellationToken.IsCancellationRequested)
            {
                break;
            }
            catch
            {
                if (!cancellationToken.IsCancellationRequested)
                {
                    try { await Task.Delay(250, cancellationToken).ConfigureAwait(false); } catch (OperationCanceledException) { break; }
                }
            }
        }
    }

    public async ValueTask DisposeAsync() => await StopAsync().ConfigureAwait(false);
}
