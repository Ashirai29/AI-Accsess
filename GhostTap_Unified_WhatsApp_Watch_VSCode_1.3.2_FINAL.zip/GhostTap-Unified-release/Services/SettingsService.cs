using GhostTap.Unified.Models;

namespace GhostTap.Unified.Services;

public sealed class SettingsService
{
    private readonly JsonStore<GhostTapSettings> _store;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private GhostTapSettings _settings = CreateDefaults();

    public event EventHandler? SettingsChanged;
    public GhostTapSettings Current => _settings;

    public SettingsService(PathService paths)
    {
        _store = new JsonStore<GhostTapSettings>(paths.SettingsPath);
    }

    public async Task LoadAsync()
    {
        var loaded = await _store.LoadAsync();
        _settings = loaded ?? CreateDefaults();
        EnsureDefaults();
        await _store.SaveAsync(_settings);
    }

    public async Task SaveAsync()
    {
        await _gate.WaitAsync();
        try
        {
            await _store.SaveAsync(_settings);
        }
        finally
        {
            _gate.Release();
        }

        SettingsChanged?.Invoke(this, EventArgs.Empty);
    }

    public FocusMode? GetMode(string modeId) => _settings.FocusModes.FirstOrDefault(x => x.Id.Equals(modeId, StringComparison.OrdinalIgnoreCase));
    public NfcBinding? GetNfcBinding(string uid) => _settings.NfcBindings.FirstOrDefault(x => x.Uid.Equals(uid, StringComparison.OrdinalIgnoreCase));

    public void SetCurrentMode(string modeId) => _settings.CurrentModeId = modeId;

    public void BindCard(string uid, string modeId, string label, string identityType, bool isUniqueIdentity)
    {
        var existing = GetNfcBinding(uid);
        if (existing is null)
        {
            _settings.NfcBindings.Add(new NfcBinding
            {
                Uid = uid,
                ModeId = modeId,
                Label = label,
                IdentityType = identityType,
                IsUniqueIdentity = isUniqueIdentity,
                BoundAt = DateTimeOffset.Now
            });
        }
        else
        {
            existing.ModeId = modeId;
            existing.Label = label;
            existing.IdentityType = identityType;
            existing.IsUniqueIdentity = isUniqueIdentity;
            existing.BoundAt = DateTimeOffset.Now;
        }
    }

    public void RemoveCardBinding(string uid) => _settings.NfcBindings.RemoveAll(x => x.Uid.Equals(uid, StringComparison.OrdinalIgnoreCase));

    private void EnsureDefaults()
    {
        var defaults = CreateDefaults();
        _settings.WhatsAppRules ??= new List<WhatsAppWatchRule>();
        _settings.FocusModes ??= new List<FocusMode>();
        _settings.NfcBindings ??= new List<NfcBinding>();
        _settings.DistractingProcessNames ??= defaults.DistractingProcessNames;

        foreach (var defaultRule in defaults.WhatsAppRules)
        {
            if (_settings.WhatsAppRules.All(x => !x.Id.Equals(defaultRule.Id, StringComparison.OrdinalIgnoreCase)))
            {
                _settings.WhatsAppRules.Add(defaultRule);
            }
        }

        foreach (var defaultMode in defaults.FocusModes)
        {
            var existingMode = _settings.FocusModes.FirstOrDefault(x => x.Id.Equals(defaultMode.Id, StringComparison.OrdinalIgnoreCase));
            if (existingMode is null)
            {
                _settings.FocusModes.Add(defaultMode);
            }
            else if (existingMode.Targets.Count == 0 && defaultMode.Targets.Count > 0)
            {
                // Upgrade older GhostTap settings that had a placeholder mode with no targets.
                existingMode.Targets = defaultMode.Targets.Select(CloneTarget).ToList();
            }
        }

        _settings.WhatsAppPollSeconds = Math.Clamp(_settings.WhatsAppPollSeconds, 15, 120);
        _settings.DefaultReminderMinutes = Math.Clamp(_settings.DefaultReminderMinutes, 5, 1440);
        _settings.NotificationCatchUpMinutes = Math.Clamp(_settings.NotificationCatchUpMinutes, 1, 60);
        _settings.CurrentModeId = string.IsNullOrWhiteSpace(_settings.CurrentModeId) || GetMode(_settings.CurrentModeId) is null
            ? "study"
            : _settings.CurrentModeId;

        foreach (var rule in _settings.WhatsAppRules)
        {
            rule.ChatPattern = string.IsNullOrWhiteSpace(rule.ChatPattern) ? "*" : rule.ChatPattern.Trim();
            rule.ReminderMinutes = Math.Clamp(rule.ReminderMinutes, 5, 1440);
            rule.Keywords ??= new List<string>();
        }

        foreach (var binding in _settings.NfcBindings)
        {
            if (string.IsNullOrWhiteSpace(binding.IdentityType)) binding.IdentityType = "UID";
            if (binding.IdentityType.Equals("UID", StringComparison.OrdinalIgnoreCase)) binding.IsUniqueIdentity = true;
        }
    }

    private static AutomationTarget CloneTarget(AutomationTarget target) => new()
    {
        Kind = target.Kind,
        Value = target.Value
    };

    public static GhostTapSettings CreateDefaults()
    {
        var study = new FocusMode
        {
            Id = "study",
            Name = "Study Mode",
            Description = "Open Blackboard and a focus playlist, then use your configured study tools.",
            PauseReminders = false,
            Targets = new()
            {
                new() { Kind = AutomationTargetKind.Url, Value = "https://learn.ufs.ac.za" },
                new() { Kind = AutomationTargetKind.Url, Value = "https://open.spotify.com/playlist/37i9dQZF1DWZeKCadgRdKQ" }
            }
        };
        study.CloseProcessNames.Add("Discord");

        var coding = new FocusMode
        {
            Id = "coding",
            Name = "Coding Mode",
            Description = "Open your development workspace and GitHub.",
            Targets = new()
            {
                new() { Kind = AutomationTargetKind.Application, Value = "code" },
                new() { Kind = AutomationTargetKind.Url, Value = "https://github.com/" }
            }
        };

        var gaming = new FocusMode
        {
            Id = "gaming",
            Name = "Gaming Mode",
            Description = "Launch your gaming environment.",
            Targets = new()
            {
                new() { Kind = AutomationTargetKind.Shell, Value = "steam://open/main" }
            }
        };

        var sleep = new FocusMode
        {
            Id = "sleep",
            Name = "Sleep Mode",
            Description = "Quiet the assistant and pause reminders until you are ready again.",
            PauseReminders = true
        };

        return new GhostTapSettings
        {
            StartWithWindows = true,
            StartMinimized = false,
            OnboardingCompleted = false,
            WhatsAppEnabled = true,
            WhatsAppPollSeconds = 30,
            DefaultReminderMinutes = 120,
            NotificationCatchUpMinutes = 10,
            CloseDistractingProcesses = false,
            ForceCloseDistractingProcesses = false,
            FocusModes = new() { study, coding, gaming, sleep },
            CurrentModeId = "study",
            WhatsAppRules = new()
            {
                new WhatsAppWatchRule
                {
                    Id = "software-engineering",
                    Name = "Software Engineering",
                    ChatPattern = "*Software Engineering*",
                    TriggerMode = WhatsAppTriggerMode.Keywords,
                    Keywords = new() { "assignment", "practical", "deadline", "due", "submission", "submit", "test", "exam", "project" },
                    ReminderMinutes = 120,
                    Enabled = true,
                    AutoCreateTasks = true,
                    RecordActivity = true
                },
                new WhatsAppWatchRule
                {
                    Id = "general-academic",
                    Name = "Academic Deadlines",
                    ChatPattern = "*",
                    TriggerMode = WhatsAppTriggerMode.Keywords,
                    Keywords = new() { "assignment", "practical", "deadline", "due", "submission", "submit", "test", "exam" },
                    ReminderMinutes = 180,
                    Enabled = false,
                    AutoCreateTasks = true,
                    RecordActivity = true
                }
            }
        };
    }
}
