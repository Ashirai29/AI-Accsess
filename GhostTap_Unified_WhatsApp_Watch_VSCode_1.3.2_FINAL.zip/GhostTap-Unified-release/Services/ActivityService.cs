using GhostTap.Unified.Models;

namespace GhostTap.Unified.Services;

public sealed class ActivityService
{
    private readonly JsonStore<List<WhatsAppActivity>> _legacyStore;
    private readonly DatabaseService _database;
    private readonly object _sync = new();
    private List<WhatsAppActivity> _activities = new();
    private int _unhandledCount;

    public event EventHandler? ActivitiesChanged;

    public ActivityService(PathService paths, DatabaseService database)
    {
        _legacyStore = new JsonStore<List<WhatsAppActivity>>(paths.ActivitiesPath);
        _database = database;
    }

    public async Task LoadAsync()
    {
        if (_database.IsAvailable)
        {
            var recent = await _database.GetRecentActivitiesAsync(250).ConfigureAwait(false);
            lock (_sync) _activities = recent.Select(Clone).ToList();
            _unhandledCount = await _database.CountUnhandledActivitiesAsync().ConfigureAwait(false);
            return;
        }

        var legacy = await _legacyStore.LoadAsync().ConfigureAwait(false) ?? new List<WhatsAppActivity>();
        lock (_sync)
        {
            _activities = legacy.OrderByDescending(x => x.CreatedAt).Take(250).Select(Clone).ToList();
            _unhandledCount = legacy.Count(x => !x.IsHandled);
        }
    }

    public IReadOnlyList<WhatsAppActivity> GetRecent(int max = 100)
    {
        lock (_sync) return _activities.OrderByDescending(x => x.CreatedAt).Take(Math.Clamp(max, 1, 250)).Select(Clone).ToList();
    }

    public int GetUnhandledCount()
    {
        lock (_sync) return _unhandledCount;
    }

    public async Task AddAsync(WhatsAppActivity activity)
    {
        WhatsAppActivity? replaced;
        lock (_sync)
        {
            replaced = _activities.FirstOrDefault(x => x.NotificationKey.Equals(activity.NotificationKey, StringComparison.OrdinalIgnoreCase));
            _activities.RemoveAll(x => x.NotificationKey.Equals(activity.NotificationKey, StringComparison.OrdinalIgnoreCase));
            _activities.Insert(0, Clone(activity));
            if (_activities.Count > 250) _activities = _activities.Take(250).ToList();

            if (replaced is null)
            {
                if (!activity.IsHandled) _unhandledCount++;
            }
            else if (replaced.IsHandled != activity.IsHandled)
            {
                _unhandledCount += activity.IsHandled ? -1 : 1;
            }
        }

        if (_database.IsAvailable) await _database.UpsertActivityAsync(activity).ConfigureAwait(false);
        else await PersistLegacyAsync().ConfigureAwait(false);
        ActivitiesChanged?.Invoke(this, EventArgs.Empty);
    }

    public async Task MarkHandledAsync(string id)
    {
        var changed = false;
        lock (_sync)
        {
            var activity = _activities.FirstOrDefault(x => x.Id.Equals(id, StringComparison.OrdinalIgnoreCase));
            if (activity is not null && !activity.IsHandled)
            {
                activity.IsHandled = true;
                _unhandledCount = Math.Max(0, _unhandledCount - 1);
                changed = true;
            }
        }
        if (!changed) return;

        if (_database.IsAvailable) await _database.UpdateActivityHandledAsync(id, true).ConfigureAwait(false);
        else await PersistLegacyAsync().ConfigureAwait(false);
        ActivitiesChanged?.Invoke(this, EventArgs.Empty);
    }

    public async Task MarkAllHandledAsync()
    {
        lock (_sync)
        {
            foreach (var activity in _activities) activity.IsHandled = true;
            _unhandledCount = 0;
        }
        if (_database.IsAvailable) await _database.MarkAllActivitiesHandledAsync().ConfigureAwait(false);
        else await PersistLegacyAsync().ConfigureAwait(false);
        ActivitiesChanged?.Invoke(this, EventArgs.Empty);
    }

    public async Task ClearAsync()
    {
        lock (_sync)
        {
            _activities.Clear();
            _unhandledCount = 0;
        }
        if (_database.IsAvailable) await _database.ClearActivitiesAsync().ConfigureAwait(false);
        else await PersistLegacyAsync().ConfigureAwait(false);
        ActivitiesChanged?.Invoke(this, EventArgs.Empty);
    }

    public async Task DeleteAsync(string id)
    {
        var removedUnread = false;
        var removed = false;
        lock (_sync)
        {
            var activity = _activities.FirstOrDefault(x => x.Id.Equals(id, StringComparison.OrdinalIgnoreCase));
            if (activity is not null)
            {
                removedUnread = !activity.IsHandled;
                removed = _activities.RemoveAll(x => x.Id.Equals(id, StringComparison.OrdinalIgnoreCase)) > 0;
                if (removedUnread) _unhandledCount = Math.Max(0, _unhandledCount - 1);
            }
        }
        if (!removed) return;

        if (_database.IsAvailable) await _database.DeleteActivityAsync(id).ConfigureAwait(false);
        else await PersistLegacyAsync().ConfigureAwait(false);
        ActivitiesChanged?.Invoke(this, EventArgs.Empty);
    }

    private async Task PersistLegacyAsync()
    {
        List<WhatsAppActivity> snapshot;
        lock (_sync) snapshot = _activities.Select(Clone).ToList();
        await _legacyStore.SaveAsync(snapshot).ConfigureAwait(false);
    }

    private static WhatsAppActivity Clone(WhatsAppActivity activity) => new()
    {
        Id = activity.Id,
        Chat = activity.Chat,
        Sender = activity.Sender,
        Preview = activity.Preview,
        CreatedAt = activity.CreatedAt,
        IsHandled = activity.IsHandled,
        GeneratedTask = activity.GeneratedTask,
        NotificationKey = activity.NotificationKey
    };
}
