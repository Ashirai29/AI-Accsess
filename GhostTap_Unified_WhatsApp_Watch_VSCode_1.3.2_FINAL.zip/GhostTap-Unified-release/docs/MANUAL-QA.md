# Manual QA matrix

## Build and install

- [ ] `dotnet restore .\GhostTap.Unified.sln` completes without NU1213 or Windows SDK package-type errors.
- [ ] `dotnet build .\GhostTap.Unified.sln -c Release -p:Platform=x64 --no-restore` succeeds.
- [ ] `dotnet run --project .\tests\GhostTap.Unified.SmokeTests.csproj -c Release -p:Platform=x64 --no-restore` reports all tests passed.
- [ ] MSIX packaging succeeds with `scripts\Setup-GhostTap.ps1`.
- [ ] The signed MSIX installs for the current Windows user.
- [ ] GhostTap starts from the installed app identity.

## First-run onboarding

- [ ] Setup wizard appears once when `OnboardingCompleted=false`.
- [ ] Step 2 correctly distinguishes packaged and unpackaged execution.
- [ ] Packaged execution shows the actual notification access state.
- [ ] Granting permission changes the state to allowed without restarting the app.
- [ ] Windows notification settings opens.
- [ ] First rule can be saved for a group pattern.
- [ ] First rule can be saved for a private chat pattern.
- [ ] NFC step accurately shows reader availability.
- [ ] Finish writes `OnboardingCompleted=true`.

## WhatsApp Watch

- [ ] WhatsApp Desktop is installed/logged in.
- [ ] Windows notifications are enabled for WhatsApp.
- [ ] GhostTap notification access is allowed.
- [ ] `WhatsApp Watch` reports connected/waiting.
- [ ] A real WhatsApp group notification appears in Recent Activity after synchronization.
- [ ] A real private-chat notification appears in Recent Activity after synchronization.
- [ ] Keyword rule creates an expected task.
- [ ] Every-message rule records activity.
- [ ] Every-message + auto-task creates a task only when the setting is intentionally enabled.
- [ ] `two practicals and an assignment due Friday` produces Practical 1, Practical 2 and Assignment.
- [ ] `Practical 1 and 2` produces Practical 1 and Practical 2.
- [ ] `tomorrow`, weekday names, explicit dates and explicit times are parsed.
- [ ] Repeated notifications do not create duplicate tasks.
- [ ] Done stops the reminder.
- [ ] Snooze moves the next reminder.
- [ ] A reminder popup does not block the main application.

## NFC

- [ ] A PC/SC reader is enumerated.
- [ ] Reader removal is detected.
- [ ] Bind → tap card creates a binding.
- [ ] A UID-based card reactivates its bound mode after removal/reinsert.
- [ ] ATR-only fallback displays the uniqueness warning.
- [ ] Unknown card shows a bind instruction instead of failing silently.
- [ ] Removing a binding stops the card from triggering its former mode.

## Modes

- [ ] Coding Mode launches its configured targets.
- [ ] Gaming Mode launches its configured targets.
- [ ] Study Mode respects its configured process-closing list.
- [ ] Sleep Mode pauses reminders.
- [ ] Leaving Sleep Mode resumes reminders.
- [ ] A failed target does not prevent later targets from running.

## Persistence

- [ ] Close and reopen GhostTap.
- [ ] Tasks persist.
- [ ] Rules persist.
- [ ] Card bindings persist.
- [ ] Completed tasks stay completed.
- [ ] Corrupt JSON files are backed up rather than crashing startup.
