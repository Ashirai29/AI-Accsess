# GhostTap Unified architecture

## Components

`MainForm`
- primary navigation and dashboard
- setup wizard launcher
- task/rule/mode editors
- diagnostics

`SetupWizardForm`
- first-run onboarding
- package identity warning
- notification permission flow
- first WhatsApp rule
- NFC introduction

`WhatsAppWatcherService`
- checks package identity before using Windows notification APIs
- requests user permission from the UI flow
- uses `NotificationChanged` for low-latency refresh
- keeps periodic synchronization as a recovery/safety net
- de-duplicates notifications by app/notification ID/content
- extracts WhatsApp notification text

`WhatsAppParser`
- chat rule matching
- keyword/every-message matching
- task extraction
- quantity expansion (for example two practicals)
- date and time extraction
- deterministic task detection keys

`TaskService`
- local persistent task state
- duplicate task suppression
- complete/reopen/snooze
- adaptive reminder scheduling

`ReminderService`
- background due-task check
- non-blocking reminder popups via the main form
- task reminder events

`NfcService`
- PC/SC reader enumeration
- monitor creation/removal
- UID APDU read
- ATR fallback with uniqueness flag

`AutomationService`
- focus-mode target launch
- optional process closing
- reminder pause/resume by mode

`SettingsService`
- local configuration and backwards-compatible default merging

## WhatsApp data path

`Windows notification listener → WhatsAppWatcherService → WhatsAppParser → ActivityService/TaskService → ReminderService`

The listener requires package identity, a manifest capability, and user access. The project therefore deliberately avoids silently attempting notification access from the normal unpackaged developer EXE.
