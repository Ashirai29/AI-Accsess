# WhatsApp Watch — boundaries

GhostTap Watch is intentionally a **notification integration**, not an unofficial WhatsApp account API.

It can use Windows-exposed WhatsApp notifications for both group and private chat rules. Windows grants notification-listener access at the OS level; GhostTap locally filters that stream to notifications whose app name is recognised as WhatsApp.

It cannot guarantee access to the complete WhatsApp conversation history, exact WhatsApp unread counters, or message content that Windows/WhatsApp withholds from a notification.

The strongest workflow is therefore:

`Select important chats → enable useful keywords → capture matching activity → create persistent tasks → remind until Done`

Use every-message matching only for small, high-value chats because an automatic task for every message can become noisy.
