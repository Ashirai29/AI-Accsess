# NFC hardware notes

GhostTap uses PC/SC reader APIs. Your reader needs a working Windows driver and the Windows Smart Card service must be available.

## UID path

The implementation first tries the common `FF CA 00 00 00` GET DATA request used by many RFID/NFC readers to expose a tag UID. Some readers do not support it. In that case, the app tries to use the card ATR as a fallback identity.

## Troubleshooting

1. Confirm the reader appears in Windows Device Manager.
2. Confirm the vendor driver is installed.
3. Confirm the Windows Smart Card service is running.
4. Start GhostTap and open **NFC & Modes**.
5. Insert the NFC card and watch the reader status.
6. If a card is detected but no UID appears, the reader/card combination likely needs a vendor-specific APDU or another identity method.

Do not assume all NFC cards are writable just because they can be detected. GhostTap's current use case only needs a stable identity for triggering local automation.
