# GhostTap Unified — User Guide

## What GhostTap is

GhostTap Unified is a Windows desktop assistant with two connected systems:

- **NFC automation:** tap a configured NFC card to launch a focus mode.
- **WhatsApp Watch:** read WhatsApp notifications exposed by Windows, match only the chats/rules you choose, create persistent tasks, detect common deadlines, and keep reminding you until you mark the task Done.

The application stores its task/rule/activity data locally in:

`%LocalAppData%\GhostTapUnified\`

## First run

GhostTap opens a five-step setup wizard the first time it runs.

### Step 1 — Welcome

The wizard explains the two systems. You can complete setup or leave it and return later through **System Check**.

### Step 2 — WhatsApp connection

WhatsApp Watch uses the Windows notification listener. The application therefore needs:

1. Windows 10/11 with a supported API level.
2. GhostTap installed with MSIX/package identity.
3. The `userNotificationListener` capability in that package.
4. User permission from Windows.
5. WhatsApp Desktop notifications enabled.

The wizard tells you when the application is unpackaged and therefore cannot activate WhatsApp Watch.

Use **Grant notification access** only after the wizard has explained why the permission is needed. This follows Microsoft's notification-listener guidance to explain the permission before requesting it.

After access is allowed:

1. Open WhatsApp on Windows.
2. Send yourself a message from another phone/account or ask someone to send a test message.
3. Return to GhostTap.
4. Keep **WhatsApp Watch** open while the listener waits in the background.
5. Use **Refresh notifications** when testing, and look for the **Last captured** line and **Recent Activity**.
6. If you grant notification access later from Windows Settings, GhostTap now re-checks access periodically and can reconnect without a restart.

### Step 3 — First rule

A rule has:

- a name;
- a group/private chat pattern;
- keywords or every-message matching;
- a reminder interval;
- whether tasks are automatically created;
- whether matching activity is recorded.

Both **groups and private chats** are supported. The chat pattern is case-insensitive and accepts `*` as a wildcard.

Examples:

`*Software Engineering*`

`*John Smith*`

`Enactus`

`*Project Team*`

For a busy class group, use keyword mode. For a small private/project chat, every-message matching can be useful.

### Step 4 — NFC

Connect a PC/SC-compatible NFC reader and wait for the reader to appear in **NFC & Modes**. The default Study Mode opens UFS Blackboard and Spotify's current Deep Focus playlist, and you can edit both targets before binding the card.

To bind a card:

1. Open **NFC & Modes**.
2. Press **Bind** next to a mode.
3. Put the NFC card on the reader.
4. GhostTap records the card identity and binds it to that mode.
5. Remove the card.
6. Tap the same card again to activate the mode.

UID is preferred because it identifies an individual card. If the hardware only exposes an ATR, GhostTap warns that the identity may describe a card technology/profile rather than a unique physical card.

### Step 5 — Finish

After the wizard, GhostTap can sit in the system tray and continue running in the background.

## WhatsApp Watch in normal use

The flow is:

`WhatsApp notification → GhostTap rule match → Activity → Task → Reminder → Done`

The same pipeline works for group and private conversations.

### Example

A Software Engineering group notification says:

`There are two practicals and an assignment due Friday at 14:00.`

With the standard Software Engineering rule enabled, GhostTap can create:

- Practical 1
- Practical 2
- Assignment

and attach a Friday 14:00 deadline.

GhostTap uses deterministic message parsing rather than an external AI service. You should still verify any automatically inferred deadline against the real instruction.

### Reminder behaviour

Tasks stay open until the user marks them Done.

As a deadline approaches, the reminder interval tightens. The service checks roughly every 20 seconds for due reminders, but the next reminder time is stored with the task so reminders persist across application restarts.

The reminder window provides:

- **Done** — closes the task and stops future reminders.
- **Snooze 30m** — postpones the next reminder.
- **Open WhatsApp** — opens the WhatsApp URI, with a web fallback.

## WhatsApp limitations

GhostTap does not log into your WhatsApp account and does not read WhatsApp's private database.

The current integration sees the notification information Windows exposes. Therefore it cannot guarantee:

- every historical WhatsApp message;
- exact WhatsApp unread counts;
- message content when notification previews are hidden;
- internal WhatsApp state that never reaches Windows notifications.

## NFC limitations

Reader/card behaviour is hardware-dependent. The project uses PC/SC and first tries a common UID APDU. If that is not supported, it may use an ATR fingerprint with an explicit uniqueness warning.

## Recommended setup

For a student workflow:

### Software Engineering

Chat pattern:

`*Software Engineering*`

Keywords:

`assignment, practical, deadline, due, submission, submit, test, exam, project`

Auto-create tasks:

`On`

Every-message mode:

`Off`

### Enactus

Chat pattern:

`*Enactus*`

Keywords:

`meeting, deadline, submission, presentation, BMC, pitch`

### Project/private chat

Chat pattern:

`*Project Team*` or the person's name.

Use every-message mode only when the chat is small enough that each message is relevant.

## If WhatsApp says it is not connected

Open **System Check**.

The order to troubleshoot is:

1. **Package identity** — install the MSIX build.
2. **WhatsApp access** — grant notification access.
3. **Windows notifications** — make sure WhatsApp notifications are enabled.
4. **WhatsApp Watch rules** — ensure the rule is enabled and its chat pattern matches the notification title.
6. **Refresh notifications** — force one synchronization.
7. **Last captured** — confirm GhostTap actually received a WhatsApp notification.
8. **Recent Activity** — confirm the rule matched.
9. **Tasks** — confirm the task was created.

## If an NFC card is detected but does nothing

Open **NFC & Modes** and check:

1. A reader appears.
2. The card has a binding.
3. The binding points to an existing mode.
4. The card was fully removed and then tapped again.
5. The reader driver is installed.

A UID-based identity is strongly preferred.
