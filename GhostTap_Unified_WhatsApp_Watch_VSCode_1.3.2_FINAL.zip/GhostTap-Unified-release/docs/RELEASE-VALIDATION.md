
## 1.3.2 — architecture hardening and persistence upgrade

- Added compact `ghosttap://` command URI generation and NFC Forum URI NDEF Type 2 encoding/validation.
- Added PC/SC Type 2 NDEF command-tag writing with read-back verification.
- Kept UID/ATR binding as the primary physical-card workflow.
- Moved WhatsApp parser categories, app-name patterns, number words, date/time regexes and parser limits to external JSON configuration with safe validation and live reload.
- Hardened regex execution against invalid patterns and match timeouts.
- Kept WhatsApp polling/notification synchronization and NFC reads/writes off the WinForms UI thread with cancellation-aware async flows.
- Added SQLite persistence for tasks and WhatsApp activity history with WAL mode, indexed queries and legacy JSON migration.
- Persisted reminder pause state so protocol/NFC pause and sleep commands survive process restarts.
- Expanded smoke tests for URI/NDEF round-trips, parser reloads and SQLite state recovery.


## 1.1.2 — final hardening and setup polish

- Fixed parser whitespace fallback and added bare `2pm`/`9am` and month-first date parsing.
- Added periodic Windows notification-access revalidation so permission revocation is surfaced instead of silently looking connected.
- Added clear-captured-activity control without deleting tasks.
- Added re-run-onboarding action in Settings.
- Improved wizard layout, scrolling, privacy explanation and live WhatsApp test guidance.
- Added safer startup diagnostics and tray reminder state initialisation.
- Added automatic permission re-checking after Windows Settings changes, so WhatsApp Watch can reconnect without restarting GhostTap.
- Prevented completed tasks from being resurrected by duplicate mentions and improved no-deadline de-duplication.
- Added first-rule validation so keyword mode cannot be saved with an empty keyword set.


## 1.1.0 — Unified reliability + onboarding

- Added a five-step first-run setup wizard.
- Added an explicit package-identity check for WhatsApp Watch.
- Stopped the unpackaged build from repeatedly attempting an unsupported notification-listener flow.
- Added a guided Windows notification permission flow.
- Added group and private-chat rule language in the onboarding UI.
- Added every-message vs keyword trigger selection.
- Added activity-recording control separate from task creation.
- Added event-driven WhatsApp synchronization through `NotificationChanged` with periodic recovery polling.
- Added notification-ID-aware de-duplication.
- Improved WhatsApp notification text parsing for one-, two- and three-line notification shapes.
- Improved task title extraction for quantities and paired numbering such as `Practical 1 and 2`.
- Added explicit-time parsing.
- Made task detection keys stable across repeated reminder messages.
- Added System Check diagnostics page.
- Added NFC UID/non-unique ATR identity awareness and warning.
- Added reader refresh and last-scan diagnostics.
- Made reminder popups non-blocking.
- Added Reopen task support.
- Added local smoke-test project and `scripts\Verify.ps1`.
- Added simplified `scripts\Setup-GhostTap.ps1` for development MSIX installation.
- Removed the incompatible `Microsoft.Windows.SDK.NET.Ref` PackageReference from the project.


## 1.3.2 enhancement gates

- NFC command URI: `ghosttap://trigger?action=<mode>` is generated, encoded as a compact Type 2 URI NDEF message and read back after write.
- WhatsApp parser configuration: `Config/whatsapp-parser.json` is copied to `%LocalAppData%\GhostTapUnified\whatsapp-parser.json`; changes can be reloaded without rebuilding.
- Async responsiveness: NFC refresh, card reads/writes, WhatsApp synchronization and reminder loops execute outside the WinForms UI thread and accept cancellation where appropriate.
- SQLite: `GhostTap.db` stores Tasks and Activities; first-run migration imports legacy `tasks.json` / `activities.json` and preserves backups.
