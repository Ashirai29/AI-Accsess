# GhostTap Unified 1.3.2 — Final Validation

## What was validated in the build workspace

- NFC custom `ghosttap://` command URI generation and validation.
- NFC Forum short URI NDEF encoding/parsing and conservative Type 2 payload size guard.
- PC/SC NFC monitoring uses `ISCardMonitor` and background tasks.
- WhatsApp parser loads `Config/whatsapp-parser.json` and reloads it when modified without recompilation.
- Parser configuration includes chat matching, keywords, task categories, quantity parsing, date/time patterns, and recognised WhatsApp app names.
- WhatsApp watcher uses cancellation-aware asynchronous polling, notification sync gates, and background processing.
- SQLite task/activity persistence via `Microsoft.Data.Sqlite`; JSON remains for lightweight settings and notification de-duplication.
- Custom Windows `ghosttap:` protocol registration is included in the MSIX manifest.
- Running-instance protocol commands are relayed through an asynchronous named-pipe bridge.
- Prior known compile issues were removed, including the invalid `Convert.ToHexString(byte[], string)` call.
- Project/solution XML and JSON files can be parsed statically.
- Source files pass structural brace/parenthesis/bracket checks.

## Windows-only final validation

This release was prepared in a Linux container. A real Windows/.NET compilation, MSIX installation, live Windows notification-listener permission flow, PC/SC reader interaction, and physical NFC tag write/read cannot be executed in this environment.

On a Windows 10/11 x64 machine with the .NET 8 SDK installed, run:

```powershell
.\scripts\Verify.ps1
```

Then perform the manual cases in `docs/MANUAL-QA.md`, especially:

1. Install the MSIX package.
2. Complete first-run onboarding.
3. Grant Windows notification access.
4. Send a real WhatsApp group message and a real private-chat message matching configured rules.
5. Verify task creation, reminder, snooze and completion.
6. Bind an NFC UID/ATR card to a mode.
7. Write and verify a GhostTap NDEF command on a compatible Type 2 tag.
8. Tap the tag while GhostTap is already running.
9. Launch a `ghosttap://trigger?action=study` URI from Windows and verify single-instance handling.
