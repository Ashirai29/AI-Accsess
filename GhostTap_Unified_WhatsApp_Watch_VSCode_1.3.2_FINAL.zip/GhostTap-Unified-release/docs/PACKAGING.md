# Packaging and notification listener capability

The source project can run as an ordinary unpackaged WinForms desktop executable. For the WhatsApp Watch notification-listener path, the repository also includes an optional MSIX manifest that declares the `uap3:userNotificationListener` capability and the `runFullTrust` capability.

Microsoft's current notification-listener documentation requires the User Notification Listener capability to be declared in the package manifest and requires user permission at runtime.

## Recommended local build

Open PowerShell in the repository root and run:

```powershell
.\scripts\Publish.ps1
```

For an MSIX build:

```powershell
.\scripts\Package-MSIX.ps1
```

Then install the local package:

```powershell
.\scripts\Install-MSIX.ps1
```

The packaging script expects a Windows SDK installation that includes `makeappx.exe` and `signtool.exe`.

## Development certificates

The script creates or reuses a local code-signing certificate for `CN=GHOSTTECH.Ashirai`. A locally generated certificate is suitable for development/testing, not public distribution. Windows must trust the certificate before the package will install normally.

## Why the project keeps an unpackaged path

The NFC automation and local checklist/reminder engine do not require MSIX. Keeping the executable runnable unpackaged makes development and debugging simple, while the included package manifest gives the project a clean path to a package identity and the notification-listener capability.
