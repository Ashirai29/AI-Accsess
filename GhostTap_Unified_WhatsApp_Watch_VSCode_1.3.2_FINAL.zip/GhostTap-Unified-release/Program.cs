using GhostTap.Unified.Services;
using GhostTap.Unified.UI;

namespace GhostTap.Unified;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        if (ProtocolActivationService.TryGetUri(out var activationUri) && activationUri is not null)
        {
            // If GhostTap is already running, execute the URI in that live instance.
            // Otherwise this process handles the command directly and exits.
            if (ProtocolBridgeService.TrySendToRunningInstanceAsync(activationUri).GetAwaiter().GetResult()) return;
            _ = ProtocolActivationService.HandleAsync(activationUri).GetAwaiter().GetResult();
            return;
        }

        using var instance = new SingleInstanceService();
        if (!instance.TryAcquire())
        {
            MessageBox.Show(
                "GhostTap Unified is already running. Check the Windows notification area.",
                "GhostTap Unified",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return;
        }

        Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
        Application.ThreadException += (_, e) => ShowUnhandledError(e.Exception);
        AppDomain.CurrentDomain.UnhandledException += (_, e) =>
        {
            if (e.ExceptionObject is Exception exception)
            {
                try { File.AppendAllText(GetCrashLogPath(), FormatCrash(exception)); } catch { }
            }
        };

        ApplicationConfiguration.Initialize();
        var services = new AppServices();
        try
        {
            using var form = new MainForm(services);
            Application.Run(form);
        }
        finally
        {
            services.DisposeAsync().AsTask().GetAwaiter().GetResult();
        }
    }

    private static void ShowUnhandledError(Exception exception)
    {
        try
        {
            File.AppendAllText(GetCrashLogPath(), FormatCrash(exception));
            MessageBox.Show(
                $"GhostTap handled an unexpected error and wrote it to the local crash log.\n\n{exception.Message}",
                "GhostTap error",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
        catch
        {
        }
    }

    private static string GetCrashLogPath()
    {
        var folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "GhostTapUnified");
        Directory.CreateDirectory(folder);
        return Path.Combine(folder, "crash.log");
    }

    private static string FormatCrash(Exception exception) =>
        $"[{DateTimeOffset.Now:O}] {exception}\r\n\r\n";
}
