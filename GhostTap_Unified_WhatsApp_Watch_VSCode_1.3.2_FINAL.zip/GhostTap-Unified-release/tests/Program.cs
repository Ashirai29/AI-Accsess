using System.Text.Json;
using GhostTap.Unified.Models;
using GhostTap.Unified.Services;

var tests = new List<(string Name, Action Test)>
{
    ("Keyword rule matches a group", () =>
    {
        using var scope = TestScope.Create();
        var parser = new WhatsAppParser(scope.Paths);
        var item = new WhatsAppNotificationItem { Chat = "Software Engineering", Body = "Assignment due Friday", CreatedAt = DateTimeOffset.Now };
        var rules = new[] { new WhatsAppWatchRule { ChatPattern = "*Software Engineering*", Keywords = new() { "assignment" }, AutoCreateTasks = true } };
        Assert(parser.MatchingRules(item, rules).Count == 1, "Expected one matching rule.");
    }),
    ("Private chat wildcard matches", () =>
    {
        using var scope = TestScope.Create();
        var parser = new WhatsAppParser(scope.Paths);
        var item = new WhatsAppNotificationItem { Chat = "John Smith", Body = "Project meeting tomorrow", CreatedAt = DateTimeOffset.Now };
        var rules = new[] { new WhatsAppWatchRule { ChatPattern = "*John Smith*", Keywords = new() { "project" }, AutoCreateTasks = true } };
        Assert(parser.MatchingRules(item, rules).Count == 1, "Expected private chat to match.");
    }),
    ("Two practicals are expanded", () =>
    {
        using var scope = TestScope.Create();
        var parser = new WhatsAppParser(scope.Paths);
        var item = new WhatsAppNotificationItem { Chat = "Software Engineering", Body = "There are two practicals and an assignment due Friday", CreatedAt = DateTimeOffset.Now };
        var rules = new[] { new WhatsAppWatchRule { ChatPattern = "*", Keywords = new() { "practical" }, AutoCreateTasks = true } };
        var candidates = parser.Extract(item, rules);
        Assert(candidates.Count == 3, $"Expected 3 tasks, received {candidates.Count}.");
        Assert(candidates.Any(x => x.Title.Equals("Practical 1", StringComparison.OrdinalIgnoreCase)), "Practical 1 missing.");
        Assert(candidates.Any(x => x.Title.Equals("Practical 2", StringComparison.OrdinalIgnoreCase)), "Practical 2 missing.");
        Assert(candidates.Any(x => x.Title.Equals("Assignment", StringComparison.OrdinalIgnoreCase)), "Assignment missing.");
    }),
    ("Practical 1 and 2 are expanded", () =>
    {
        using var scope = TestScope.Create();
        var parser = new WhatsAppParser(scope.Paths);
        var item = new WhatsAppNotificationItem { Chat = "Software Engineering", Body = "Practical 1 and 2 are due tomorrow", CreatedAt = DateTimeOffset.Now };
        var rules = new[] { new WhatsAppWatchRule { ChatPattern = "*", Keywords = new() { "practical" }, AutoCreateTasks = true } };
        var candidates = parser.Extract(item, rules);
        Assert(candidates.Count == 2, $"Expected only two paired practical tasks, received {candidates.Count}.");
        Assert(candidates.Any(x => x.Title.Equals("Practical 1", StringComparison.OrdinalIgnoreCase)), "Practical 1 missing.");
        Assert(candidates.Any(x => x.Title.Equals("Practical 2", StringComparison.OrdinalIgnoreCase)), "Practical 2 missing.");
    }),
    ("Tomorrow gets a deadline", () =>
    {
        using var scope = TestScope.Create();
        var parser = new WhatsAppParser(scope.Paths);
        var created = new DateTimeOffset(2026, 10, 5, 12, 0, 0, TimeSpan.FromHours(2));
        var item = new WhatsAppNotificationItem { Chat = "Class", Body = "Assignment due tomorrow", CreatedAt = created };
        var rules = new[] { new WhatsAppWatchRule { ChatPattern = "*", Keywords = new() { "assignment" }, AutoCreateTasks = true } };
        var due = parser.Extract(item, rules).Single().DueAt;
        Assert(due.HasValue && due.Value.Date == created.Date.AddDays(1), "Tomorrow deadline was not detected.");
    }),
    ("Explicit time is preserved", () =>
    {
        using var scope = TestScope.Create();
        var parser = new WhatsAppParser(scope.Paths);
        var created = new DateTimeOffset(2026, 10, 5, 12, 0, 0, TimeSpan.FromHours(2));
        var item = new WhatsAppNotificationItem { Chat = "Class", Body = "Assignment due Friday at 14:00", CreatedAt = created };
        var rules = new[] { new WhatsAppWatchRule { ChatPattern = "*", Keywords = new() { "assignment" }, AutoCreateTasks = true } };
        var due = parser.Extract(item, rules).Single().DueAt;
        Assert(due.HasValue && due.Value.Hour == 14 && due.Value.Minute == 0, "Explicit time was not preserved.");
    }),
    ("Fallback title collapses whitespace", () =>
    {
        using var scope = TestScope.Create();
        var parser = new WhatsAppParser(scope.Paths);
        var item = new WhatsAppNotificationItem { Chat = "Project Team", Body = "Please   review\nthis draft.", CreatedAt = DateTimeOffset.Now };
        var rules = new[] { new WhatsAppWatchRule { ChatPattern = "Project Team", Keywords = new() { "review" }, AutoCreateTasks = true } };
        var candidate = parser.Extract(item, rules).Single();
        Assert(candidate.Title == "Please review this draft.", $"Unexpected fallback title: {candidate.Title}");
    }),
    ("Bare am/pm time is parsed", () =>
    {
        using var scope = TestScope.Create();
        var parser = new WhatsAppParser(scope.Paths);
        var created = new DateTimeOffset(2026, 10, 5, 12, 0, 0, TimeSpan.FromHours(2));
        var item = new WhatsAppNotificationItem { Chat = "Class", Body = "Assignment due Friday at 2pm", CreatedAt = created };
        var rules = new[] { new WhatsAppWatchRule { ChatPattern = "*", Keywords = new() { "assignment" }, AutoCreateTasks = true } };
        var due = parser.Extract(item, rules).Single().DueAt;
        Assert(due.HasValue && due.Value.Hour == 14 && due.Value.Minute == 0, "Bare am/pm time was not parsed.");
    }),
    ("Month-first date is parsed", () =>
    {
        using var scope = TestScope.Create();
        var parser = new WhatsAppParser(scope.Paths);
        var created = new DateTimeOffset(2026, 10, 5, 12, 0, 0, TimeSpan.FromHours(2));
        var item = new WhatsAppNotificationItem { Chat = "Class", Body = "Assignment due Oct 12", CreatedAt = created };
        var rules = new[] { new WhatsAppWatchRule { ChatPattern = "*", Keywords = new() { "assignment" }, AutoCreateTasks = true } };
        var due = parser.Extract(item, rules).Single().DueAt;
        Assert(due.HasValue && due.Value.Date == new DateTime(2026, 10, 12), "Month-first date was not parsed.");
    }),
    ("Any-message rule creates a task only when enabled", () =>
    {
        using var scope = TestScope.Create();
        var parser = new WhatsAppParser(scope.Paths);
        var item = new WhatsAppNotificationItem { Chat = "Project Team", Body = "Please review the draft", CreatedAt = DateTimeOffset.Now };
        var disabled = new WhatsAppWatchRule { ChatPattern = "Project Team", TriggerMode = WhatsAppTriggerMode.AnyMessage, AutoCreateTasks = false };
        Assert(parser.Extract(item, new[] { disabled }).Count == 0, "Disabled auto-task rule should create no task.");
        var enabled = new WhatsAppWatchRule { ChatPattern = "Project Team", TriggerMode = WhatsAppTriggerMode.AnyMessage, AutoCreateTasks = true };
        Assert(parser.Extract(item, new[] { enabled }).Count == 1, "Enabled any-message task rule should create a task.");
    }),
    ("No-deadline task keys are day-scoped", () =>
    {
        using var scope = TestScope.Create();
        var parser = new WhatsAppParser(scope.Paths);
        var rules = new[] { new WhatsAppWatchRule { ChatPattern = "*", Keywords = new() { "assignment" }, AutoCreateTasks = true } };
        var first = parser.Extract(new WhatsAppNotificationItem
        { Chat = "Class", Body = "Assignment to submit", CreatedAt = new DateTimeOffset(2026, 10, 5, 10, 0, 0, TimeSpan.FromHours(2)) }, rules).Single();
        var second = parser.Extract(new WhatsAppNotificationItem
        { Chat = "Class", Body = "Assignment to submit", CreatedAt = new DateTimeOffset(2026, 10, 6, 10, 0, 0, TimeSpan.FromHours(2)) }, rules).Single();
        Assert(!first.DetectionKey.Equals(second.DetectionKey, StringComparison.OrdinalIgnoreCase), "No-deadline keys should not suppress a future day's task.");
    }),
    ("External parser configuration loads", () =>
    {
        using var scope = TestScope.Create();
        var config = new WhatsAppParserConfiguration
        {
            Version = 2,
            RecognizedAppNamePatterns = new() { "WhatsApp" },
            Categories = new() { "lab" },
            NumberWords = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase) { ["one"] = 1, ["two"] = 2 },
            MaxTaskTitles = 4,
            MaxQuantityPerCategory = 4,
            DefaultDueTime = "18:00",
            Patterns = new()
        };
        File.WriteAllText(scope.Paths.WhatsAppParserConfigPath, JsonSerializer.Serialize(config, new JsonSerializerOptions { WriteIndented = true }));
        var parser = new WhatsAppParser(scope.Paths);
        var message = new WhatsAppNotificationItem { Chat = "Labs", Body = "Lab 2 is due Friday", CreatedAt = DateTimeOffset.Now };
        var rule = new WhatsAppWatchRule { ChatPattern = "*", Keywords = new() { "lab" }, AutoCreateTasks = true };
        Assert(parser.Extract(message, new[] { rule }).Any(x => x.Title.Equals("Lab 2", StringComparison.OrdinalIgnoreCase)), "External lab category was not loaded.");
        Assert(parser.ConfigurationStatus.Contains("External parser configuration loaded", StringComparison.OrdinalIgnoreCase), "Parser did not report the external configuration as active.");
    }),
    ("External parser app-name patterns are respected", () =>
    {
        using var scope = TestScope.Create();
        var config = new WhatsAppParserConfiguration
        {
            Version = 3,
            RecognizedAppNamePatterns = new() { "WhatsApp Custom" },
            Categories = new() { "assignment" },
            NumberWords = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase) { ["one"] = 1 },
            Patterns = new()
        };
        File.WriteAllText(scope.Paths.WhatsAppParserConfigPath, JsonSerializer.Serialize(config));
        var parser = new WhatsAppParser(scope.Paths);
        Assert(parser.IsWhatsAppAppName("WhatsApp Custom"), "Configured WhatsApp app name should be recognised.");
        Assert(!parser.IsWhatsAppAppName("WhatsApp"), "Hard-coded WhatsApp app-name matching should not bypass external configuration.");
    }),
    ("External parser configuration reloads without rebuild", () =>
    {
        using var scope = TestScope.Create();
        var parser = new WhatsAppParser(scope.Paths);
        var first = new WhatsAppNotificationItem { Chat = "Class", Body = "Lab 1 is ready", CreatedAt = DateTimeOffset.Now };
        var rule = new WhatsAppWatchRule { ChatPattern = "*", Keywords = new() { "lab" }, AutoCreateTasks = true };
        Assert(parser.Extract(first, new[] { rule }).Count > 0, "Default parser should recognize lab.");

        var config = parser.GetCurrentConfiguration();
        config.Categories = new() { "viva" };
        File.WriteAllText(scope.Paths.WhatsAppParserConfigPath, JsonSerializer.Serialize(config, new JsonSerializerOptions { WriteIndented = true }));
        parser.ReloadConfiguration();

        var second = new WhatsAppNotificationItem { Chat = "Class", Body = "Viva 1 is ready", CreatedAt = DateTimeOffset.Now };
        var vivaRule = new WhatsAppWatchRule { ChatPattern = "*", Keywords = new() { "viva" }, AutoCreateTasks = true };
        Assert(parser.Extract(second, new[] { vivaRule }).Any(x => x.Title.Equals("Viva 1", StringComparison.OrdinalIgnoreCase)), "Parser configuration did not reload without rebuilding.");
    }),
    ("GhostTap URI validates and round-trips through Type 2 NDEF", () =>
    {
        var uri = NfcPayloadService.BuildModeUri("study");
        Assert(NfcPayloadService.TryValidateGhostTapUri(uri, out var valid) && valid is not null, "GhostTap URI should validate.");
        var tlv = NfcPayloadService.BuildType2NdefTlv(uri);
        Assert(tlv.Length <= NfcPayloadService.ConservativeType2CapacityBytes, "NDEF payload exceeds the conservative Type 2 capacity.");
        Assert(NfcPayloadService.TryParseGhostTapUri(tlv, out var parsed) && parsed is not null, "NDEF parser should recover the GhostTap URI.");
        Assert(parsed!.ToString().Equals(uri, StringComparison.OrdinalIgnoreCase), "Recovered URI did not match the original.");
    }),
    ("Invalid GhostTap URI commands are rejected", () =>
    {
        Assert(!NfcPayloadService.TryValidateGhostTapUri("http://trigger?action=study", out _), "Non-GhostTap schemes must be rejected.");
        Assert(!NfcPayloadService.TryValidateGhostTapUri("ghosttap://trigger", out _), "Commands without an action/mode must be rejected.");
        Assert(!NfcPayloadService.TryValidateGhostTapUri("ghosttap://other?action=study", out _), "Unexpected GhostTap hosts must be rejected.");
    }),
    ("SQLite task state survives reload", () =>
    {
        using var scope = TestScope.Create(withDatabase: true);
        var service = scope.Tasks!;
        var created = service.AddCandidateAsync(new TaskCandidate
        {
            Title = "Reload check", SourceChat = "Test", SourcePreview = "Persist me",
            ReminderMinutes = 60, DetectionKey = Guid.NewGuid().ToString("N")
        }).GetAwaiter().GetResult();
        var reloaded = new TaskService(scope.Paths, scope.Database!);
        reloaded.LoadAsync().GetAwaiter().GetResult();
        Assert(reloaded.Get(created.Id)?.Title == "Reload check", "Task was not restored from SQLite after reload.");
    }),
    ("SQLite preserves completed duplicate tasks", () =>
    {
        using var scope = TestScope.Create(withDatabase: true);
        var candidate = new TaskCandidate
        {
            Title = "Practical 1", SourceChat = "Software Engineering", SourcePreview = "Practical 1",
            DueAt = new DateTimeOffset(2026, 10, 9, 18, 0, 0, TimeSpan.FromHours(2)),
            ReminderMinutes = 120, DetectionKey = "duplicate-key"
        };
        var created = scope.Tasks!.AddCandidateAsync(candidate).GetAwaiter().GetResult();
        scope.Tasks.CompleteAsync(created.Id).GetAwaiter().GetResult();
        scope.Tasks.AddCandidateAsync(candidate).GetAwaiter().GetResult();
        var persisted = scope.Tasks.Get(created.Id);
        Assert(persisted?.Status == GhostTaskStatus.Done, "A duplicate notification should not resurrect a completed task.");
        Assert(persisted?.Occurrences == 2, "Duplicate mention should still increment occurrence history.");
    }),
    ("SQLite activity history survives reload and handled state", () =>
    {
        using var scope = TestScope.Create(withDatabase: true);
        var activity = new WhatsAppActivity
        {
            Chat = "Software Engineering", Sender = "Lecturer", Preview = "Assignment due Friday",
            CreatedAt = DateTimeOffset.Now, NotificationKey = "activity-key", IsHandled = false, GeneratedTask = true
        };
        scope.Activities!.AddAsync(activity).GetAwaiter().GetResult();
        var reloaded = new ActivityService(scope.Paths, scope.Database!);
        reloaded.LoadAsync().GetAwaiter().GetResult();
        Assert(reloaded.GetRecent().Any(x => x.NotificationKey == "activity-key"), "Activity was not restored from SQLite.");
        reloaded.MarkHandledAsync(reloaded.GetRecent().Single(x => x.NotificationKey == "activity-key").Id).GetAwaiter().GetResult();
        Assert(reloaded.GetUnhandledCount() == 0, "Handled activity should no longer be counted as unhandled.");
    }),
    ("Settings contain the core modes", () =>
    {
        var settings = SettingsService.CreateDefaults();
        Assert(settings.FocusModes.Count == 4, "Expected four focus modes.");
        Assert(settings.FocusModes.Any(x => x.Id == "sleep" && x.PauseReminders), "Sleep mode should pause reminders.");
        var study = settings.FocusModes.Single(x => x.Id == "study");
        Assert(study.Targets.Any(x => x.Value == "https://learn.ufs.ac.za"), "Study Mode Blackboard target missing.");
        Assert(study.Targets.Any(x => x.Value.Contains("37i9dQZF1DWZeKCadgRdKQ", StringComparison.Ordinal)), "Study Mode focus playlist target missing.");
        Assert(settings.WhatsAppRules.Any(x => x.Id == "software-engineering"), "Software Engineering rule missing.");
    })
};

var failures = new List<string>();
foreach (var (name, test) in tests)
{
    try
    {
        test();
        Console.WriteLine($"PASS  {name}");
    }
    catch (Exception ex)
    {
        failures.Add($"FAIL  {name}: {ex.Message}");
        Console.WriteLine(failures[^1]);
    }
}

Console.WriteLine();
Console.WriteLine($"Smoke tests: {tests.Count - failures.Count}/{tests.Count} passed.");
Environment.ExitCode = failures.Count == 0 ? 0 : 1;

static void Assert(bool condition, string message)
{
    if (!condition) throw new InvalidOperationException(message);
}

sealed class TestScope : IDisposable
{
    private TestScope(string root, bool withDatabase)
    {
        Root = root;
        Paths = new PathService(root);
        if (withDatabase)
        {
            Database = new DatabaseService(Paths);
            Database.InitializeAsync(Paths).GetAwaiter().GetResult();
            if (!Database.IsAvailable) throw new InvalidOperationException(Database.Status);
            Tasks = new TaskService(Paths, Database);
            Activities = new ActivityService(Paths, Database);
            Tasks.LoadAsync().GetAwaiter().GetResult();
            Activities.LoadAsync().GetAwaiter().GetResult();
        }
    }

    public string Root { get; }
    public PathService Paths { get; }
    public DatabaseService? Database { get; }
    public TaskService? Tasks { get; }
    public ActivityService? Activities { get; }

    public static TestScope Create(bool withDatabase = false) =>
        new(Path.Combine(Path.GetTempPath(), "GhostTapSmoke", Guid.NewGuid().ToString("N")), withDatabase);

    public void Dispose()
    {
        try { Database?.DisposeAsync().AsTask().GetAwaiter().GetResult(); } catch { }
        try { Directory.Delete(Root, true); } catch { }
    }
}
