namespace GhostTap.Unified.Models;

public enum GhostTaskStatus
{
    Open,
    Done
}

public enum WhatsAppTriggerMode
{
    Keywords,
    AnyMessage
}

public enum AutomationTargetKind
{
    Url,
    Application,
    Shell
}

public sealed class GhostTask
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Title { get; set; } = string.Empty;
    public string SourceChat { get; set; } = string.Empty;
    public string SourcePreview { get; set; } = string.Empty;
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.Now;
    public DateTimeOffset? DueAt { get; set; }
    public GhostTaskStatus Status { get; set; } = GhostTaskStatus.Open;
    public DateTimeOffset? LastReminderAt { get; set; }
    public DateTimeOffset? NextReminderAt { get; set; }
    public int ReminderMinutes { get; set; } = 120;
    public string DetectionKey { get; set; } = string.Empty;
    public int Occurrences { get; set; } = 1;
}

public sealed class WhatsAppActivity
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Chat { get; set; } = string.Empty;
    public string Sender { get; set; } = string.Empty;
    public string Preview { get; set; } = string.Empty;
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.Now;
    public bool IsHandled { get; set; }
    public bool GeneratedTask { get; set; }
    public string NotificationKey { get; set; } = string.Empty;
}

public sealed class WhatsAppWatchRule
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = string.Empty;
    public string ChatPattern { get; set; } = "*";
    public WhatsAppTriggerMode TriggerMode { get; set; } = WhatsAppTriggerMode.Keywords;
    public List<string> Keywords { get; set; } = new();
    public int ReminderMinutes { get; set; } = 120;
    public bool Enabled { get; set; } = true;
    public bool AutoCreateTasks { get; set; } = true;
    public bool CaptureAllMessages { get; set; }
    public bool RecordActivity { get; set; } = true;
}

public sealed class AutomationTarget
{
    public AutomationTargetKind Kind { get; set; } = AutomationTargetKind.Url;
    public string Value { get; set; } = string.Empty;
}

public sealed class FocusMode
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public bool PauseReminders { get; set; }
    public List<AutomationTarget> Targets { get; set; } = new();
    public List<string> CloseProcessNames { get; set; } = new();
}

public sealed class NfcBinding
{
    public string Uid { get; set; } = string.Empty;
    public string ModeId { get; set; } = string.Empty;
    public string Label { get; set; } = string.Empty;
    public string IdentityType { get; set; } = "UID";
    public bool IsUniqueIdentity { get; set; } = true;
    public DateTimeOffset BoundAt { get; set; } = DateTimeOffset.Now;
}

public sealed class GhostTapSettings
{
    public bool StartWithWindows { get; set; } = true;
    public bool StartMinimized { get; set; }
    public bool OnboardingCompleted { get; set; }
    public bool WhatsAppEnabled { get; set; } = true;
    public bool RemindersPaused { get; set; }
    public int WhatsAppPollSeconds { get; set; } = 30;
    public int DefaultReminderMinutes { get; set; } = 120;
    public int NotificationCatchUpMinutes { get; set; } = 10;
    public bool CloseDistractingProcesses { get; set; }
    public bool ForceCloseDistractingProcesses { get; set; }
    public List<string> DistractingProcessNames { get; set; } = new() { "Discord", "DiscordPTB", "DiscordCanary" };
    public string CurrentModeId { get; set; } = string.Empty;
    public List<WhatsAppWatchRule> WhatsAppRules { get; set; } = new();
    public List<FocusMode> FocusModes { get; set; } = new();
    public List<NfcBinding> NfcBindings { get; set; } = new();
}

public sealed class TaskCandidate
{
    public string Title { get; set; } = string.Empty;
    public string SourceChat { get; set; } = string.Empty;
    public string SourcePreview { get; set; } = string.Empty;
    public DateTimeOffset? DueAt { get; set; }
    public int ReminderMinutes { get; set; } = 120;
    public string DetectionKey { get; set; } = string.Empty;
}

public sealed class WhatsAppNotificationItem
{
    public string AppName { get; set; } = string.Empty;
    public string Chat { get; set; } = string.Empty;
    public string Sender { get; set; } = string.Empty;
    public string Body { get; set; } = string.Empty;
    public DateTimeOffset CreatedAt { get; set; }
    public uint? NotificationId { get; set; }
    public string NotificationKey { get; set; } = string.Empty;
}


public sealed class WhatsAppParserConfiguration
{
    public int Version { get; set; } = 1;
    public List<string> RecognizedAppNamePatterns { get; set; } = new();
    public List<string> Categories { get; set; } = new();
    public Dictionary<string, int> NumberWords { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public int MaxTaskTitles { get; set; } = 8;
    public int MaxQuantityPerCategory { get; set; } = 10;
    public string DefaultDueTime { get; set; } = "18:00";
    public Dictionary<string, string> Patterns { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

public sealed class AppCheckResult
{
    public string Name { get; init; } = string.Empty;
    public bool Passed { get; init; }
    public bool Warning { get; init; }
    public string Details { get; init; } = string.Empty;
}
